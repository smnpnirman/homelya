import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getYouTubeEmbedUrl(url: string): string | null {
  if (!url) return null;
  let videoId: string | null = null;
  // Standard URL: https://www.youtube.com/watch?v=...
  const urlParams = new URLSearchParams(new URL(url).search);
  videoId = urlParams.get('v');

  if (videoId) {
    return `https://www.youtube.com/embed/${videoId}`;
  }

  // Shortened URL: https://youtu.be/...
  const match = url.match(/youtu\.be\/([^?&]+)/);
  if (match && match[1]) {
    videoId = match[1];
    return `https://www.youtube.com/embed/${videoId}`;
  }
  
  // Shorts URL: https://www.youtube.com/shorts/...
  const shortsMatch = url.match(/youtube\.com\/shorts\/([^?&]+)/);
  if (shortsMatch && shortsMatch[1]) {
      videoId = shortsMatch[1];
      return `https://www.youtube.com/embed/${videoId}`;
  }

  return null;
}

export function getInstagramEmbedUrl(url: string): string | null {
    if (!url) return null;
    const match = url.match(/(?:https?:\/\/(?:www\.)?instagram\.com\/(?:p|reel)\/([a-zA-Z0-9_-]+))/);
    if (match && match[1]) {
        return `https://www.instagram.com/p/${match[1]}/embed/`;
    }
    return null;
}
