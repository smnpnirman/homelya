import type { Design, Provider, Supplier } from './types';

export const designs: Design[] = [
  {
    id: 'des1',
    name: 'Modern Minimalist Villa',
    style: 'Modern',
    bedrooms: 4,
    bathrooms: 3,
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'modern house',
    description: 'A sleek and stylish modern villa with open-plan living and clean lines.'
  },
  {
    id: 'des2',
    name: 'Traditional Jharkhand Haveli',
    style: 'Traditional',
    bedrooms: 5,
    bathrooms: 4,
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'traditional indian house',
    description: 'A beautiful haveli design inspired by the rich heritage of Jharkhand.'
  },
  {
    id: 'des3',
    name: 'Eco-Friendly Cottage',
    style: 'Eco-Friendly',
    bedrooms: 3,
    bathrooms: 2,
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'eco friendly cottage',
    description: 'A sustainable cottage design using natural materials and energy-efficient features.'
  },
  {
    id: 'des4',
    name: 'Contemporary Urban Home',
    style: 'Contemporary',
    bedrooms: 3,
    bathrooms: 3,
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'urban house',
    description: 'A chic urban home perfect for city living, with smart space utilization.'
  },
  {
    id: 'des5',
    name: 'Rustic Farmhouse',
    style: 'Rustic',
    bedrooms: 4,
    bathrooms: 3,
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'rustic farmhouse',
    description: 'A charming rustic farmhouse that blends comfort with country-style living.'
  },
  {
    id: 'des6',
    name: 'Luxury Duplex',
    style: 'Luxury',
    bedrooms: 5,
    bathrooms: 5,
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'luxury duplex',
    description: 'An opulent duplex with high-end finishes and spacious interiors.'
  },
];

export const designers: Provider[] = [
  {
    id: 'dgn1',
    name: 'Anjali Sharma Designs',
    specialty: 'Modern & Minimalist',
    location: 'Ranchi',
    rating: 4.9,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'architect portrait',
    description: 'Specializing in creating elegant and functional modern living spaces.'
  },
  {
    id: 'dgn2',
    name: 'Heritage Architects',
    specialty: 'Traditional Indian',
    location: 'Jamshedpur',
    rating: 4.8,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'architect working',
    description: 'Experts in reviving traditional architecture with a contemporary touch.'
  },
  {
    id: 'dgn3',
    name: 'Green Scapes Studio',
    specialty: 'Sustainable Design',
    location: 'Dhanbad',
    rating: 4.7,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'woman architect',
    description: 'Pioneering eco-friendly and sustainable architectural solutions.'
  },
  {
    id: 'dgn4',
    name: 'Urban Edge Planners',
    specialty: 'Contemporary Urban',
    location: 'Ranchi',
    rating: 4.6,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'man architect',
    description: 'Innovative designs tailored for the modern urban lifestyle.'
  },
];

export const constructors: Provider[] = [
  {
    id: 'con1',
    name: 'Jharkhand Builders',
    specialty: 'Residential & Commercial',
    location: 'Ranchi',
    rating: 4.8,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'construction site',
    description: 'Trusted builders with a legacy of quality construction in Jharkhand.'
  },
  {
    id: 'con2',
    name: 'Steel City Constructions',
    specialty: 'Industrial & Residential',
    location: 'Jamshedpur',
    rating: 4.7,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'building construction',
    description: 'Delivering robust and high-quality construction projects on time.'
  },
  {
    id: 'con3',
    name: 'Dhanbad Developers',
    specialty: 'Luxury Apartments',
    location: 'Dhanbad',
    rating: 4.9,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'apartment building',
    description: 'Creating premium living spaces with a focus on luxury and comfort.'
  },
  {
    id: 'con4',
    name: 'EcoBuild Solutions',
    specialty: 'Eco-friendly Homes',
    location: 'Bokaro',
    rating: 4.6,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'green building',
    description: 'Building sustainable homes for a greener future.'
  },
];

export const suppliers: Supplier[] = [
  {
    id: 'sup1',
    name: 'Ranchi Steel & Cement',
    category: 'Building Materials',
    location: 'Ranchi',
    rating: 4.7,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'steel beams',
    description: 'One-stop shop for high-quality steel, cement, and other essential materials.'
  },
  {
    id: 'sup2',
    name: 'Jamshedpur Marbles',
    category: 'Flooring & Tiles',
    location: 'Jamshedpur',
    rating: 4.8,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'marble slab',
    description: 'Exquisite collection of marbles, granites, and tiles for elegant interiors.'
  },
  {
    id: 'sup3',
    name: 'Dhanbad Electricals',
    category: 'Electrical Fittings',
    location: 'Dhanbad',
    rating: 4.6,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'electrical wires',
    description: 'Reliable supplier for all your electrical wiring and fitting needs.'
  },
  {
    id: 'sup4',
    name: 'Bokaro Paints & Finishes',
    category: 'Paints & Coatings',
    location: 'Bokaro',
    rating: 4.5,
    image: 'https://placehold.co/400x400.png',
    dataAiHint: 'paint cans',
    description: 'Wide range of premium paints and finishes to beautify your home.'
  },
];

export const allItems = [...designs, ...designers, ...constructors, ...suppliers];
