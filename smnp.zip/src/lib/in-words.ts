
const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

function numberToWords(num: number): string {
    if (num < 10) return ones[num];
    if (num < 20) return teens[num - 10];
    if (num < 100) return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + ones[num % 10] : '');
    if (num < 1000) return ones[Math.floor(num / 100)] + ' Hundred' + (num % 100 !== 0 ? ' and ' + numberToWords(num % 100) : '');
    return '';
}

export function amountToWords(amount: number): string {
    if (amount === 0) return 'Zero';

    let words = '';
    const crore = Math.floor(amount / 10000000);
    amount %= 10000000;
    const lakh = Math.floor(amount / 100000);
    amount %= 100000;
    const thousand = Math.floor(amount / 1000);
    amount %= 1000;
    const remaining = amount;

    if (crore > 0) {
        words += numberToWords(crore) + ' Crore ';
    }
    if (lakh > 0) {
        words += numberToWords(lakh) + ' Lakh ';
    }
    if (thousand > 0) {
        words += numberToWords(thousand) + ' Thousand ';
    }
    if (remaining > 0) {
        words += numberToWords(remaining);
    }

    return words.trim() + ' Only';
}
