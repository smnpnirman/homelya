
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyB7iVQfKXIqoxZC5yURE5A1T6jm8-AEvpM",
  authDomain: "homelya-yjrg1.firebaseapp.com",
  databaseURL: "https://homelya-yjrg1-default-rtdb.firebaseio.com",
  projectId: "homelya-yjrg1",
  storageBucket: "homelya-yjrg1.firebasestorage.app",
  messagingSenderId: "573024554521",
  appId: "1:573024554521:web:24604258cf6d69e78b6488"
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getDatabase(app);

export { app, auth, db };
