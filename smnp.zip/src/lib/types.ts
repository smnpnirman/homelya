






export type ItemType = 'design' | 'designer' | 'constructor' | 'supplier' | 'property' | 'auction' | 'event' | 'seller' | 'broker';
export type VerificationStatus = 'in-progress' | 'payment-pending' | 'verified' | 'rejected' | 'master-payment-pending' | 'master' | 'user';
export type ProfileTheme = 'default' | 'modern' | 'creative' | 'premium';

export interface BaseItem {
  id: string;
  name: string;
  image: string;
  rating?: number;
  description?: string;
  dataAiHint?: string;
}

export type DesignCategory = "Architectural Plan" | "Interior Design" | "Wall Art" | "Furniture Design";

export interface Design extends BaseItem {
  style: string;
  category: DesignCategory;
  bedrooms?: number;
  bathrooms?: number;
  price?: number;
  designerId?: string;
  rating?: number;
  reviewCount?: number;
  images?: string[];
  videoUrl?: string;
}

export interface Property extends BaseItem {
  price: number;
  location: string;
  area: number; // in sqft
  bedrooms: number;
  bathrooms: number;
  propertyType: 'Apartment' | 'Villa' | 'Plot' | 'House';
  sellerId: string;
  images?: string[];
  status: 'available' | 'sold';
}

export interface Bid {
    userId: string;
    userName: string;
    amount: number;
    timestamp: number;
}

export interface Auction extends BaseItem {
    propertyType: 'Apartment' | 'Villa' | 'Plot' | 'House';
    location: string;
    area: number;
    bedrooms: number;
    bathrooms: number;
    images: string[];
    startingBid: number;
    currentBid: number;
    bidIncrement: number;
    endTime: number; // as timestamp
    sellerId: string;
    status: 'active' | 'ended';
    winnerId?: string;
    bids: Record<string, Bid>;
}


export interface Provider extends BaseItem {
  specialty: string;
  experienceLevel?: 'Beginner' | 'Intermediate' | 'Expert';
  location: string;
  locationUrl?: string;
  phone?: string;
  email?: string;
  website?: string;
  status?: VerificationStatus;
  gstNumber?: string;
  architectureRegistrationNumber?: string;
  localAuthorityRegistrationNumber?: string;
  smnpId?: string;
  vrId?: string;
  socials?: {
    facebook?: string;
    instagram?: string;
    linkedin?: string;
    twitter?: string;
  };
  workHistory?: string;
  skills?: string;
  catalogPdfUrl?: string;
  role: 'designer' | 'constructor' | 'supplier' | 'seller' | 'broker';
  theme?: ProfileTheme;
  coverImage?: string;
  galleryImages?: string;
  profileVideoUrl?: string;
  country?: 'india' | 'dubai';
}

export interface Supplier extends Provider { // Supplier can also be a provider
  category: string;
}

export interface AdvertisementStatus = 'pending' | 'active' | 'rejected' | 'paused' | 'completed';

export interface Advertisement {
    id: string;
    professionalId: string;
    professionalName: string;
    campaignName: string;
    targetLocation: string;
    budget: number;
    adCopy: string;
    adImage: string;
    ctaLink: string;
    status: AdvertisementStatus;
    createdAt: number;
    startDate?: number;
    endDate?: number;
    rejectionReason?: string;
}

export interface Transaction {
    amount: number;
    description: string;
    timestamp: number;
    type: 'payment' | 'purchase' | 'refund';
    status: 'completed' | 'pending' | 'failed';
    subscriptionYears?: number;
}

export type EventStatus = 'pending' | 'approved' | 'rejected' | 'completed' | 'cancelled';

export interface AppEvent extends BaseItem {
    eventType: 'online' | 'offline';
    eventDate: string;
    locationOrUrl: string;
    ticketPrice: number;
    totalTickets: number;
    ticketsBooked: number;
    professionalId: string;
    professionalName: string;
    status: EventStatus;
    createdAt: number;
}

export interface EventBooking {
    id: string;
    eventId: string;
    eventTitle: string;
    userId: string;
    userName: string;
    userEmail: string;
    userPhone?: string;
    timestamp: number;
    userId_eventId: string;
}

export interface FestivalGreeting {
  id: string;
  eventName: string;
  title: string;
  description: string;
  images: string[];
  readMoreUrl?: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userImage?: string;
  rating: number;
  comment: string;
  timestamp: number;
}

export interface DesignReview {
  id: string;
  userId: string;
  userName: string;
  userImage?: string;
  rating: number;
  comment: string;
  images?: string[];
  timestamp: number;
}

export interface Offer {
    id: string;
    title: string;
    description: string;
    discountPercentage: number;
    applicableOn: string;
    code?: string;
    expiryDate: string;
    status: 'active' | 'hidden';
}

export type Item = (Design | Provider | Supplier | Property | Auction | AppEvent) & { status?: VerificationStatus };
