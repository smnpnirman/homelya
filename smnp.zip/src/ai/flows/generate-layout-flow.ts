
'use server';
/**
 * @fileOverview A flow for generating a description for a floor plan layout from a design description.
 *
 * - generateLayout - A function that takes a description and generates an image URL and a caption.
 * - GenerateLayoutInput - The input type for the generateLayout function.
 * - GenerateLayoutOutput - The return type for the generateLayout function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';

const GenerateLayoutInputSchema = z.object({
  designDescription: z
    .string()
    .describe('A detailed text description of the home design for which to generate a layout description.'),
});
export type GenerateLayoutInput = z.infer<typeof GenerateLayoutInputSchema>;

const GenerateLayoutOutputSchema = z.object({
  imageUrl: z.string().url().describe('A URL for a relevant floor plan image.'),
  caption: z.string().describe('A descriptive caption for the floor plan image.'),
});
export type GenerateLayoutOutput = z.infer<typeof GenerateLayoutOutputSchema>;

export async function generateLayout(input: GenerateLayoutInput): Promise<GenerateLayoutOutput> {
  return generateLayoutFlow(input);
}

const generateLayoutFlow = ai.defineFlow(
  {
    name: 'generateLayoutFlow',
    inputSchema: GenerateLayoutInputSchema,
    outputSchema: GenerateLayoutOutputSchema,
  },
  async ({ designDescription }) => {
    const { output } = await ai.generate({
      model: 'googleai/gemini-pro',
      prompt: `Based on the following home design description, write a short, one-sentence caption for a representative floor plan image. The caption should be descriptive and sound professional.
      
      Design Description: "${designDescription}"
      
      Caption:`,
    });
    
    const caption = output?.toString() || 'A well-designed floor plan showcasing the layout and features of the home.';

    return { 
        imageUrl: 'https://picsum.photos/1200/800',
        caption: caption,
    };
  }
);
