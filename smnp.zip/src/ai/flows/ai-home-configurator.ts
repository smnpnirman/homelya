'use server';
/**
 * @fileOverview Provides AI-powered home configuration recommendations.
 *
 * - aiHomeConfigurator - A function that provides personalized recommendations for home designs, constructors, and material suppliers.
 * - AIHomeConfiguratorInput - The input type for the aiHomeConfigurator function.
 * - AIHomeConfiguratorOutput - The return type for the aiHomeConfigurator function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIHomeConfiguratorInputSchema = z.object({
  preferences: z
    .string()
    .describe('User preferences and requirements for their home, including desired style, size, budget, and location.'),
  existingDesignElements: z
    .string()
    .optional()
    .describe('Optional description of existing design elements or constraints.'),
  language: z.enum(['english', 'hindi']).optional().default('english').describe('The language for the response.'),
});
export type AIHomeConfiguratorInput = z.infer<typeof AIHomeConfiguratorInputSchema>;

const AIHomeConfiguratorOutputSchema = z.object({
  designRecommendation: z.object({
    style: z.string().describe("The recommended architectural style (e.g., Modern, Traditional)."),
    summary: z.string().describe("A brief summary explaining why this design is a good fit."),
    keyFeatures: z.array(z.string()).describe("A list of 3-5 key features of the recommended design."),
  }).describe('AI-generated recommendation for home design.'),
  constructorRecommendation: z.object({
    name: z.string().describe("The name of a suggested local constructor or a profile type (e.g., 'Experienced Residential Contractor')."),
    justification: z.string().describe("A brief explanation for why this type of constructor is recommended."),
    suggestedQualities: z.array(z.string()).describe("A list of 2-3 important qualities to look for in this constructor."),
  }).describe('AI-generated recommendation for a constructor.'),
  materialSupplierRecommendation: z.object({
    name: z.string().describe("The name of a suggested local supplier or a type of supplier (e.g., 'Local Brick and Steel Distributor')."),
    justification: z.string().describe("A brief explanation for why this type of supplier is recommended."),
    suggestedMaterials: z.array(z.string()).describe("A list of 2-3 key materials this supplier should provide for the project."),
  }).describe('AI-generated recommendation for a material supplier.'),
});
export type AIHomeConfiguratorOutput = z.infer<typeof AIHomeConfiguratorOutputSchema>;

export async function aiHomeConfigurator(input: AIHomeConfiguratorInput): Promise<AIHomeConfiguratorOutput> {
  return aiHomeConfiguratorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiHomeConfiguratorPrompt',
  input: {schema: AIHomeConfiguratorInputSchema},
  output: {schema: AIHomeConfiguratorOutputSchema},
  prompt: `You are a home design expert specializing in providing personalized recommendations for home designs, constructors, and material suppliers.

  Based on the user's preferences and requirements, generate recommendations for a suitable home design, constructor, and material supplier.
  Take into account any existing design elements or constraints provided by the user.

  Preferences and Requirements: {{{preferences}}}
  Existing Design Elements: {{{existingDesignElements}}}
  
  Respond in a professional tone. Ensure that the design, constructor, and material supplier recommendations are all suitable for the user.
  Remember we are operating in India. Ensure that the design and materials are suitable for the local climate and availability based on the user's location.
  
  Please provide the response in the "{{language}}" language.

  Provide your response in a structured format with clear, actionable points as defined in the output schema.
`,
});

const aiHomeConfiguratorFlow = ai.defineFlow(
  {
    name: 'aiHomeConfiguratorFlow',
    inputSchema: AIHomeConfiguratorInputSchema,
    outputSchema: AIHomeConfiguratorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
