'use server';
/**
 * @fileOverview Provides AI-powered construction cost estimations and guidance.
 *
 * - constructionCostEstimator - A function that provides an estimated cost and professional guidance for a construction project.
 * - ConstructionCostEstimatorInput - The input type for the function.
 * - ConstructionCostEstimatorOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ConstructionCostEstimatorInputSchema = z.object({
  plotArea: z.number().min(100).describe('The area of the plot in square feet.'),
  floors: z.number().min(1).describe('The number of floors to be constructed.'),
  quality: z.enum(['basic', 'standard', 'premium']).describe("The desired quality of materials and finishing (e.g., 'basic', 'standard', 'premium')."),
  location: z.string().min(2).describe('The city or location of the construction project in India.'),
});
export type ConstructionCostEstimatorInput = z.infer<typeof ConstructionCostEstimatorInputSchema>;

const ConstructionCostEstimatorOutputSchema = z.object({
  estimatedCost: z.object({
    total: z.string().describe("The total estimated cost in Indian Rupees (e.g., '₹50,00,000')."),
    materials: z.string().describe("The estimated cost for materials in Indian Rupees."),
    labor: z.string().describe("The estimated cost for labor in Indian Rupees."),
    permits: z.string().describe("The estimated cost for permits and fees in Indian Rupees."),
    sqftRate: z.string().describe("The estimated per square foot construction rate for the given location and quality (e.g., '₹1,500 per sqft')."),
  }).describe('A breakdown of the estimated construction costs.'),
  guidance: z.object({
    summary: z.string().describe("A brief summary of the project and cost implications."),
    nextSteps: z.array(z.string()).describe("A list of 2-4 recommended next steps for the user."),
    recommendations: z.array(z.string()).describe("A list of 2-3 key recommendations to consider for the project."),
  }).describe('Professional guidance and recommendations.'),
});
export type ConstructionCostEstimatorOutput = z.infer<typeof ConstructionCostEstimatorOutputSchema>;

export async function constructionCostEstimator(input: ConstructionCostEstimatorInput): Promise<ConstructionCostEstimatorOutput> {
  return constructionCostEstimatorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'constructionCostEstimatorPrompt',
  input: {schema: ConstructionCostEstimatorInputSchema},
  output: {schema: ConstructionCostEstimatorOutputSchema},
  prompt: `You are a construction cost estimation expert in India.

  A user wants to estimate the cost of building a house. Based on their inputs, provide a detailed cost estimation and professional guidance.
  
  User Inputs:
  - Plot Area: {{{plotArea}}} sq. ft.
  - Number of Floors: {{{floors}}}
  - Quality of Materials: {{{quality}}}
  - Location: {{{location}}}, India

  Instructions:
  1.  Calculate the total built-up area (Plot Area * Number of Floors).
  2.  Determine a reasonable per square foot (sqft) construction rate based on the location and quality. Use your knowledge of construction costs across different Indian cities. For example, Tier 1 cities (Mumbai, Delhi) will be more expensive than Tier 2 (Pune, Lucknow) or Tier 3 cities.
  3.  Calculate the total estimated cost.
  4.  Break down the total cost into:
      - Materials: ~65% of total
      - Labor: ~25% of total
      - Permits & Fees: ~10% of total
  5.  Format all costs clearly in Indian Rupees (e.g., "₹50,00,000").
  6.  Provide a summary of the project, concise next steps, and key recommendations for the user. Keep all text brief and easy to understand.

  Provide your response in the structured format defined in the output schema.
`,
});

const constructionCostEstimatorFlow = ai.defineFlow(
  {
    name: 'constructionCostEstimatorFlow',
    inputSchema: ConstructionCostEstimatorInputSchema,
    outputSchema: ConstructionCostEstimatorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
