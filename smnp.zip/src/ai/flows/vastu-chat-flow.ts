
'use server';
/**
 * @fileOverview A Vastu Shastra consultation AI agent.
 *
 * - vastuChat - A function that answers user questions about Vastu Shastra.
 * - VastuChatInput - The input type for the vastuChat function.
 * - VastuChatOutput - The return type for the vastuChat function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const VastuChatInputSchema = z.object({
  question: z
    .string()
    .min(10)
    .describe('A user\'s question about Vastu Shastra.'),
  language: z.enum(['english', 'hindi']).optional().default('english').describe('The language for the response.'),
});
export type VastuChatInput = z.infer<typeof VastuChatInputSchema>;

const VastuChatOutputSchema = z.object({
  answer: z.string().describe('A helpful and detailed answer based on Vastu Shastra principles.'),
  references: z.array(z.string()).describe('A list of Indian scriptures or texts used as a reference for the answer.'),
});
export type VastuChatOutput = z.infer<typeof VastuChatOutputSchema>;

export async function vastuChat(input: VastuChatInput): Promise<VastuChatOutput> {
  return vastuChatFlow(input);
}

const prompt = ai.definePrompt({
  name: 'vastuChatPrompt',
  input: {schema: VastuChatInputSchema},
  output: {schema: VastuChatOutputSchema},
  prompt: `You are an expert in Vastu Shastra, the ancient Indian science of architecture and design.
  
  A user has a question about Vastu. Provide a clear, helpful, and respectful answer based on traditional Vastu principles.
  For each answer, you MUST provide a list of one or two primary Indian scriptures or texts (e.g., Mayamatam, Manasara, Samarangana Sutradhara, Vedas) that the principle is derived from.

  If the question is not related to Vastu, architecture, or home design, politely decline to answer and state that you are a Vastu expert.

  The user's question is in English, but you must respond in the user's preferred language: "{{language}}".

  User's Question: {{{question}}}
  
  Your Answer and References:
`,
});

const vastuChatFlow = ai.defineFlow(
  {
    name: 'vastuChatFlow',
    inputSchema: VastuChatInputSchema,
    outputSchema: VastuChatOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
