'use server';
import { config } from 'dotenv';
config();

import '@/ai/flows/ai-home-configurator.ts';
import '@/ai/flows/generate-layout-flow.ts';
import '@/ai/flows/estimation-calculator-flow.ts';
import '@/ai/flows/vastu-chat-flow.ts';
