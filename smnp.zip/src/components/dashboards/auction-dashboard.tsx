
'use client';

import { useEffect, useState, useMemo } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue } from 'firebase/database';
import type { Auction } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { IndianRupee, Gavel } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import Image from 'next/image';
import Logo from '@/components/logo';

interface AuctionStats {
  endedCount: number;
  endedValue: number;
  totalCount: number;
  activeCount: number;
}

interface TypeStats {
  type: string;
  active: number;
  total: number;
  percentage: number;
}

const formatCurrency = (value: number) => {
    if (value >= 10000000) { // Crores
        return `₹${(value / 10000000).toFixed(2)} Cr`;
    }
    if (value >= 100000) { // Lakhs
        return `₹${(value / 100000).toFixed(2)} L`;
    }
    return `₹${value.toLocaleString('en-IN')}`;
};

export default function AuctionDashboard() {
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [pageUrl, setPageUrl] = useState('');

  useEffect(() => {
    setPageUrl(window.location.href);

    const auctionsRef = ref(db, 'auctions');
    const unsubscribe = onValue(auctionsRef, (snapshot) => {
      const data = snapshot.val();
      const auctionsList: Auction[] = data
        ? Object.keys(data).map(key => ({ id: key, ...data[key] }))
        : [];
      setAuctions(auctionsList);
      setLoading(false);
    });
    
    const timer = setInterval(() => setCurrentTime(new Date()), 1000 * 60);

    return () => {
        unsubscribe();
        clearInterval(timer);
    };
  }, []);

  const stats: AuctionStats = useMemo(() => {
    const now = new Date().getTime();
    return auctions.reduce(
      (acc, auction) => {
        acc.totalCount += 1;
        if (auction.endTime < now) {
          acc.endedCount += 1;
          acc.endedValue += auction.currentBid;
        } else {
          acc.activeCount += 1;
        }
        return acc;
      },
      { endedCount: 0, endedValue: 0, totalCount: 0, activeCount: 0 }
    );
  }, [auctions]);

  const typeStats: TypeStats[] = useMemo(() => {
    const statsByType = auctions.reduce((acc, auction) => {
      const type = auction.propertyType || 'Unknown';
      if (!acc[type]) {
        acc[type] = { active: 0, total: 0 };
      }
      acc[type].total += 1;
      if (new Date().getTime() <= auction.endTime) {
        acc[type].active += 1;
      }
      return acc;
    }, {} as Record<string, { active: number; total: number }>);

    return Object.entries(statsByType)
      .map(([type, data]) => ({
        type,
        ...data,
        percentage: data.total > 0 ? (data.active / data.total) * 100 : 0,
      }))
      .sort((a, b) => b.total - a.total);
  }, [auctions]);

  const activePercentage = stats.totalCount > 0 ? (stats.activeCount / stats.totalCount) * 100 : 0;
  
  const qrCodeUrl = pageUrl ? `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(pageUrl)}` : '';


  if (loading) {
    return (
        <div className="space-y-6 pt-4">
            <Skeleton className="h-16 w-1/2 mx-auto" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {Array.from({length: 4}).map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}
            </div>
             <Skeleton className="h-64 w-full" />
        </div>
    );
  }

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-white font-sans mt-4 rounded-lg">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tighter bg-gradient-to-r from-red-500 to-orange-400 bg-clip-text text-transparent">
                GRAND AUCTIONS
            </h1>
            <p className="text-slate-400">Live Auction Dashboard</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 flex flex-col gap-6">
                <Image
                    src="https://picsum.photos/seed/auction/600/400"
                    alt="Auction Gavel"
                    width={600}
                    height={400}
                    className="rounded-lg object-cover"
                    data-ai-hint="auction gavel"
                />
                {qrCodeUrl && (
                    <Image
                        src={qrCodeUrl}
                        alt="QR Code for page"
                        width={150}
                        height={150}
                        className="rounded-lg bg-white p-2 mx-auto"
                    />
                )}
            </div>
            <div className="lg:col-span-2 space-y-4">
                 <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">CURRENT TIME</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-semibold">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </CardContent>
                </Card>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                     <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">AUCTIONS ENDED</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-4xl font-bold text-red-400">{stats.endedCount}</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">TOTAL VALUE OF ENDED</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-4xl font-bold text-red-400">{formatCurrency(stats.endedValue)}</p>
                        </CardContent>
                    </Card>
                </div>
                 <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">ACTIVE / TOTAL AUCTIONS</CardTitle>
                    </CardHeader>
                    <CardContent>
                         <p className="text-3xl font-semibold mb-2">{stats.activeCount} / {stats.totalCount} <span className="text-xl text-slate-400">({activePercentage.toFixed(1)}% Active)</span></p>
                         <Progress value={activePercentage} className="h-3 bg-slate-700" indicatorClassName="bg-green-500" />
                    </CardContent>
                </Card>

                 <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">ACTIVE AUCTIONS BY TYPE</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {typeStats.map(t => (
                             <div key={t.type}>
                                <div className="flex justify-between items-center text-sm mb-1">
                                    <p className="font-semibold">{t.type}</p>
                                    <p className="text-slate-400">{t.active} / {t.total} Active</p>
                                </div>
                                <Progress value={t.percentage} className="h-2.5 bg-slate-700" indicatorClassName="bg-amber-500" />
                             </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </div>
      </div>
    </div>
  );
}

declare module "react" {
    interface HTMLAttributes<T> extends AriaAttributes, DOMAttributes<T> {
      indicatorClassName?: string;
    }
}
