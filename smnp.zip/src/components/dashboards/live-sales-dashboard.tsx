
'use client';

import { useEffect, useState, useMemo } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue } from 'firebase/database';
import type { Property } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { IndianRupee, Building, CheckCircle, Clock } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import Image from 'next/image';
import Logo from '@/components/logo';

interface SalesStats {
  unitsSold: number;
  soldValue: number;
  totalUnits: number;
  availableUnits: number;
}

interface LocationStats {
  location: string;
  sold: number;
  total: number;
  percentage: number;
}

// Function to format large numbers into a compact format (e.g., 1.2M, 1.5Cr)
const formatCurrency = (value: number) => {
    if (value >= 10000000) { // Crores
        return `₹${(value / 10000000).toFixed(2)} Cr`;
    }
    if (value >= 100000) { // Lakhs
        return `₹${(value / 100000).toFixed(2)} L`;
    }
    return `₹${value.toLocaleString('en-IN')}`;
};

export default function LiveSalesDashboard() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [pageUrl, setPageUrl] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
        setPageUrl(window.location.href);
    }
    const propertiesRef = ref(db, 'properties');
    const unsubscribe = onValue(propertiesRef, (snapshot) => {
      const data = snapshot.val();
      const propertiesList: Property[] = data
        ? Object.keys(data).map(key => ({ id: key, ...data[key] }))
        : [];
      setProperties(propertiesList);
      setLoading(false);
    });
    
    // Timer for the clock
    const timer = setInterval(() => setCurrentTime(new Date()), 1000 * 60); // Update every minute

    return () => {
        unsubscribe();
        clearInterval(timer);
    };
  }, []);

  const stats: SalesStats = useMemo(() => {
    return properties.reduce(
      (acc, property) => {
        acc.totalUnits += 1;
        if (property.status === 'sold') {
          acc.unitsSold += 1;
          acc.soldValue += property.price;
        } else {
          acc.availableUnits += 1;
        }
        return acc;
      },
      { unitsSold: 0, soldValue: 0, totalUnits: 0, availableUnits: 0 }
    );
  }, [properties]);

  const locationStats: LocationStats[] = useMemo(() => {
    const statsByLocation = properties.reduce((acc, property) => {
      const location = property.location || 'Unknown';
      if (!acc[location]) {
        acc[location] = { sold: 0, total: 0 };
      }
      acc[location].total += 1;
      if (property.status === 'sold') {
        acc[location].sold += 1;
      }
      return acc;
    }, {} as Record<string, { sold: number; total: number }>);

    return Object.entries(statsByLocation)
      .map(([location, data]) => ({
        location,
        ...data,
        percentage: data.total > 0 ? (data.sold / data.total) * 100 : 0,
      }))
      .sort((a, b) => b.total - a.total);
  }, [properties]);

  const availabilityPercentage = stats.totalUnits > 0 ? (stats.availableUnits / stats.totalUnits) * 100 : 0;
  
  const qrCodeUrl = pageUrl ? `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(pageUrl)}` : '';


  if (loading) {
    return (
        <div className="space-y-6 pt-4">
            <Skeleton className="h-16 w-1/2 mx-auto" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {Array.from({length: 4}).map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}
            </div>
             <Skeleton className="h-64 w-full" />
        </div>
    );
  }

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-white font-sans mt-4 rounded-lg">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tighter bg-gradient-to-r from-amber-400 to-yellow-500 bg-clip-text text-transparent">
                RIVERSIDE VIEWS
            </h1>
            <p className="text-slate-400">Live Sales Dashboard</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 flex flex-col gap-6">
                <Image
                    src="https://picsum.photos/seed/riverside/600/400"
                    alt="Riverside Views"
                    width={600}
                    height={400}
                    className="rounded-lg object-cover"
                    data-ai-hint="modern apartment building"
                />
                {qrCodeUrl && <Image
                    src={qrCodeUrl}
                    alt="QR Code for page"
                    width={150}
                    height={150}
                    className="rounded-lg bg-white p-2 mx-auto"
                />}
            </div>
            <div className="lg:col-span-2 space-y-4">
                 <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">CURRENT TIME</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-semibold">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </CardContent>
                </Card>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                     <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">UNITS SOLD</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-4xl font-bold text-amber-400">{stats.unitsSold}</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">SOLD VALUE</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-4xl font-bold text-amber-400">{formatCurrency(stats.soldValue)}</p>
                        </CardContent>
                    </Card>
                </div>
                 <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">AVAILABLE / TOTAL UNITS</CardTitle>
                    </CardHeader>
                    <CardContent>
                         <p className="text-3xl font-semibold mb-2">{stats.availableUnits} / {stats.totalUnits} <span className="text-xl text-slate-400">({availabilityPercentage.toFixed(1)}%)</span></p>
                         <Progress value={availabilityPercentage} className="h-3 bg-slate-700" indicatorClassName="bg-green-500" />
                    </CardContent>
                </Card>

                 <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-slate-300 text-sm font-medium tracking-wider uppercase">SALES BY LOCATION</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {locationStats.map(loc => (
                             <div key={loc.location}>
                                <div className="flex justify-between items-center text-sm mb-1">
                                    <p className="font-semibold">{loc.location}</p>
                                    <p className="text-slate-400">{loc.sold} / {loc.total} ({loc.percentage.toFixed(1)}%)</p>
                                </div>
                                <Progress value={loc.percentage} className="h-2.5 bg-slate-700" indicatorClassName="bg-amber-500" />
                             </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </div>
      </div>
    </div>
  );
}

// Small helper for Progress component indicator color
declare module "react" {
    interface HTMLAttributes<T> extends AriaAttributes, DOMAttributes<T> {
      indicatorClassName?: string;
    }
}
