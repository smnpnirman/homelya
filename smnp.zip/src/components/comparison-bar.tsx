
'use client';

import { useComparison } from '@/hooks/use-comparison';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Scale, Trash2, X } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

export default function ComparisonBar() {
    const { items, removeItem, clearAll } = useComparison();

    if (items.length === 0) {
        return null;
    }

    return (
        <Card className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-4xl shadow-2xl animate-in slide-in-from-bottom-10">
            <div className="p-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                    <h3 className="font-headline text-lg hidden sm:block">Compare Items ({items.length}/3)</h3>
                    <div className="flex items-center gap-3">
                        {items.map(item => (
                            <div key={item.id} className="relative group">
                                <Image
                                    src={item.image || 'https://picsum.photos/100'}
                                    alt={item.name}
                                    width={60}
                                    height={60}
                                    className="rounded-md object-cover aspect-square"
                                />
                                <Button
                                    size="icon"
                                    variant="destructive"
                                    className="absolute -top-2 -right-2 h-6 w-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => removeItem(item.id)}
                                >
                                    <X className="h-4 w-4" />
                                </Button>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <Button asChild>
                        <Link href="/compare">
                            <Scale className="mr-2 h-4 w-4"/>
                            Compare Now
                        </Link>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={clearAll}>
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                </div>
            </div>
        </Card>
    );
}
