
'use client';

import { SidebarTrigger } from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import React from "react";
import Logo from "./logo";

interface PageHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  title?: string;
  description?: string;
  showTrigger?: boolean;
}

export default function PageHeader({ title, description, showTrigger = false, className, children, ...props }: PageHeaderProps) {
  return (
    <header className={cn("flex items-center justify-between gap-4 p-4 md:p-0", className)} {...props}>
      {showTrigger && (
        <div className="md:hidden">
            <Logo />
        </div>
      )}
      <div className="flex-1">
        {title && <h1 className="font-headline text-2xl md:text-3xl font-bold">{title}</h1>}
        {description && <p className="text-muted-foreground mt-1">{description}</p>}
      </div>
      {children}
      {showTrigger && <SidebarTrigger />}
    </header>
  );
}
