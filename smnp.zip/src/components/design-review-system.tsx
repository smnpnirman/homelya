'use client';

import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue, push, serverTimestamp } from 'firebase/database';
import { useAuth } from '@/hooks/use-auth';
import type { DesignReview } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star, Loader2, Image as ImageIcon, PlusCircle, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatDistanceToNow } from 'date-fns';
import { Skeleton } from './ui/skeleton';
import { useForm, useFieldArray } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from './ui/input';
import Image from 'next/image';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from './ui/carousel';


interface DesignReviewSystemProps {
  designId: string;
  onStatsUpdate: (average: number, count: number) => void;
}

const reviewFormSchema = z.object({
  rating: z.number().min(1, 'Please select a rating.'),
  comment: z.string().min(10, 'Comment must be at least 10 characters.'),
  images: z.array(z.object({ value: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')) })).optional(),
});

type ReviewFormValues = z.infer<typeof reviewFormSchema>;


export default function DesignReviewSystem({ designId, onStatsUpdate }: DesignReviewSystemProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reviews, setReviews] = useState<DesignReview[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);

  const form = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      rating: 0,
      comment: '',
      images: [{ value: "" }],
    },
  });
  
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "images"
  });

  useEffect(() => {
    setLoading(true);
    const reviewsRef = ref(db, `design-reviews/${designId}`);
    const unsubscribe = onValue(reviewsRef, (snapshot) => {
      const reviewsList: DesignReview[] = [];
      let totalRating = 0;
      let hasUserReviewed = false;
      
      if (snapshot.exists()) {
        const data = snapshot.val();
        Object.keys(data).forEach(key => {
            const review = { id: key, ...data[key] };
            reviewsList.push(review);
            totalRating += review.rating;
            if (user && review.userId === user.uid) {
              hasUserReviewed = true;
            }
        });
        reviewsList.sort((a, b) => b.timestamp - a.timestamp);
      }
      
      setReviews(reviewsList);
      setHasReviewed(hasUserReviewed);
      onStatsUpdate(reviewsList.length > 0 ? totalRating / reviewsList.length : 0, reviewsList.length);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [designId, user, onStatsUpdate]);

  const onSubmit = async (data: ReviewFormValues) => {
    if (!user) {
      toast({ variant: 'destructive', title: 'You must be logged in to leave a review.' });
      return;
    }
    
    setSubmitting(true);
    try {
      const reviewData = {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userImage: user.photoURL || '',
        rating: data.rating,
        comment: data.comment,
        images: (data.images || []).map(img => img.value).filter(Boolean),
        timestamp: serverTimestamp(),
      };
      await push(ref(db, `design-reviews/${designId}`), reviewData);
      toast({ title: 'Review submitted!', description: 'Thank you for your feedback.' });
      form.reset({ rating: 0, comment: '', images: [{ value: "" }]});
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to submit review.' });
    } finally {
      setSubmitting(false);
    }
  };
  
  if (loading) {
      return (
          <Card>
              <CardHeader>
                  <Skeleton className="h-6 w-1/3" />
              </CardHeader>
              <CardContent className="space-y-4">
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
              </CardContent>
          </Card>
      )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Reviews & Ratings</CardTitle>
        <CardDescription>See what others think about this design.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {user && !hasReviewed && (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 border-b pb-6">
                <h4 className="font-semibold">Write Your Review</h4>
                <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Your Rating</FormLabel>
                            <FormControl>
                                <div className="flex items-center gap-1">
                                {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                    key={star}
                                    className={`cursor-pointer h-6 w-6 transition-colors ${
                                        field.value >= star
                                        ? 'text-yellow-500 fill-yellow-400'
                                        : 'text-gray-300 hover:text-gray-400'
                                    }`}
                                    onClick={() => field.onChange(star)}
                                    />
                                ))}
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="comment"
                    render={({ field }) => (
                         <FormItem>
                            <FormLabel>Your Comment</FormLabel>
                            <FormControl>
                                <Textarea
                                placeholder="Share your experience with this design..."
                                {...field}
                                rows={3}
                                />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                 <div className="space-y-4">
                    <FormLabel>Add Image URLs (Optional)</FormLabel>
                    {fields.map((field, index) => (
                        <FormField
                            key={field.id}
                            control={form.control}
                            name={`images.${index}.value`}
                            render={({ field }) => (
                                <FormItem>
                                    <div className="flex gap-2 items-center">
                                        <ImageIcon className="h-4 w-4 text-muted-foreground" />
                                        <FormControl>
                                            <Input placeholder={`Image URL ${index + 1}`} {...field} />
                                        </FormControl>
                                        <Button type="button" variant="ghost" size="icon" className="shrink-0 text-destructive" onClick={() => remove(index)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    ))}
                    <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => append({ value: "" })}
                    >
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add Image URL
                    </Button>
                </div>
                <Button type="submit" disabled={submitting}>
                    {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Submit Review
                </Button>
            </form>
          </Form>
        )}
        
        {reviews.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">No reviews yet. Be the first to leave a review!</p>
        ) : (
            <div className="space-y-6">
                {reviews.map(review => (
                    <div key={review.id} className="flex gap-4">
                        <Avatar className="h-10 w-10 border">
                            <AvatarImage src={review.userImage}/>
                            <AvatarFallback>{review.userName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                            <div className="flex justify-between items-center">
                                <div>
                                    <p className="font-semibold">{review.userName}</p>
                                    <p className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(review.timestamp), {addSuffix: true})}</p>
                                </div>
                                <div className="flex items-center gap-0.5">
                                    {[1, 2, 3, 4, 5].map(star => (
                                        <Star key={star} className={`h-4 w-4 ${review.rating >= star ? 'text-yellow-500 fill-yellow-400' : 'text-gray-300'}`} />
                                    ))}
                                </div>
                            </div>
                            <p className="text-sm text-muted-foreground mt-2 whitespace-pre-wrap">{review.comment}</p>
                             {review.images && review.images.length > 0 && (
                                <div className="mt-2">
                                     <Carousel className="w-full max-w-xs">
                                        <CarouselContent>
                                            {review.images.map((img, index) => (
                                            <CarouselItem key={index}>
                                                <Image src={img} alt={`Review image ${index + 1}`} width={400} height={300} className="rounded-md object-cover" />
                                            </CarouselItem>
                                            ))}
                                        </CarouselContent>
                                        {review.images.length > 1 && <>
                                            <CarouselPrevious className="left-2 h-6 w-6"/>
                                            <CarouselNext className="right-2 h-6 w-6"/>
                                        </>}
                                    </Carousel>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        )}
      </CardContent>
    </Card>
  );
}
