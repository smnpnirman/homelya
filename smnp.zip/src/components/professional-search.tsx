

'use client';

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Search, MapPin, Briefcase, Loader2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { db } from "@/lib/firebase";
import { ref, onValue, get } from "firebase/database";
import { useAuth } from "@/hooks/use-auth";

interface ProfessionalCounts {
    designers: number;
    constructors: number;
    suppliers: number;
    properties: number; // Assuming we might count properties too
}

export default function ProfessionalSearch() {
    const router = useRouter();
    const { user } = useAuth();
    const [searchQuery, setSearchQuery] = useState("");
    const [location, setLocation] = useState("all");
    const [type, setType] = useState("properties");
    const [counts, setCounts] = useState<ProfessionalCounts>({ designers: 0, constructors: 0, suppliers: 0, properties: 0 });
    const [loadingCounts, setLoadingCounts] = useState(true);

    useEffect(() => {
        if (user) {
            const userRef = ref(db, `users/${user.uid}`);
            get(userRef).then(snapshot => {
                if (snapshot.exists()) {
                    const userData = snapshot.val();
                    if (userData.city) {
                        setLocation(userData.city);
                    }
                }
            });
        }
    }, [user]);

    useEffect(() => {
        setLoadingCounts(true);
        const usersRef = ref(db, 'users');
        const propertiesRef = ref(db, 'properties');

        const unsubscribeUsers = onValue(usersRef, (snapshot) => {
            if (snapshot.exists()) {
                const users = snapshot.val();
                const newCounts = { designers: 0, constructors: 0, suppliers: 0, properties: counts.properties };
                Object.values(users).forEach((user: any) => {
                    if (user.role === 'designer') newCounts.designers++;
                    if (user.role === 'constructor') newCounts.constructors++;
                    if (user.role === 'supplier') newCounts.suppliers++;
                });
                setCounts(prev => ({...prev, ...newCounts}));
            }
            setLoadingCounts(false);
        });

        const unsubscribeProperties = onValue(propertiesRef, (snapshot) => {
            if (snapshot.exists()) {
                setCounts(prev => ({...prev, properties: snapshot.size}));
            }
        });

        return () => {
            unsubscribeUsers();
            unsubscribeProperties();
        };
    }, []);

    const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        
        const params = new URLSearchParams();
        if (searchQuery) {
            params.set('q', searchQuery);
        }
        if (location !== 'all') {
            params.set('location', location);
        }
        
        const destination = type === 'properties' ? '/properties' : `/${type}`;
        
        router.push(`${destination}?${params.toString()}`);
    }

    const placeholderText = {
        properties: "Search by neighborhood, city, or property...",
        designers: "Search for architects, interior designers...",
        constructors: "Search for builders, contractors...",
        suppliers: "Search for steel, cement, etc...",
    }[type] || "Search...";


    return (
        <div className="bg-card/80 backdrop-blur-sm p-4 rounded-xl shadow-lg border max-w-4xl mx-auto space-y-4">
            <form onSubmit={handleSearch} className="space-y-4">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input 
                        placeholder={placeholderText} 
                        className="w-full h-12 pl-10 pr-4 rounded-lg text-base" 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_auto] gap-3">
                    <Select value={type} onValueChange={setType}>
                        <SelectTrigger className="h-11">
                             <div className="flex items-center gap-2">
                                <Briefcase className="h-4 w-4 text-muted-foreground"/>
                                <SelectValue placeholder="Type" />
                            </div>
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="properties">
                                <span className="font-semibold">Properties</span>
                                {loadingCounts ? <Loader2 className="h-4 w-4 animate-spin ml-2 inline-block"/> : <span className="text-muted-foreground ml-2">({counts.properties})</span>}
                            </SelectItem>
                            <SelectItem value="designers">
                                <span className="font-semibold">Designers</span>
                                {loadingCounts ? <Loader2 className="h-4 w-4 animate-spin ml-2 inline-block"/> : <span className="text-muted-foreground ml-2">({counts.designers})</span>}
                            </SelectItem>
                            <SelectItem value="constructors">
                                <span className="font-semibold">Constructors</span>
                                {loadingCounts ? <Loader2 className="h-4 w-4 animate-spin ml-2 inline-block"/> : <span className="text-muted-foreground ml-2">({counts.constructors})</span>}
                            </SelectItem>
                            <SelectItem value="suppliers">
                                <span className="font-semibold">Suppliers</span>
                                {loadingCounts ? <Loader2 className="h-4 w-4 animate-spin ml-2 inline-block"/> : <span className="text-muted-foreground ml-2">({counts.suppliers})</span>}
                            </SelectItem>
                        </SelectContent>
                    </Select>
                    <Select value={location} onValueChange={setLocation}>
                        <SelectTrigger className="h-11">
                             <div className="flex items-center gap-2">
                                <MapPin className="h-4 w-4 text-muted-foreground"/>
                                <SelectValue placeholder="Location" />
                            </div>
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All India</SelectItem>
                            <SelectItem value="Mumbai">Mumbai</SelectItem>
                            <SelectItem value="Delhi">Delhi</SelectItem>
                            <SelectItem value="Bangalore">Bangalore</SelectItem>
                            <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                            <SelectItem value="Chennai">Chennai</SelectItem>
                            <SelectItem value="Kolkata">Kolkata</SelectItem>
                            <SelectItem value="Pune">Pune</SelectItem>
                            <SelectItem value="Ahmedabad">Ahmedabad</SelectItem>
                            <SelectItem value="Jaipur">Jaipur</SelectItem>
                            <SelectItem value="Lucknow">Lucknow</SelectItem>
                            <SelectItem value="Ranchi">Ranchi</SelectItem>
                            <SelectItem value="Jamshedpur">Jamshedpur</SelectItem>
                            <SelectItem value="Dubai">Dubai</SelectItem>
                        </SelectContent>
                    </Select>
                    
                    <Button type="submit" className="h-11 w-full lg:col-span-1">
                        <Search className="mr-2 h-4 w-4" />
                        Search
                    </Button>
                </div>
            </form>
        </div>
    )
}
