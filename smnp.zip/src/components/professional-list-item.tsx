

'use client';

import Image from "next/image";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import type { Item, ItemType, Provider, Supplier, VerificationStatus } from "@/lib/types";
import { Button } from "./ui/button";
import { MapPin, Phone, MessageSquare, Star, ShieldCheck, CheckCircle, FileText, Scale } from "lucide-react";
import Link from "next/link";
import { Badge } from "./ui/badge";
import { useComparison } from "@/hooks/use-comparison";

interface ProfessionalListItemProps {
  professional: Provider | Supplier;
  itemType: 'designer' | 'constructor' | 'supplier' | 'seller' | 'broker';
}

function VerificationStatus({ status }: { status?: VerificationStatus }) {
    if (status !== 'verified') return null;

    return (
        <div className="flex items-center gap-1 text-xs text-green-700">
            <ShieldCheck className="h-4 w-4" />
            <span>Verified</span>
        </div>
    );
}


export default function ProfessionalListItem({ professional, itemType }: ProfessionalListItemProps) {
  const linkHref = `/${itemType}s/${professional.id}`;
  const telLink = professional.phone ? `tel:${professional.phone}` : null;
  const { addItem, items } = useComparison();
  const isComparing = items.some(i => i.id === professional.id);

  return (
    <Card className="w-full overflow-hidden hover:shadow-lg transition-shadow">
        <CardHeader className="bg-muted/30 p-3">
            <h3 className="font-semibold text-sm capitalize">{itemType} Services</h3>
        </CardHeader>
        <div className="grid grid-cols-1 md:grid-cols-4">
            <div className="md:col-span-1 p-4 flex justify-center items-center">
                 <Image
                    src={professional.image || 'https://picsum.photos/300/300'}
                    alt={professional.name}
                    width={150}
                    height={150}
                    className="object-cover rounded-md aspect-square"
                    data-ai-hint={professional.dataAiHint}
                />
            </div>
            <div className="md:col-span-3 p-4 flex flex-col">
                <div className="flex-1">
                    <div className="flex justify-between items-start">
                        <Link href={linkHref} className="hover:text-primary">
                            <h2 className="font-headline text-xl font-bold">{professional.name}</h2>
                        </Link>
                        <div className="flex items-center gap-1 text-sm">
                            <Star className="w-4 h-4 text-yellow-500 fill-yellow-400" />
                            <span className="font-medium">{professional.rating?.toFixed(1)}</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <MapPin className="h-4 w-4"/>
                        <span>{professional.location}</span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm mt-3">
                        {professional.gstNumber && (
                           <div className="flex items-center gap-1">
                               <CheckCircle className="h-4 w-4 text-green-600" />
                               <span>GST</span>
                           </div>
                        )}
                        <VerificationStatus status={professional.status}/>
                    </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">
                    {telLink ? (
                         <Button variant="outline" asChild>
                            <a href={telLink}>
                                <Phone className="mr-2"/> Call Now
                            </a>
                        </Button>
                    ) : (
                         <Button variant="outline" disabled>
                            <Phone className="mr-2"/> Call Now
                        </Button>
                    )}
                    <Button variant={isComparing ? 'secondary' : 'outline'} onClick={() => addItem(professional as Item, itemType)}>
                        <Scale className="mr-2"/> {isComparing ? 'Added' : 'Compare'}
                    </Button>
                    <Button asChild className="md:col-span-1 col-span-2">
                        <Link href={linkHref}>
                            <FileText className="mr-2"/> More Details
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    </Card>
  );
}
