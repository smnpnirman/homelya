
'use client';

import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue, push, serverTimestamp } from 'firebase/database';
import { useAuth } from '@/hooks/use-auth';
import type { Review } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatDistanceToNow } from 'date-fns';
import { Skeleton } from './ui/skeleton';

interface ReviewSystemProps {
  professionalId: string;
  onStatsUpdate: (average: number, count: number) => void;
}

export default function ReviewSystem({ professionalId, onStatsUpdate }: ReviewSystemProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);

  useEffect(() => {
    setLoading(true);
    const reviewsRef = ref(db, `reviews/${professionalId}`);
    const unsubscribe = onValue(reviewsRef, (snapshot) => {
      const reviewsList: Review[] = [];
      let totalRating = 0;
      let hasUserReviewed = false;
      
      if (snapshot.exists()) {
        const data = snapshot.val();
        Object.keys(data).forEach(key => {
            const review = { id: key, ...data[key] };
            reviewsList.push(review);
            totalRating += review.rating;
            if (user && review.userId === user.uid) {
              hasUserReviewed = true;
            }
        });
        reviewsList.sort((a, b) => b.timestamp - a.timestamp);
      }
      
      setReviews(reviewsList);
      setHasReviewed(hasUserReviewed);
      onStatsUpdate(reviewsList.length > 0 ? totalRating / reviewsList.length : 0, reviewsList.length);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [professionalId, user, onStatsUpdate]);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({ variant: 'destructive', title: 'You must be logged in to leave a review.' });
      return;
    }
    if (professionalId === user.uid) {
        toast({ variant: 'destructive', title: "You can't review your own profile." });
        return;
    }
    if (rating === 0) {
      toast({ variant: 'destructive', title: 'Please select a rating.' });
      return;
    }
    if (comment.trim().length < 10) {
      toast({ variant: 'destructive', title: 'Please write a comment of at least 10 characters.' });
      return;
    }
    
    setSubmitting(true);
    try {
      const reviewData = {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userImage: user.photoURL || '',
        rating,
        comment,
        timestamp: serverTimestamp(),
      };
      await push(ref(db, `reviews/${professionalId}`), reviewData);
      toast({ title: 'Review submitted!', description: 'Thank you for your feedback.' });
      setRating(0);
      setComment('');
    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to submit review.' });
    } finally {
      setSubmitting(false);
    }
  };
  
  if (loading) {
      return (
          <Card>
              <CardHeader>
                  <Skeleton className="h-6 w-1/3" />
              </CardHeader>
              <CardContent className="space-y-4">
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
              </CardContent>
          </Card>
      )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Reviews</CardTitle>
        <CardDescription>What others are saying about this professional.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {user && !hasReviewed && professionalId !== user.uid && (
          <form onSubmit={handleSubmitReview} className="space-y-4 border-b pb-6">
            <h4 className="font-semibold">Write a Review</h4>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`cursor-pointer h-6 w-6 ${
                    (hoverRating || rating) >= star
                      ? 'text-yellow-500 fill-yellow-400'
                      : 'text-gray-300'
                  }`}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => setRating(star)}
                />
              ))}
            </div>
            <Textarea
              placeholder="Share your experience..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
            <Button type="submit" disabled={submitting}>
              {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit Review
            </Button>
          </form>
        )}
        
        {reviews.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">No reviews yet. Be the first to leave a review!</p>
        ) : (
            <div className="space-y-6">
                {reviews.map(review => (
                    <div key={review.id} className="flex gap-3">
                        <Avatar className="h-10 w-10 border">
                            <AvatarImage src={review.userImage}/>
                            <AvatarFallback>{review.userName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                            <div className="flex justify-between items-center">
                                <div>
                                    <p className="font-semibold">{review.userName}</p>
                                    <p className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(review.timestamp), {addSuffix: true})}</p>
                                </div>
                                <div className="flex items-center gap-0.5">
                                    {[1, 2, 3, 4, 5].map(star => (
                                        <Star key={star} className={`h-4 w-4 ${review.rating >= star ? 'text-yellow-500 fill-yellow-400' : 'text-gray-300'}`} />
                                    ))}
                                </div>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1 whitespace-pre-wrap">{review.comment}</p>
                        </div>
                    </div>
                ))}
            </div>
        )}
      </CardContent>
    </Card>
  );
}
