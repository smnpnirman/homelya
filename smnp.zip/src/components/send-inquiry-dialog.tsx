

'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, LogIn, Send } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { Textarea } from './ui/textarea';
import { db } from '@/lib/firebase';
import { ref, push, set, serverTimestamp } from 'firebase/database';
import Link from 'next/link';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';


type SendInquiryDialogProps = {
  children: React.ReactNode;
  professionalName: string;
  professionalId: string;
  productName?: string;
};

export default function SendInquiryDialog({ children, professionalName, professionalId, productName }: SendInquiryDialogProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [countryCode, setCountryCode] = useState('+91');

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    
    const formData = new FormData(event.currentTarget);
    const phone = formData.get('phone') as string;
    const inquiryData: { [key: string]: any } = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      phone: `${countryCode}${phone}`,
      message: formData.get('message') as string,
      fromUserId: user?.uid || 'guest',
      timestamp: serverTimestamp(),
      status: 'new',
    };

    if (productName) {
      inquiryData.productName = productName;
    }
    
    try {
        const inquiriesRef = ref(db, `inquiries/${professionalId}`);
        await push(inquiriesRef, inquiryData);
        
        toast({
            title: 'Inquiry Sent!',
            description: `Your message has been successfully sent to ${professionalName}.`,
        });
        setOpen(false);
    } catch (error: any) {
        console.error("Failed to send inquiry:", error);
         toast({
            variant: "destructive",
            title: 'Failed to Send Inquiry',
            description: error.message || 'There was a problem sending your message. Please try again later.',
        });
    } finally {
        setLoading(false);
    }

  };

  const handleTriggerClick = (e: React.MouseEvent) => {
    // This stops the click from propagating to parent components like ItemCard's Link wrapper.
    e.preventDefault();
    e.stopPropagation();
    setOpen(true);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {React.cloneElement(children as React.ReactElement, { onClick: handleTriggerClick })}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[480px]">
        {!user ? (
            <>
                <DialogHeader>
                    <DialogTitle className="font-headline flex items-center gap-2">
                        <LogIn className="text-primary" /> Please Login to Continue
                    </DialogTitle>
                    <DialogDescription>
                        You need to be logged in to send an inquiry. Please log in or create an account.
                    </DialogDescription>
                </DialogHeader>
                <DialogFooter className="sm:justify-center">
                    <Button asChild>
                        <Link href="/login">Login</Link>
                    </Button>
                    <Button asChild variant="outline">
                        <Link href="/signup">Sign Up</Link>
                    </Button>
                </DialogFooter>
            </>
        ) : (
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle className="font-headline flex items-center gap-2">
              <Send className="text-primary" /> Contact {professionalName}
            </DialogTitle>
            <DialogDescription>
              Send your inquiry for {productName ? `the product "${productName}"` : 'their services'}. They will get back to you shortly.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Name
              </Label>
              <Input id="name" name="name" required className="col-span-3" defaultValue={user?.displayName ?? ''} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                Email
              </Label>
              <Input id="email" name="email" type="email" required className="col-span-3" defaultValue={user?.email ?? ''}/>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="phone" className="text-right">
                    Phone
                </Label>
                <div className="col-span-3 flex items-center">
                    <Select defaultValue={countryCode} onValueChange={setCountryCode}>
                    <SelectTrigger className="w-[100px] rounded-r-none">
                        <SelectValue placeholder="Code" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="+91">IN +91</SelectItem>
                        <SelectItem value="+971">AE +971</SelectItem>
                    </SelectContent>
                    </Select>
                    <Input id="phone" name="phone" type="tel" required className="rounded-l-none" defaultValue={user?.phoneNumber?.replace(/^\+\d{1,3}/, '') ?? ''} />
                </div>
            </div>
             <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="message" className="text-right pt-2">
                Message
              </Label>
              <Textarea id="message" name="message" required className="col-span-3" placeholder={`I am interested in ${productName ? `your product: ${productName}` : 'your services'}...`}/>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading}>
                {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending...</> : 'Send Inquiry'}
            </Button>
          </DialogFooter>
        </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
