
'use client';

import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue, query, orderByChild } from 'firebase/database';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Skeleton } from '@/components/ui/skeleton';
import { Tag, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import Autoplay from "embla-carousel-autoplay";
import { useRef } from 'react';

interface Offer {
    id: string;
    title: string;
    description: string;
    discountPercentage: number;
    applicableOn: string;
    code?: string;
    expiryDate: string;
    status: 'active' | 'hidden';
}

export default function OffersCarousel() {
    const [offers, setOffers] = useState<Offer[]>([]);
    const [loading, setLoading] = useState(true);

    const plugin = useRef(
        Autoplay({ delay: 5000, stopOnInteraction: true })
    );

    useEffect(() => {
        setLoading(true);
        const offersRef = query(ref(db, 'offers'));
        const unsubscribe = onValue(offersRef, (snapshot) => {
            const data = snapshot.val();
            const now = new Date();
            const offersList: Offer[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key]
            })).filter(offer => offer.status === 'active' && new Date(offer.expiryDate) >= now) // Filter out expired and hidden offers
              .sort((a,b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()) : []; // Sort by expiry
            setOffers(offersList);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    if (loading) {
        return (
            <section className="container">
                 <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold">Offers & Discounts</h2>
                    <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">Grab these limited-time deals on our services and products.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-48 w-full" />
                </div>
            </section>
        );
    }

    if (offers.length === 0) {
        return null;
    }

    return (
        <section className="container">
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold">Offers & Discounts</h2>
                <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">Grab these limited-time deals on our services and products.</p>
            </div>
            <Carousel
                plugins={[plugin.current]}
                opts={{
                    align: "start",
                    loop: offers.length > 3,
                }}
                className="w-full"
                onMouseEnter={plugin.current.stop}
                onMouseLeave={plugin.current.reset}
            >
                <CarouselContent>
                    {offers.map((offer) => (
                        <CarouselItem key={offer.id} className="md:basis-1/2 lg:basis-1/3">
                             <div className="p-1 h-full">
                                <Card className="bg-gradient-to-br from-accent/10 to-transparent h-full flex flex-col">
                                    <CardHeader>
                                        <CardTitle className="flex items-start justify-between">
                                            <span>{offer.title}</span>
                                            <div className="text-4xl font-bold text-accent">{offer.discountPercentage}% <span className="text-2xl">OFF</span></div>
                                        </CardTitle>
                                        <CardDescription>On {offer.applicableOn}</CardDescription>
                                    </CardHeader>
                                    <CardContent className="flex-1">
                                        <p className="text-muted-foreground text-sm">{offer.description}</p>
                                    </CardContent>
                                    <CardFooter className="flex-col items-start gap-2">
                                         {offer.code && (
                                            <div className="flex items-center gap-2">
                                                <Tag className="h-4 w-4 text-primary"/>
                                                <p className="font-semibold">Use Code: <span className="font-mono bg-muted px-2 py-1 rounded-md">{offer.code}</span></p>
                                            </div>
                                         )}
                                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                            <Calendar className="h-4 w-4"/>
                                            <span>Expires on: {format(new Date(offer.expiryDate), 'PPP')}</span>
                                        </div>
                                    </CardFooter>
                                </Card>
                             </div>
                        </CarouselItem>
                    ))}
                </CarouselContent>
                <CarouselPrevious className="hidden md:flex"/>
                <CarouselNext className="hidden md:flex"/>
            </Carousel>
        </section>
    );
}
