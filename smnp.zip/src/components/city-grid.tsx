
'use client';

import { useState } from 'react';
import { MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { Card, CardContent } from './ui/card';

type CityGridProps = {
  cities: string[];
};

const INITIAL_VISIBLE_CITIES = 8;

export default function CityGrid({ cities }: CityGridProps) {
  const [showAll, setShowAll] = useState(false);

  const visibleCities = showAll ? cities : cities.slice(0, INITIAL_VISIBLE_CITIES);

  return (
    <div className="mt-8">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {visibleCities.map((city, index) => (
            <Link key={city} href={`/location/${city.toLowerCase()}`}>
                <Card
                    className={cn(
                        "group transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg hover:bg-primary/5 hover:border-primary/20",
                        "animate-fade-in-up"
                    )}
                    style={{ animationDelay: `${index * 75}ms` }}
                >
                    <CardContent className="p-4 flex items-center gap-3">
                         <div className="bg-primary/10 text-primary rounded-lg p-2 transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                            <MapPin className="h-5 w-5" />
                        </div>
                        <span className="font-semibold text-foreground group-hover:text-primary">{city}</span>
                    </CardContent>
                </Card>
            </Link>
        ))}
      </div>
      {!showAll && cities.length > INITIAL_VISIBLE_CITIES && (
        <div className="mt-8 text-center">
          <Button onClick={() => setShowAll(true)} variant="outline">
            Show More Cities
          </Button>
        </div>
      )}
    </div>
  );
}
