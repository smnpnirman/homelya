
'use client';

import { Card, CardContent } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import Image from "next/image";
import { useEffect, useState, useRef } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue } from "firebase/database";
import type { FestivalGreeting } from "@/lib/types";
import { Skeleton } from "./ui/skeleton";
import Autoplay from "embla-carousel-autoplay"
import { Button } from "./ui/button";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function FestivalBanner() {
  const [banners, setBanners] = useState<FestivalGreeting[]>([]);
  const [loading, setLoading] = useState(true);

  const plugin = useRef(
    Autoplay({ delay: 4000, stopOnInteraction: true })
  )

  useEffect(() => {
    setLoading(true);
    const bannersRef = ref(db, 'festival-greetings');
    const unsubscribe = onValue(bannersRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        const bannersList: FestivalGreeting[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key],
        }));
        setBanners(bannersList);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <section className="container">
        <Skeleton className="h-[200px] md:h-[300px] w-full" />
      </section>
    )
  }

  if (banners.length === 0) {
    return null;
  }

  return (
    <section className="container">
        <div className="text-center mb-8">
            <h2 className="text-3xl font-bold">Festive Greetings</h2>
            <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">Wishing you joy and prosperity on every special occasion.</p>
        </div>
        <Carousel
            plugins={[plugin.current]}
            opts={{
            align: "start",
            loop: true,
            }}
            className="w-full"
            onMouseEnter={plugin.current.stop}
            onMouseLeave={plugin.current.reset}
        >
            <CarouselContent>
            {banners.map((banner) => (
                <CarouselItem key={banner.id}>
                    <div className="p-1">
                        <Card className="overflow-hidden">
                            <CardContent className="p-0">
                                <div className="relative aspect-video md:aspect-[21/9] w-full">
                                    <Image
                                        src={banner.images[0] || 'https://picsum.photos/1200/500'}
                                        alt={banner.eventName}
                                        fill
                                        className="object-cover"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/20 flex flex-col justify-center p-8 md:p-12">
                                        <h3 className="text-3xl md:text-4xl font-bold text-white">{banner.title}</h3>
                                        <p className="text-lg text-white/80 mt-2 max-w-lg">{banner.description}</p>
                                        {banner.readMoreUrl && (
                                            <div className="mt-4">
                                                <Button asChild variant="secondary">
                                                    <Link href={banner.readMoreUrl} target="_blank">
                                                        Read More <ArrowRight className="ml-2 h-4 w-4" />
                                                    </Link>
                                                </Button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </CarouselItem>
            ))}
            </CarouselContent>
            <CarouselPrevious className="hidden md:flex" />
            <CarouselNext className="hidden md:flex" />
        </Carousel>
    </section>
  );
}
