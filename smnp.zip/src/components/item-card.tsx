

'use client';

import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import type { Design, Provider, Supplier, ItemType, Property, Auction, Item, AppEvent } from "@/lib/types";
import { Button } from "./ui/button";
import { Heart, IndianRupee, MapPin, MessageSquare, Phone, ShieldCheck, FileText, Bed, Bath, Ruler, Gavel, Clock, Scale, Calendar, User, Ticket } from "lucide-react";
import { useFavorites } from "@/hooks/use-favorites";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { Badge } from "./ui/badge";
import { useEffect, useState } from "react";
import { useComparison } from "@/hooks/use-comparison";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";

type ItemCardProps = {
  item: Item;
  itemType: ItemType;
}

const ProfessionalCard = ({ item, itemType }: { item: Provider | Supplier, itemType: ItemType }) => {
    const linkHref = `/${itemType}s/${item.id}`;
    const { addItem, items } = useComparison();
    const isComparing = items.some(i => i.id === item.id);

    return (
        <Card className="flex flex-col h-full overflow-hidden transition-all hover:shadow-lg rounded-lg group">
            <CardHeader className="p-0">
                <Link href={linkHref}>
                    <Image
                        src={item.image || 'https://picsum.photos/400/300'}
                        alt={item.name}
                        width={400}
                        height={300}
                        className="object-cover w-full aspect-[4/3] group-hover:scale-105 transition-transform duration-300"
                        data-ai-hint={item.dataAiHint}
                    />
                </Link>
            </CardHeader>
            <CardContent className="flex-1 p-4 space-y-2">
                <Link href={linkHref}>
                    <CardTitle className="font-headline text-lg hover:text-primary transition-colors leading-tight">
                        {item.name}
                    </CardTitle>
                </Link>
                 <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 shrink-0" />
                    <span className="truncate">{item.location}</span>
                </div>
                {item.status === 'verified' && (
                    <div className="flex items-center gap-2 text-sm text-green-600">
                        <ShieldCheck className="h-4 w-4 shrink-0" />
                        <span>Verified</span>
                    </div>
                )}
            </CardContent>
            <CardFooter className="p-2 pt-0 grid grid-cols-2 gap-2 mt-auto">
                 <Button variant={isComparing ? "secondary" : "outline"} size="sm" onClick={() => addItem(item, itemType)}>
                    <Scale className="mr-2" /> {isComparing ? 'Added' : 'Compare'}
                </Button>
                <Button size="sm" asChild>
                    <Link href={linkHref}>
                        <FileText /> More Details
                    </Link>
                </Button>
            </CardFooter>
        </Card>
    )
}

const DesignCard = ({ item }: { item: Design }) => {
  const { isFavorite, addFavorite, removeFavorite } = useFavorites();
  const { addItem, items } = useComparison();
  const { userData } = useAuth();
  const isDubai = userData?.country === 'dubai';
  const favorite = isFavorite(item.id);
  const isComparing = items.some(i => i.id === item.id);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (favorite) {
      removeFavorite(item.id);
    } else {
      addFavorite(item.id, 'design');
    }
  };

  const handleCompareClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(item, 'design');
  }

  const linkHref = `/designs/${item.id}`;

  return (
    <Card className="flex flex-col h-full overflow-hidden transition-all hover:shadow-lg rounded-lg group">
      <CardHeader className="p-0 relative">
        <Link href={linkHref}>
            <Image
            src={item.image || 'https://picsum.photos/600/400'}
            alt={item.name}
            width={600}
            height={400}
            className="object-cover w-full aspect-video group-hover:scale-105 transition-transform duration-300"
            data-ai-hint={item.dataAiHint}
            />
        </Link>
        <Badge variant="secondary" className="absolute top-3 left-3">{item.category}</Badge>
        <div className="absolute top-3 right-3 flex flex-col gap-2">
            <Button
            size="icon"
            variant="secondary"
            className={cn("rounded-full h-9 w-9 transition-colors", 
                favorite ? 'bg-red-500 text-white hover:bg-red-600' : 'bg-background/70 hover:bg-background'
            )}
            onClick={handleFavoriteClick}
            aria-label={favorite ? 'Remove from favorites' : 'Add to favorites'}
            >
            <Heart className={cn("h-5 w-5", favorite ? 'fill-current' : '')} />
            </Button>
            <Button
                size="icon"
                variant="secondary"
                className={cn("rounded-full h-9 w-9 transition-colors", 
                    isComparing ? 'bg-primary text-white' : 'bg-background/70 hover:bg-background'
                )}
                onClick={handleCompareClick}
            >
                <Scale className="h-5 w-5" />
            </Button>
        </div>
      </CardHeader>
      <CardContent className="flex-1 p-4">
        <Link href={linkHref}>
            <CardTitle className="font-headline text-lg mb-1 hover:text-primary transition-colors">
                {item.name}
            </CardTitle>
        </Link>
        <Badge variant="outline">{item.style}</Badge>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center mt-auto">
        <span className="font-bold text-lg flex items-center">
            {item.price ? (
                <>
                    {isDubai ? <span className="font-bold mr-1">AED</span> : <IndianRupee className="h-4 w-4 -mt-1"/>}
                    {item.price.toLocaleString(isDubai ? undefined : 'en-IN')}
                </>
            ) : 'N/A'}
        </span>
        <Button asChild variant="secondary" size="sm">
            <Link href={linkHref}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}

const PropertyCard = ({ item }: { item: Property }) => {
    const linkHref = `/properties/${item.id}`;
    const { addItem, items } = useComparison();
    const { userData } = useAuth();
    const isDubai = userData?.country === 'dubai';
    const isComparing = items.some(i => i.id === item.id);
  
    return (
      <Card className="flex flex-col h-full overflow-hidden transition-all hover:shadow-lg rounded-lg group">
        <CardHeader className="p-0 relative">
          <Link href={linkHref}>
              <Image
              src={item.image || 'https://picsum.photos/600/400'}
              alt={item.name}
              width={600}
              height={400}
              className="object-cover w-full aspect-video group-hover:scale-105 transition-transform duration-300"
              data-ai-hint={item.dataAiHint}
              />
          </Link>
           <Badge className="absolute top-3 left-3">{item.propertyType}</Badge>
        </CardHeader>
        <CardContent className="flex-1 p-4 space-y-2">
          <Link href={linkHref}>
              <CardTitle className="font-headline text-lg mb-1 hover:text-primary transition-colors line-clamp-2">
                  {item.name}
              </CardTitle>
          </Link>
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><MapPin className="h-4 w-4" /> {item.location}</p>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground pt-1">
             <span className="flex items-center gap-1.5"><Bed className="h-4 w-4"/> {item.bedrooms} Beds</span>
             <span className="flex items-center gap-1.5"><Bath className="h-4 w-4"/> {item.bathrooms} Baths</span>
             <span className="flex items-center gap-1.5"><Ruler className="h-4 w-4"/> {item.area.toLocaleString('en-IN')} sqft</span>
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between items-center mt-auto">
          <span className="font-bold text-lg flex items-center">
            {item.price ? (
                <>
                    {isDubai ? <span className="font-bold mr-1">AED</span> : <IndianRupee className="h-5 w-5 -mt-1"/>}
                    {item.price.toLocaleString(isDubai ? undefined : 'en-IN')}
                </>
            ) : 'N/A'}
          </span>
          <div className="flex items-center gap-2">
            <Button variant={isComparing ? "secondary" : "outline"} size="sm" onClick={() => addItem(item, 'property')}>
                <Scale className="mr-2 h-4 w-4" /> {isComparing ? 'Added' : 'Compare'}
            </Button>
            <Button asChild variant="secondary" size="sm">
                <Link href={linkHref}>Details</Link>
            </Button>
          </div>
        </CardFooter>
      </Card>
    );
}

const AuctionCard = ({ item }: { item: Auction }) => {
    const linkHref = `/auctions/${item.id}`;
    const [timeLeft, setTimeLeft] = useState('');
    const { userData } = useAuth();
    const isDubai = userData?.country === 'dubai';

    useEffect(() => {
        const calculateTimeLeft = () => {
            const now = new Date().getTime();
            const distance = item.endTime - now;

            if (distance < 0) {
                return 'Ended';
            }
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            if (days > 0) return `${days}d left`;
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            if (hours > 0) return `${hours}h left`;
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            return `${minutes}m left`;
        };
        setTimeLeft(calculateTimeLeft());
        const timer = setInterval(() => setTimeLeft(calculateTimeLeft()), 60000); // update every minute
        return () => clearInterval(timer);
    }, [item.endTime]);

    return (
      <Card className="flex flex-col h-full overflow-hidden transition-all hover:shadow-lg rounded-lg group">
        <CardHeader className="p-0 relative">
          <Link href={linkHref}>
              <Image
              src={item.image || 'https://picsum.photos/600/400'}
              alt={item.name}
              width={600}
              height={400}
              className="object-cover w-full aspect-video group-hover:scale-105 transition-transform duration-300"
              data-ai-hint={item.dataAiHint}
              />
          </Link>
           <Badge variant="destructive" className="absolute top-3 left-3 animate-pulse"><Gavel className="mr-1.5 h-3 w-3" /> LIVE</Badge>
           <Badge className="absolute top-3 right-3"><Clock className="mr-1.5 h-3 w-3" /> {timeLeft}</Badge>
        </CardHeader>
        <CardContent className="flex-1 p-4 space-y-2">
          <Link href={linkHref}>
              <CardTitle className="font-headline text-lg mb-1 hover:text-primary transition-colors line-clamp-2">
                  {item.name}
              </CardTitle>
          </Link>
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><MapPin className="h-4 w-4" /> {item.location}</p>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between items-center mt-auto">
          <div>
            <p className="text-xs text-muted-foreground">Current Bid</p>
            <span className="font-bold text-lg flex items-center">
                {item.currentBid ? (
                    <>
                        {isDubai ? <span className="font-bold mr-1">AED</span> : <IndianRupee className="h-5 w-5 -mt-1"/>}
                        {item.currentBid.toLocaleString(isDubai ? undefined : 'en-IN')}
                    </>
                ) : 'N/A'}
            </span>
          </div>
          <Button asChild size="sm">
              <Link href={linkHref}>Place Bid</Link>
          </Button>
        </CardFooter>
      </Card>
    );
  }

const EventCard = ({ item }: { item: AppEvent }) => {
    const linkHref = `/events/${item.id}`;
    const { userData } = useAuth();
    const isDubai = userData?.country === 'dubai';
  
    return (
      <Card className="flex flex-col h-full overflow-hidden transition-all hover:shadow-lg rounded-lg group">
        <CardHeader className="p-0 relative">
          <Link href={linkHref}>
              <Image
              src={item.image || 'https://picsum.photos/600/400'}
              alt={item.name}
              width={600}
              height={400}
              className="object-cover w-full aspect-video group-hover:scale-105 transition-transform duration-300"
              data-ai-hint={item.dataAiHint}
              />
          </Link>
           <Badge className="absolute top-3 left-3 capitalize">{item.eventType}</Badge>
        </CardHeader>
        <CardContent className="flex-1 p-4 space-y-2">
          <Link href={linkHref}>
              <CardTitle className="font-headline text-lg mb-1 hover:text-primary transition-colors line-clamp-2">
                  {item.name}
              </CardTitle>
          </Link>
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><Calendar className="h-4 w-4" /> {format(new Date(item.eventDate), 'PPP')}</p>
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><User className="h-4 w-4" /> {item.professionalName}</p>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between items-center mt-auto">
          <span className="font-bold text-lg flex items-center">
              {item.ticketPrice > 0 ? (
                    isDubai ? <span>AED {item.ticketPrice.toLocaleString()}</span> : <><IndianRupee className="h-5 w-5 -mt-1"/>{item.ticketPrice.toLocaleString('en-IN')}</>
              ) : 'Free'}
          </span>
          <Button asChild size="sm" variant="secondary">
              <Link href={linkHref}><Ticket className="mr-2 h-4 w-4" /> Book Now</Link>
          </Button>
        </CardFooter>
      </Card>
    );
}

export default function ItemCard({ item, itemType }: ItemCardProps) {
    if (itemType === 'design') {
        return <DesignCard item={item as Design} />;
    }
    if (itemType === 'designer' || itemType === 'constructor' || itemType === 'supplier' || itemType === 'seller' || itemType === 'broker') {
        return <ProfessionalCard item={item as Provider | Supplier} itemType={itemType} />;
    }
    if (itemType === 'property') {
        return <PropertyCard item={item as Property} />
    }
    if (itemType === 'auction') {
        return <AuctionCard item={item as Auction} />
    }
    if (itemType === 'event') {
        return <EventCard item={item as AppEvent} />
    }
    return null;
}
