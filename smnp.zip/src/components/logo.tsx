
import { cn } from "@/lib/utils";
import Image from "next/image";

export default function Logo({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <Image 
        src="https://i.ibb.co/5XV6JpDw/Minimal-and-Elegant-Real-Estate-Logo-Template-20251205-181849-0000.png"
        alt="Homelya Logo"
        width={56}
        height={56}
        className="rounded-md"
      />
      <span className="font-headline text-3xl font-bold text-foreground">
        Homelya
      </span>
    </div>
  );
}
