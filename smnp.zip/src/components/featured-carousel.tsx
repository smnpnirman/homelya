
'use client';

import type { Item, ItemType } from "@/lib/types";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "./ui/carousel";
import ItemCard from "./item-card";
import { Skeleton } from "./ui/skeleton";
import { Button } from "./ui/button";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Autoplay from "embla-carousel-autoplay"
import { useRef } from "react";


interface FeaturedCarouselProps<T extends Item> {
    title: string;
    viewAllLink: string;
    items: T[];
    itemType: ItemType;
    loading: boolean;
    skeletons: number;
}

export default function FeaturedCarousel<T extends Item>({ title, viewAllLink, items, itemType, loading, skeletons }: FeaturedCarouselProps<T>) {

    const plugin = useRef(
        Autoplay({ delay: 3000, stopOnInteraction: true })
    );

    if (loading) {
        return (
             <section className="container">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold">{title}</h2>
                    <Button asChild variant="ghost">
                        <Link href={viewAllLink}>
                        View All <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                    </Button>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {Array.from({ length: skeletons }).map((_, i) => (
                    <div key={i} className="space-y-2">
                        <Skeleton className="h-48 w-full" />
                        <Skeleton className="h-6 w-3/4" />
                        <Skeleton className="h-4 w-1/2" />
                        <Skeleton className="h-10 w-full" />
                    </div>
                    ))}
                 </div>
             </section>
        )
    }

    if (items.length === 0) return null;

    return (
        <section className="container">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold">{title}</h2>
                <Button asChild variant="ghost" className="hidden md:inline-flex">
                    <Link href={viewAllLink}>
                    View All <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                </Button>
            </div>
            <Carousel 
                plugins={[plugin.current]}
                opts={{
                    align: "start",
                    loop: items.length > 4,
                }}
                className="w-full"
                onMouseEnter={plugin.current.stop}
                onMouseLeave={plugin.current.reset}
            >
                <CarouselContent>
                    {items.map((item) => (
                        <CarouselItem key={item.id} className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                             <div className="p-1 h-full">
                                <ItemCard item={item} itemType={itemType} />
                             </div>
                        </CarouselItem>
                    ))}
                </CarouselContent>
                <CarouselPrevious className="hidden md:flex"/>
                <CarouselNext className="hidden md:flex"/>
            </Carousel>
             <div className="mt-4 text-center md:hidden">
                <Button asChild variant="outline">
                    <Link href={viewAllLink}>
                        View All {title}
                    </Link>
                </Button>
            </div>
        </section>
    );
}

