
'use client';

import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue, query, orderByChild, equalTo } from 'firebase/database';
import type { Advertisement } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import Image from 'next/image';
import { Button } from './ui/button';
import Link from 'next/link';
import { Megaphone, ArrowRight } from 'lucide-react';
import { Skeleton } from './ui/skeleton';

interface AdBannerProps {
  targetLocation?: string;
}

export default function AdBanner({ targetLocation }: AdBannerProps) {
  const [ad, setAd] = useState<Advertisement | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const adsQuery = query(
      ref(db, 'advertisements'),
      orderByChild('status'),
      equalTo('active')
    );

    const unsubscribe = onValue(adsQuery, (snapshot) => {
      if (snapshot.exists()) {
        const activeAds: Advertisement[] = Object.values(snapshot.val());
        
        let relevantAds = activeAds;
        if (targetLocation) {
          const locationSpecificAds = activeAds.filter(ad => ad.targetLocation.toLowerCase() === targetLocation.toLowerCase());
          if (locationSpecificAds.length > 0) {
            relevantAds = locationSpecificAds;
          }
        }
        
        // Pick a random ad from the relevant list
        const randomAd = relevantAds[Math.floor(Math.random() * relevantAds.length)];
        setAd(randomAd);
      } else {
        setAd(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [targetLocation]);

  if (loading) {
    return <Skeleton className="h-40 w-full" />;
  }

  if (!ad) {
    return null; // Don't render anything if there's no active ad
  }

  return (
    <Card className="overflow-hidden w-full">
      <CardContent className="p-0">
        <div className="relative aspect-[4/1] w-full">
          <Image
            src={ad.adImage}
            alt={ad.campaignName}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30 flex items-center justify-between p-6 md:p-8">
            <div className="text-white max-w-2xl">
              <div className="flex items-center gap-2 text-sm font-semibold text-yellow-300">
                <Megaphone className="h-4 w-4" />
                <span>Sponsored</span>
              </div>
              <h3 className="text-xl md:text-2xl font-bold mt-2">{ad.professionalName}</h3>
              <p className="text-md text-white/80 mt-1 hidden md:block">{ad.adCopy}</p>
            </div>
            <Button asChild variant="secondary" className="hidden sm:inline-flex">
              <Link href={ad.ctaLink}>
                Learn More <ArrowRight className="ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
