
'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from './ui/textarea';
import { Bot, Loader2, Send, Mic, BookOpen } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { vastuChat, VastuChatOutput } from '@/ai/flows/vastu-chat-flow';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import Logo from './logo';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
  TooltipProvider,
} from "@/components/ui/tooltip";


const VastuIcon = () => (
    <div className="relative h-12 w-12">
        <div className="absolute inset-0 rounded-full bg-accent animate-ping"></div>
        <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="absolute inset-0"
        >
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
            <polyline points="9 22 9 12 15 12 15 22"></polyline>
        </svg>
        <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="absolute inset-0 opacity-70"
        >
            <circle cx="12" cy="12" r="2"></circle>
            <line x1="12" y1="9" x2="12" y2="3"></line>
            <line x1="12" y1="21" x2="12" y2="15"></line>
            <line x1="15" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="12" x2="9" y2="12"></line>
        </svg>
    </div>
);

type Message = {
    type: 'user' | 'ai';
    text: string;
    references?: string[];
}

export default function VastuChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [language, setLanguage] = useState<'english' | 'hindi'>('english');
  const { toast } = useToast();
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;

      recognitionRef.current.onstart = () => setIsListening(true);
      recognitionRef.current.onresult = (event: any) => setQuestion(event.results[0][0].transcript);
      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        toast({ variant: 'destructive', title: 'Voice Error', description: `Could not process audio: ${event.error}` });
      };
      recognitionRef.current.onend = () => setIsListening(false);
    }
  }, [toast]);
  
  useEffect(() => {
      if (recognitionRef.current) {
          recognitionRef.current.lang = language === 'hindi' ? 'hi-IN' : 'en-US';
      }
  }, [language]);


  const handleToggleListening = () => {
    if (!recognitionRef.current) {
      toast({ variant: 'destructive', title: 'Not Supported', description: 'Your browser does not support voice recognition.' });
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        recognitionRef.current.start();
      } catch (error) {
        console.error("Could not start recognition:", error)
        toast({ variant: 'destructive', title: 'Mic Error', description: 'Could not start voice recognition. Please check permissions.' });
      }
    }
  };


  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    const userMessage = { type: 'user' as const, text: question };
    setConversation(prev => [...prev, userMessage]);
    setLoading(true);
    setQuestion('');

    try {
      const result: VastuChatOutput = await vastuChat({ question, language });
      const aiMessage = { type: 'ai' as const, text: result.answer, references: result.references };
      setConversation(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Vastu Chat Error:', error);
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: 'Failed to get a response from the Vastu expert.',
      });
      const errorMessage = { type: 'ai' as const, text: "I'm sorry, but I'm unable to provide a response at this moment." };
       setConversation(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <TooltipProvider>
        <Tooltip>
            <TooltipTrigger asChild>
                <Button
                    size="icon"
                    className="fixed bottom-6 right-6 h-20 w-20 rounded-full shadow-lg z-50 bg-gradient-to-tr from-primary to-accent overflow-visible"
                    onClick={() => setIsOpen(true)}
                >
                    <VastuIcon />
                    <span className="sr-only">Open Vastu Chat</span>
                </Button>
            </TooltipTrigger>
            <TooltipContent>
                <p>AI Vastu Expert</p>
            </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md p-0 flex flex-col h-[70vh]">
          <DialogHeader className="p-4 border-b">
            <div className="flex justify-between items-center">
                <DialogTitle className="flex items-center gap-2 font-headline">
                <Bot /> AI Vastu Expert
                </DialogTitle>
                 <div className="flex items-center space-x-2">
                    <Label htmlFor="language-toggle">English</Label>
                    <Switch
                        id="language-toggle"
                        checked={language === 'hindi'}
                        onCheckedChange={(checked) => setLanguage(checked ? 'hindi' : 'english')}
                    />
                    <Label htmlFor="language-toggle">Hindi</Label>
                </div>
            </div>
            <DialogDescription>Ask any question about Vastu Shastra for your home.</DialogDescription>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
             {conversation.length === 0 ? (
                <div className="text-center text-muted-foreground pt-12">
                    <p>e.g., "Where should the main entrance be?"</p>
                    <p>or "What is the best direction for the master bedroom?"</p>
                </div>
             ) : (
                conversation.map((msg, index) => (
                    <div key={index} className={`flex items-end gap-2 ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                        {msg.type === 'ai' && (
                            <Avatar className="h-8 w-8 border self-start">
                                <AvatarImage src="https://i.ibb.co/CpSdyCyY/IMG-20250824-195931.jpg" />
                                <AvatarFallback>AI</AvatarFallback>
                            </Avatar>
                        )}
                         <div className="max-w-[80%]">
                            <div className={`rounded-lg px-3 py-2 ${msg.type === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                            </div>
                            {msg.type === 'ai' && msg.references && msg.references.length > 0 && (
                                <div className="mt-2 text-xs text-muted-foreground space-y-1">
                                    <h4 className="font-semibold flex items-center gap-1.5"><BookOpen className="h-3.5 w-3.5" /> References:</h4>
                                    <ul className="list-disc list-inside">
                                        {msg.references.map((ref, i) => <li key={i}>{ref}</li>)}
                                    </ul>
                                </div>
                            )}
                         </div>
                    </div>
                ))
             )}
              {loading && (
                <div className="flex items-end gap-2 justify-start">
                    <Avatar className="h-8 w-8 border">
                        <AvatarImage src="https://i.ibb.co/CpSdyCyY/IMG-20250824-195931.jpg" />
                        <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                    <div className="bg-muted rounded-lg px-3 py-2">
                        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                    </div>
                </div>
            )}
          </div>

          <DialogFooter className="p-4 border-t">
            <form onSubmit={handleSendMessage} className="w-full flex items-center gap-2">
              <div className="relative flex-1">
                 <Input
                    placeholder="Ask a Vastu question..."
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    disabled={loading}
                    autoComplete="off"
                    className="pr-10"
                  />
                  <Button 
                    type="button" 
                    size="icon" 
                    variant="ghost" 
                    className={`absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 ${isListening ? 'text-red-500' : ''}`}
                    onClick={handleToggleListening}
                  >
                    <Mic className="h-4 w-4" />
                    <span className="sr-only">Use microphone</span>
                  </Button>
              </div>
              <Button type="submit" size="icon" disabled={loading || !question.trim()}>
                <Send className="h-4 w-4" />
                <span className="sr-only">Send</span>
              </Button>
            </form>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
