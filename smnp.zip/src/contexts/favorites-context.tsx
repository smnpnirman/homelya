'use client';

import type { ItemType } from '@/lib/types';
import React, { createContext, useState, useEffect, useCallback } from 'react';

interface FavoriteItem {
  id: string;
  type: ItemType;
}

interface FavoritesContextType {
  favorites: FavoriteItem[];
  addFavorite: (id: string, type: ItemType) => void;
  removeFavorite: (id:string) => void;
  isFavorite: (id: string) => boolean;
}

export const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'homelya-favorites';

export const FavoritesProvider = ({ children }: { children: React.ReactNode }) => {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    try {
      const storedFavorites = window.localStorage.getItem(LOCAL_STORAGE_KEY);
      if (storedFavorites) {
        setFavorites(JSON.parse(storedFavorites));
      }
    } catch (error) {
      console.error("Could not read favorites from localStorage", error);
    }
  }, []);

  const updateLocalStorage = (updatedFavorites: FavoriteItem[]) => {
    try {
      window.localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedFavorites));
    } catch (error) {
      console.error("Could not save favorites to localStorage", error);
    }
  };

  const addFavorite = useCallback((id: string, type: ItemType) => {
    setFavorites(prevFavorites => {
      const newFavorites = [...prevFavorites, { id, type }];
      updateLocalStorage(newFavorites);
      return newFavorites;
    });
  }, []);

  const removeFavorite = useCallback((id: string) => {
    setFavorites(prevFavorites => {
      const newFavorites = prevFavorites.filter(fav => fav.id !== id);
      updateLocalStorage(newFavorites);
      return newFavorites;
    });
  }, []);

  const isFavorite = useCallback((id: string) => {
    return favorites.some(fav => fav.id === id);
  }, [favorites]);

  return (
    <FavoritesContext.Provider value={{ favorites, addFavorite, removeFavorite, isFavorite }}>
      {children}
    </FavoritesContext.Provider>
  );
};
