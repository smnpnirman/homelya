
'use client';

import { useAuth } from '@/hooks/use-auth';
import { db } from '@/lib/firebase';
import { onValue, ref, remove, set } from 'firebase/database';
import React, { createContext, useState, useEffect, useCallback, ReactNode } from 'react';

interface FollowContextType {
  following: string[];
  follow: (professionalId: string) => void;
  unfollow: (professionalId: string) => void;
  isFollowing: (professionalId: string) => boolean;
}

export const FollowContext = createContext<FollowContextType | undefined>(undefined);

export const FollowProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const [following, setFollowing] = useState<string[]>([]);

  useEffect(() => {
    if (user) {
      const followsRef = ref(db, `user-follows/${user.uid}`);
      const unsubscribe = onValue(followsRef, (snapshot) => {
        if (snapshot.exists()) {
          setFollowing(Object.keys(snapshot.val()));
        } else {
          setFollowing([]);
        }
      });
      return () => unsubscribe();
    } else {
      setFollowing([]);
    }
  }, [user]);

  const follow = useCallback((professionalId: string) => {
    if (!user) return;
    const followRef = ref(db, `user-follows/${user.uid}/${professionalId}`);
    set(followRef, true);
    const followerRef = ref(db, `professional-followers/${professionalId}/${user.uid}`);
    set(followerRef, true);
  }, [user]);

  const unfollow = useCallback((professionalId: string) => {
    if (!user) return;
    const followRef = ref(db, `user-follows/${user.uid}/${professionalId}`);
    remove(followRef);
    const followerRef = ref(db, `professional-followers/${professionalId}/${user.uid}`);
    remove(followerRef);
  }, [user]);

  const isFollowing = useCallback((professionalId: string) => {
    return following.includes(professionalId);
  }, [following]);

  return (
    <FollowContext.Provider value={{ following, follow, unfollow, isFollowing }}>
      {children}
    </FollowContext.Provider>
  );
};
