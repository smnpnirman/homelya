
'use client';

import type { Item, ItemType } from '@/lib/types';
import React, { createContext, useState, useCallback, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

interface ComparisonContextType {
  items: Item[];
  addItem: (item: Item, type: ItemType) => void;
  removeItem: (id: string) => void;
  clearAll: () => void;
  itemType: ItemType | null;
}

export const ComparisonContext = createContext<ComparisonContextType | undefined>(undefined);

const MAX_COMPARE_ITEMS = 3;

const getComparisonGroup = (type: ItemType): string => {
    if (['designer', 'constructor', 'supplier', 'seller', 'broker'].includes(type)) {
        return 'professional';
    }
    return type;
}

export const ComparisonProvider = ({ children }: { children: React.ReactNode }) => {
  const [items, setItems] = useState<Item[]>([]);
  const [itemType, setItemType] = useState<ItemType | null>(null);
  const { toast } = useToast();

  const addItem = useCallback((item: Item, type: ItemType) => {
    const newComparisonGroup = getComparisonGroup(type);
    const currentComparisonGroup = itemType ? getComparisonGroup(itemType) : null;

    if (currentComparisonGroup && newComparisonGroup !== currentComparisonGroup) {
      setItems([item]);
      setItemType(type);
      toast({
        title: 'Comparison items cleared',
        description: `You can only compare items of a similar category. Your comparison list has been updated.`,
      });
      return;
    }

    if (items.find(i => i.id === item.id)) {
      toast({
        title: 'Already in comparison',
        description: `${item.name} is already added for comparison.`,
      });
      return;
    }
    
    if (items.length >= MAX_COMPARE_ITEMS) {
       toast({
        variant: 'destructive',
        title: 'Comparison limit reached',
        description: `You can only compare up to ${MAX_COMPARE_ITEMS} items at a time.`,
      });
      return;
    }
    
    if (items.length === 0) {
      setItemType(type);
    }
    toast({
      title: 'Added to comparison',
      description: `${item.name} has been added for comparison.`,
    });
    setItems(prevItems => [...prevItems, item]);
  }, [items, itemType, toast]);

  const removeItem = useCallback((id: string) => {
    setItems(prevItems => {
        const newItems = prevItems.filter(item => item.id !== id);
        if (newItems.length === 0) {
            setItemType(null);
        }
        return newItems;
    });
  }, []);
  
  const clearAll = useCallback(() => {
      setItems([]);
      setItemType(null);
  }, []);

  return (
    <ComparisonContext.Provider value={{ items, addItem, removeItem, clearAll, itemType }}>
      {children}
    </ComparisonContext.Provider>
  );
};
