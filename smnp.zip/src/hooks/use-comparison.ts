
'use client';

import { ComparisonContext } from '@/contexts/comparison-context';
import { useContext } from 'react';

export const useComparison = () => {
  const context = useContext(ComparisonContext);
  if (context === undefined) {
    throw new Error('useComparison must be used within a ComparisonProvider');
  }
  return context;
};
