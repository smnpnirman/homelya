
'use client';

import { FollowContext } from '@/contexts/follow-context';
import { useContext } from 'react';

export const useFollow = () => {
  const context = useContext(FollowContext);
  if (context === undefined) {
    throw new Error('useFollow must be used within a FollowProvider');
  }
  return context;
};
