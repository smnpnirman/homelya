
'use client';

import { useState, useMemo, useEffect, useCallback } from 'react';
import PageHeader from '@/components/page-header';
import ProfessionalListItem from '@/components/professional-list-item';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search } from 'lucide-react';
import { db } from '@/lib/firebase';
import { ref, onValue, set, push, serverTimestamp } from 'firebase/database';
import type { Provider } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import AdBanner from '@/components/ad-banner';

export default function SellersPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const [sellers, setSellers] = useState<Provider[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  const [specialtyFilter, setSpecialtyFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');

  useEffect(() => {
    setLoading(true);
    const usersRef = ref(db, 'users');
    const unsubscribe = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const allUsers: any[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        
        const sellersList: Provider[] = allUsers
          .filter(user => user.role === 'seller')
          .map(user => ({
            id: user.id,
            name: user.companyName,
            specialty: user.specialty || 'Real Estate',
            location: user.location || 'Not specified',
            description: user.description || 'No description available.',
            image: user.image || 'https://picsum.photos/300/300',
            dataAiHint: 'real estate agent',
            rating: 4.5 + Math.random() * 0.5, // Placeholder rating
            status: user.status || 'in-progress',
            phone: user.phone,
        }));

        setSellers(sellersList);
      } else {
        setSellers([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const sellerSpecialties = useMemo(() => [...new Set(sellers.map((d) => d.specialty))], [sellers]);
  const sellerLocations = useMemo(() => [...new Set(sellers.map((d) => d.location))], [sellers]);

  const generateLeadsForMasters = useCallback((location: string, masterProfessionals: Provider[]) => {
    if (!user || !location || masterProfessionals.length === 0) return;
    
    const currentUserIsProfessional = masterProfessionals.some(p => p.id === user.uid);
    if(currentUserIsProfessional) return;

    masterProfessionals.forEach(prof => {
        const leadRef = ref(db, `leads/${prof.id}`);
        const newLeadRef = push(leadRef);
        set(newLeadRef, {
            userName: user.displayName,
            userEmail: user.email,
            userPhone: user.phoneNumber || '',
            searchedLocation: location,
            timestamp: serverTimestamp(),
        }).catch(err => console.error("Failed to generate lead for", prof.id, err));
    });

    toast({
        title: "Master Professionals Notified",
        description: `Top professionals in ${location} have been notified of your interest.`,
    });

  }, [user, toast]);

  const filteredSellers = useMemo(() => {
    const filtered = sellers.filter((seller) => {
      const searchMatch = seller.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          seller.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          seller.specialty?.toLowerCase().includes(searchTerm.toLowerCase());
      const specialtyMatch = specialtyFilter === 'all' || seller.specialty === specialtyFilter;
      const locationMatch = locationFilter === 'all' || seller.location === locationFilter;
      return searchMatch && specialtyMatch && locationMatch;
    });

    if (locationFilter !== 'all') {
        const masterProfessionalsInLocation = filtered.filter(d => d.status === 'master');
        if (masterProfessionalsInLocation.length > 0) {
            generateLeadsForMasters(locationFilter, masterProfessionalsInLocation);
        }
    }
    
    return filtered;

  }, [searchTerm, specialtyFilter, locationFilter, sellers, generateLeadsForMasters]);

  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
       <Skeleton key={i} className="h-48 w-full" />
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader
        title="Find a Property Seller"
        description="Connect with trusted real estate professionals to buy or sell property."
      />
      
      <AdBanner targetLocation={locationFilter !== 'all' ? locationFilter : undefined} />

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search sellers by name, specialty..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={specialtyFilter} onValueChange={setSpecialtyFilter} disabled={loading}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by specialty" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Specialties</SelectItem>
            {sellerSpecialties.map(specialty => (
              <SelectItem key={specialty} value={specialty}>{specialty}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={locationFilter} onValueChange={setLocationFilter} disabled={loading}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by location" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Locations</SelectItem>
            {sellerLocations.map(location => (
              <SelectItem key={location} value={location}>{location}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-6">
        {loading ? renderSkeletons() : filteredSellers.map((seller) => (
          <ProfessionalListItem key={seller.id} professional={seller} itemType="seller" />
        ))}
      </div>
      {!loading && filteredSellers.length === 0 && (
        <div className="text-center col-span-full py-12">
            <h3 className="font-headline text-xl font-semibold">No Sellers Found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters, or check back later.</p>
        </div>
       )}
    </div>
  );
}
