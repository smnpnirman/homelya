
'use client';

import { useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, MapPin, Send, MessageCircle, ShieldCheck, ShieldAlert, Link as LinkIcon, FileText, Linkedin, Twitter, Instagram, Facebook, UserPlus, Briefcase, Award, Phone, Mail, Gem, Building, Camera, Info, Video, Gavel } from 'lucide-react';
import PageHeader from '@/components/page-header';
import ItemCard from '@/components/item-card';
import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, get, query, orderByChild, equalTo, onValue } from 'firebase/database';
import type { Provider, Property, Auction, VerificationStatus } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import SendInquiryDialog from '@/components/send-inquiry-dialog';
import ShareButton from '@/components/share-button';
import { useFollow } from '@/hooks/use-follow';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getYouTubeEmbedUrl, getInstagramEmbedUrl } from '@/lib/utils';


function getEmbedUrl(url: string | undefined): string | null {
    if (!url) return null;
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname.includes('google.com') && urlObj.pathname.includes('/maps/place/')) {
            const place = urlObj.pathname.split('/place/')[1];
            return `https://maps.google.com/maps?q=${decodeURIComponent(place)}&t=&z=13&ie=UTF8&iwloc=&output=embed`;
        }
    } catch (e) {
        // invalid url
    }
    return url;
}

const VideoEmbed = ({ url }: { url: string }) => {
    const youtubeUrl = getYouTubeEmbedUrl(url);
    if (youtubeUrl) {
        return (
            <iframe
                src={youtubeUrl}
                width="100%"
                className="aspect-video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
            ></iframe>
        );
    }
    
    const instagramUrl = getInstagramEmbedUrl(url);
    if (instagramUrl) {
         return (
             <iframe 
                src={instagramUrl}
                width="100%"
                className="aspect-[9/16] sm:aspect-video"
                frameBorder="0"
                allowFullScreen
            ></iframe>
         );
    }

    return <p>Invalid video URL.</p>;
}

function VerificationBadge({ status }: { status?: VerificationStatus }) {
    if (!status || status === 'rejected') return null;

    if (status === 'verified') {
        return (
            <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700">
                <ShieldCheck className="h-4 w-4 mr-1" />
                Verified
            </Badge>
        );
    }
    
    if (status === 'master') {
        return (
            <Badge variant="secondary" className="border-purple-500/50 bg-purple-500/10 text-purple-700">
                <Gem className="h-4 w-4 mr-1" />
                Master Professional
            </Badge>
        );
    }

    if (status === 'in-progress' || status === 'payment-pending' || status === 'master-payment-pending') {
        return (
            <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700">
                <ShieldAlert className="h-4 w-4 mr-1" />
                In Process
            </Badge>
        );
    }

    return null;
}

const DefaultLayout = ({ seller, properties, auctions, embedUrl, whatsappLink, socials, skillsList, galleryImages, user, isFollowed, handleFollow, followerCount }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", seller.theme === 'dark' && 'theme-dark')}>
        <section className="bg-gradient-to-b from-muted/30 to-background">
            <div className="container py-8 md:py-12">
                <div className="flex flex-col md:flex-row items-start gap-6 md:gap-8">
                    <Image
                        src={seller.image}
                        alt={seller.name}
                        width={150}
                        height={150}
                        className="rounded-lg object-contain aspect-square border-4 border-background bg-background shadow-lg"
                        data-ai-hint={seller.dataAiHint}
                    />
                    <div className="space-y-2 flex-1 pt-2">
                        <div className="flex items-center gap-4 flex-wrap">
                            <PageHeader title={seller.name} className="p-0" />
                            <VerificationBadge status={seller.status}/>
                        </div>
                        <div className="flex items-center gap-4 flex-wrap text-sm text-muted-foreground">
                            <div className="flex items-center gap-1.5">
                                <Star className="w-4 h-4 text-yellow-500 fill-yellow-400" />
                                <span className="font-bold">{seller.rating}</span>
                                <span>(24 reviews)</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                                <UserPlus className="w-4 h-4 text-primary" />
                                <span className="font-bold">{followerCount}</span>
                                <span>Followers</span>
                            </div>
                        </div>
                        {seller.gstNumber && <Badge variant="outline">GST: {seller.gstNumber}</Badge>}
                        <div className="flex items-center gap-2 pt-2">
                            {socials && Object.values(socials).some(s => s) && (
                                <div className="flex items-center gap-1">
                                    {socials.linkedin && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#0077B5]"><Link href={socials.linkedin} target="_blank"><Linkedin className="h-5 w-5"/></Link></Button>}
                                    {socials.twitter && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1DA1F2]"><Link href={socials.twitter} target="_blank"><Twitter className="h-5 w-5"/></Link></Button>}
                                    {socials.instagram && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#E4405F]"><Link href={socials.instagram} target="_blank"><Instagram className="h-5 w-5"/></Link></Button>}
                                    {socials.facebook && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1877F2]"><Link href={socials.facebook} target="_blank"><Facebook className="h-5 w-5"/></Link></Button>}
                                    <Separator orientation="vertical" className="h-6 mx-2" />
                                </div>
                            )}
                            <ShareButton title={seller.name} text={`Check out ${seller.name} on Homelya.`} />
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div className="container space-y-8 md:space-y-12">
            <div className="grid lg:grid-cols-3 gap-8 md:gap-12 items-start">
            <div className="lg:col-span-2 space-y-8 md:space-y-12">
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline">About {seller.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground whitespace-pre-wrap">{seller.description}</p>
                    </CardContent>
                </Card>

                {seller.profileVideoUrl && (
                  <section>
                    <h2 className="font-headline text-2xl font-bold mb-4">Profile Video</h2>
                    <Card>
                      <CardContent className="p-0 aspect-video rounded-lg overflow-hidden">
                        <VideoEmbed url={seller.profileVideoUrl}/>
                      </CardContent>
                    </Card>
                  </section>
                )}

                {galleryImages.length > 0 && (
                    <section>
                        <h2 className="font-headline text-2xl font-bold mb-4">Gallery</h2>
                        <Carousel className="w-full">
                            <CarouselContent>
                            {galleryImages.map((imgUrl: string, index: number) => (
                                <CarouselItem key={index} className="md:basis-1/2">
                                    <div className="p-1">
                                        <Card className="overflow-hidden">
                                            <CardContent className="p-0 aspect-video">
                                                <Image src={imgUrl} alt={`Gallery image ${index + 1}`} width={600} height={400} className="object-cover w-full h-full" />
                                            </CardContent>
                                        </Card>
                                    </div>
                                </CarouselItem>
                            ))}
                            </CarouselContent>
                            <CarouselPrevious />
                            <CarouselNext />
                        </Carousel>
                    </section>
                )}
                
                {properties.length > 0 && (
                    <section>
                        <h2 className="font-headline text-2xl font-bold mb-4">Properties for Sale</h2>
                        <div className="grid sm:grid-cols-2 gap-6">
                            {properties.map((property: Property) => (
                            <ItemCard key={property.id} item={property} itemType="property" />
                            ))}
                        </div>
                    </section>
                )}

                {auctions.length > 0 && (
                    <section>
                        <h2 className="font-headline text-2xl font-bold mb-4">Live Auctions</h2>
                        <div className="grid sm:grid-cols-2 gap-6">
                            {auctions.map((auction: Auction) => (
                            <ItemCard key={auction.id} item={auction} itemType="auction" />
                            ))}
                        </div>
                    </section>
                )}
            </div>
            <div className="lg:sticky top-6 space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline">Contact & Connect</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                         {seller.status === 'master' && (
                            <>
                                <SendInquiryDialog professionalName={seller.name} professionalId={seller.id}>
                                    <Button size="lg" className="w-full">
                                        <Send className="mr-2" /> Send Inquiry
                                    </Button>
                                </SendInquiryDialog>
                                {whatsappLink && (
                                    <Button size="lg" variant="outline" asChild className="w-full">
                                        <Link href={whatsappLink} target="_blank">
                                            <MessageCircle className="mr-2" /> Chat on WhatsApp
                                        </Link>
                                    </Button>
                                )}
                            </>
                        )}
                        {user && user.uid !== seller.id && (
                            <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow} className="w-full">
                                <UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}
                            </Button>
                        )}
                        {seller.catalogPdfUrl && (
                            <Button size="lg" variant="outline" asChild className="w-full">
                                <Link href={seller.catalogPdfUrl} target="_blank">
                                    <FileText className="mr-2" /> View Catalog (PDF)
                                </Link>
                            </Button>
                        )}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline text-lg">Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 text-sm">
                        <div className="flex items-center gap-3">
                            <Badge variant="secondary">{seller.specialty}</Badge>
                            {seller.experienceLevel && <Badge variant="outline">{seller.experienceLevel}</Badge>}
                        </div>
                        <Separator />
                        <div className="flex items-start gap-3">
                            <MapPin className="h-4 w-4 text-primary mt-1" />
                            <div className="flex-1">
                                <h4 className="font-semibold">Location</h4>
                                <p className="text-muted-foreground">{seller.locationUrl ? (
                                    <Link href={seller.locationUrl} target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-primary transition-colors">
                                        {seller.location}
                                    </Link>
                                    ) : (
                                    <span>{seller.location}</span>
                                )}</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Phone className="h-4 w-4 text-primary mt-1" />
                            <div className="flex-1">
                                <h4 className="font-semibold">Phone</h4>
                                <p className="text-muted-foreground">{seller.phone ? (
                                    <a href={`tel:${seller.phone}`} className="hover:underline">{seller.phone}</a>
                                ) : 'Not Available'}</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Mail className="h-4 w-4 text-primary mt-1" />
                            <div className="flex-1">
                                <h4 className="font-semibold">Email</h4>
                                <p className="text-muted-foreground">{seller.email ? (
                                    <a href={`mailto:${seller.email}`} className="hover:underline">{seller.email}</a>
                                ) : 'Not Available'}</p>
                            </div>
                        </div>
                        {seller.website && (
                            <div className="flex items-start gap-3">
                                <LinkIcon className="h-4 w-4 text-primary mt-1" />
                                <div className="flex-1">
                                    <h4 className="font-semibold">Website</h4>
                                    <p className="text-muted-foreground">
                                        <Link href={seller.website} target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-primary transition-colors truncate">
                                            {seller.website.replace(/^(https?:\/\/)?(www\.)?/, '')}
                                        </Link>
                                    </p>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {seller.workHistory && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline flex items-center gap-2 text-xl"><Briefcase /> Work History</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground whitespace-pre-wrap">{seller.workHistory}</p>
                        </CardContent>
                    </Card>
                )}

                {skillsList && skillsList.length > 0 && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline flex items-center gap-2 text-xl"><Award /> Skills & Expertise</CardTitle>
                        </CardHeader>
                        <CardContent className="flex flex-wrap gap-2">
                            {skillsList.map((skill: string) => <Badge key={skill} variant="secondary">{skill}</Badge>)}
                        </CardContent>
                    </Card>
                )}

                {embedUrl && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline text-lg">Location on Map</CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="aspect-square w-full rounded-b-lg overflow-hidden">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    loading="lazy"
                                    allowFullScreen
                                    src={embedUrl}>
                                </iframe>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
            </div>
        </div>
    </div>
);

const ModernLayout = ({ seller, properties, auctions, whatsappLink, socials, galleryImages, user, isFollowed, handleFollow, followerCount }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", "theme-modern")}>
        <section className="relative h-64 md:h-80 w-full">
            <Image
                src={seller.coverImage || seller.image}
                alt={seller.name}
                fill
                className="object-cover"
                data-ai-hint={seller.dataAiHint}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        </section>

        <div className="container -mt-32 relative z-10">
            <div className="max-w-4xl mx-auto">
                <Card className="p-6 md:p-8">
                     <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
                        <Avatar className="h-24 w-24 border-4 border-background shadow-md">
                            <AvatarImage src={seller.image} alt={seller.name} />
                            <AvatarFallback>{seller.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="space-y-1 flex-1">
                            <PageHeader title={seller.name} className="p-0 justify-center sm:justify-start" />
                            <p className="text-muted-foreground">{seller.specialty}</p>
                            <div className="pt-1"><VerificationBadge status={seller.status}/></div>
                        </div>
                    </div>

                    <Separator className="my-6" />

                    <div className="flex justify-center items-center gap-6 md:gap-12 text-sm text-muted-foreground">
                        <div className="text-center">
                            <span className="font-bold text-2xl text-foreground">{seller.rating}</span>
                            <div className="flex items-center gap-1"><Star className="w-4 h-4 text-yellow-500 fill-yellow-400" /><span>(24 reviews)</span></div>
                        </div>
                        <div className="text-center">
                            <span className="font-bold text-2xl text-foreground">{followerCount}</span>
                            <div className="flex items-center gap-1"><UserPlus className="w-4 h-4 text-primary" /><span>Followers</span></div>
                        </div>
                    </div>
                     <div className="flex items-center justify-center gap-2 pt-6">
                        {socials && Object.values(socials).some(s => s) && (
                            <div className="flex items-center gap-1">
                                {socials.linkedin && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#0077B5]"><Link href={socials.linkedin} target="_blank"><Linkedin className="h-5 w-5"/></Link></Button>}
                                {socials.twitter && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1DA1F2]"><Link href={socials.twitter} target="_blank"><Twitter className="h-5 w-5"/></Link></Button>}
                                {socials.instagram && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#E4405F]"><Link href={socials.instagram} target="_blank"><Instagram className="h-5 w-5"/></Link></Button>}
                                {socials.facebook && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1877F2]"><Link href={socials.facebook} target="_blank"><Facebook className="h-5 w-5"/></Link></Button>}
                                <Separator orientation="vertical" className="h-6 mx-2" />
                            </div>
                        )}
                        <ShareButton title={seller.name} text={`Check out ${seller.name} on Homelya.`} />
                    </div>
                </Card>

                <div className="mt-8 grid gap-8">
                    <Card>
                        <CardHeader><CardTitle className="font-headline">About</CardTitle></CardHeader>
                        <CardContent><p className="text-muted-foreground whitespace-pre-wrap">{seller.description}</p></CardContent>
                    </Card>

                    <Card>
                        <CardHeader><CardTitle className="font-headline">Contact</CardTitle></CardHeader>
                        <CardContent className="grid md:grid-cols-2 gap-4">
                            {seller.status === 'master' && (
                                <>
                                    <SendInquiryDialog professionalName={seller.name} professionalId={seller.id}>
                                        <Button size="lg" className="w-full"><Send className="mr-2" /> Send Inquiry</Button>
                                    </SendInquiryDialog>
                                    {whatsappLink && <Button size="lg" variant="outline" asChild className="w-full"><Link href={whatsappLink} target="_blank"><MessageCircle className="mr-2" /> Chat on WhatsApp</Link></Button>}
                                </>
                            )}
                             {user && user.uid !== seller.id && <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow} className="w-full"><UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}</Button>}
                             {seller.catalogPdfUrl && <Button size="lg" variant="outline" asChild className="w-full"><Link href={seller.catalogPdfUrl} target="_blank"><FileText className="mr-2" /> View Catalog (PDF)</Link></Button>}
                        </CardContent>
                    </Card>

                    {galleryImages.length > 0 && (
                        <section>
                            <h2 className="font-headline text-2xl font-bold mb-4 text-center">Gallery</h2>
                            <Carousel className="w-full">
                                <CarouselContent>
                                {galleryImages.map((imgUrl: string, index: number) => (
                                    <CarouselItem key={index} className="md:basis-1/2">
                                        <div className="p-1">
                                            <Card className="overflow-hidden">
                                                <CardContent className="p-0 aspect-video">
                                                    <Image src={imgUrl} alt={`Gallery image ${index + 1}`} width={600} height={400} className="object-cover w-full h-full" />
                                                </CardContent>
                                            </Card>
                                        </div>
                                    </CarouselItem>
                                ))}
                                </CarouselContent>
                                <CarouselPrevious />
                                <CarouselNext />
                            </Carousel>
                        </section>
                    )}
                    
                    {properties.length > 0 && (
                        <section>
                            <h2 className="font-headline text-2xl font-bold mb-4 text-center">Properties for Sale</h2>
                            <div className="grid sm:grid-cols-2 gap-6">
                                {properties.map((property: Property) => (
                                <ItemCard key={property.id} item={property} itemType="property" />
                                ))}
                            </div>
                        </section>
                    )}
                    
                    {auctions.length > 0 && (
                        <section>
                            <h2 className="font-headline text-2xl font-bold mb-4 text-center">Live Auctions</h2>
                            <div className="grid sm:grid-cols-2 gap-6">
                                {auctions.map((auction: Auction) => (
                                <ItemCard key={auction.id} item={auction} itemType="auction" />
                                ))}
                            </div>
                        </section>
                    )}
                </div>
            </div>
        </div>
    </div>
);

const CreativeLayout = ({ seller, properties, auctions, embedUrl, user, isFollowed, handleFollow, followerCount, whatsappLink }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", "theme-creative")}>
        <section className="bg-muted">
            <div className="container py-12 md:py-20">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                    <div className="relative">
                         <div className="absolute -left-4 -top-4 w-48 h-48 bg-primary/20 rounded-full blur-2xl"></div>
                         <Image
                            src={seller.image}
                            alt={seller.name}
                            width={400}
                            height={400}
                            className="rounded-lg object-cover aspect-square shadow-lg mx-auto relative z-10"
                            data-ai-hint={seller.dataAiHint}
                        />
                    </div>
                    <div className="space-y-4">
                        <PageHeader title={seller.name} className="p-0" />
                        <p className="text-xl text-primary font-semibold">{seller.specialty}</p>
                         <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1.5">
                                <Star className="w-4 h-4 text-yellow-500 fill-yellow-400" />
                                <span className="font-bold">{seller.rating}</span>
                                <span>(24 reviews)</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                                <UserPlus className="w-4 h-4 text-primary" />
                                <span className="font-bold">{followerCount}</span>
                                <span>Followers</span>
                            </div>
                        </div>
                        <p className="text-muted-foreground">{seller.description}</p>
                        <div className="flex items-center gap-4 pt-2">
                             {seller.status === 'master' && (
                                <>
                                    <SendInquiryDialog professionalName={seller.name} professionalId={seller.id}>
                                        <Button size="lg"><Send className="mr-2" /> Send Inquiry</Button>
                                    </SendInquiryDialog>
                                    {whatsappLink && <Button size="lg" variant="outline" asChild><Link href={whatsappLink} target="_blank"><MessageCircle className="mr-2" /> Chat on WhatsApp</Link></Button>}
                                </>
                             )}
                            <ShareButton title={seller.name} text={`Check out ${seller.name} on Homelya.`} />
                        </div>
                         {user && user.uid !== seller.id && <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow}><UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}</Button>}
                    </div>
                </div>
            </div>
        </section>
        <div className="container grid gap-12">
            {properties.length > 0 && (
                <section>
                <h2 className="font-headline text-3xl font-bold mb-6 text-center">Properties for Sale</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {properties.map((property: Property) => (
                    <ItemCard key={property.id} item={property} itemType="property" />
                    ))}
                </div>
                </section>
            )}

            {auctions.length > 0 && (
                <section>
                <h2 className="font-headline text-3xl font-bold mb-6 text-center">Live Auctions</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {auctions.map((auction: Auction) => (
                    <ItemCard key={auction.id} item={auction} itemType="auction" />
                    ))}
                </div>
                </section>
            )}

             {embedUrl && (
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline text-lg">Find Us</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="aspect-video w-full rounded-b-lg overflow-hidden">
                            <iframe width="100%" height="100%" loading="lazy" allowFullScreen src={embedUrl}></iframe>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    </div>
);

const PremiumLayout = ({ seller, properties, auctions, whatsappLink, socials, galleryImages, user, isFollowed, handleFollow, followerCount }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", "theme-premium")}>
        <section className="relative h-64 md:h-80 w-full">
            <Image
                src={seller.coverImage || 'https://images.unsplash.com/photo-1484154218962-a197022b5858?q=80&w=2074&auto=format&fit=crop'}
                alt={seller.name}
                fill
                className="object-cover"
                data-ai-hint={seller.dataAiHint || 'modern interior'}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
        </section>

        <div className="container -mt-24 md:-mt-32 relative z-10">
            <div className="max-w-5xl mx-auto">
                 <div className="flex flex-col sm:flex-row items-end gap-6">
                    <Avatar className="h-32 w-32 md:h-40 md:w-40 border-4 border-background shadow-lg bg-background">
                        <AvatarImage src={seller.image} alt={seller.name} />
                        <AvatarFallback>{seller.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="space-y-1 flex-1 pb-4 text-center sm:text-left">
                        <h1 className="font-headline text-3xl md:text-4xl font-bold">{seller.name}</h1>
                        <p className="text-primary text-lg font-medium">{seller.specialty}</p>
                        <div className="pt-2"><VerificationBadge status={seller.status}/></div>
                    </div>
                </div>
                
                 <div className="mt-6 flex justify-center items-center gap-6 md:gap-12 text-sm text-muted-foreground border-y py-4">
                    <div className="text-center">
                        <span className="font-bold text-2xl text-foreground">{seller.rating}</span>
                        <div className="flex items-center gap-1"><Star className="w-4 h-4 text-yellow-500 fill-yellow-400" /><span>(24 reviews)</span></div>
                    </div>
                    <div className="text-center">
                        <span className="font-bold text-2xl text-foreground">{followerCount}</span>
                        <div className="flex items-center gap-1"><UserPlus className="w-4 h-4 text-primary" /><span>Followers</span></div>
                    </div>
                </div>

                <div className="mt-6 grid md:grid-cols-3 gap-6">
                    <div className="md:col-span-2">
                        <Tabs defaultValue="properties" className="w-full">
                            <TabsList className="bg-card">
                                <TabsTrigger value="about"><Info className="mr-2"/> About</TabsTrigger>
                                <TabsTrigger value="properties"><Building className="mr-2"/> Properties</TabsTrigger>
                                <TabsTrigger value="auctions"><Gavel className="mr-2"/> Auctions</TabsTrigger>
                                {seller.profileVideoUrl && <TabsTrigger value="video"><Video className="mr-2"/> Video</TabsTrigger>}
                                {galleryImages.length > 0 && <TabsTrigger value="gallery"><Camera className="mr-2"/> Gallery</TabsTrigger>}
                            </TabsList>
                            <TabsContent value="about" className="mt-4">
                                <Card>
                                    <CardHeader><CardTitle className="font-headline">About</CardTitle></CardHeader>
                                    <CardContent><p className="text-muted-foreground whitespace-pre-wrap">{seller.description}</p></CardContent>
                                </Card>
                            </TabsContent>
                            <TabsContent value="properties" className="mt-4">
                               {properties.length > 0 ? (
                                    <div className="grid sm:grid-cols-2 gap-6">
                                        {properties.map((property: Property) => <ItemCard key={property.id} item={property} itemType="property" />)}
                                    </div>
                                ) : (
                                    <Card className="text-center py-12">
                                        <CardContent>
                                            <p className="text-muted-foreground">No properties for sale have been added yet.</p>
                                        </CardContent>
                                    </Card>
                                )}
                            </TabsContent>
                             <TabsContent value="auctions" className="mt-4">
                               {auctions.length > 0 ? (
                                    <div className="grid sm:grid-cols-2 gap-6">
                                        {auctions.map((auction: Auction) => <ItemCard key={auction.id} item={auction} itemType="auction" />)}
                                    </div>
                                ) : (
                                    <Card className="text-center py-12">
                                        <CardContent>
                                            <p className="text-muted-foreground">No active auctions at the moment.</p>
                                        </CardContent>
                                    </Card>
                                )}
                            </TabsContent>
                            {seller.profileVideoUrl && (
                              <TabsContent value="video" className="mt-4">
                                <Card>
                                  <CardContent className="p-0 aspect-video rounded-lg overflow-hidden">
                                    <VideoEmbed url={seller.profileVideoUrl}/>
                                  </CardContent>
                                </Card>
                              </TabsContent>
                            )}
                            {galleryImages.length > 0 && (
                                <TabsContent value="gallery" className="mt-4">
                                     <div className="columns-2 md:columns-3 gap-4">
                                        {galleryImages.map((imgUrl: string, index: number) => (
                                             <div key={index} className="mb-4 break-inside-avoid">
                                                <Image src={imgUrl} alt={`Gallery image ${index + 1}`} width={400} height={400} className="object-cover w-full h-auto rounded-lg" />
                                            </div>
                                        ))}
                                    </div>
                                </TabsContent>
                            )}
                        </Tabs>
                    </div>

                     <div className="space-y-6">
                        <Card>
                            <CardHeader><CardTitle className="font-headline">Contact & Connect</CardTitle></CardHeader>
                            <CardContent className="space-y-3">
                                {seller.status === 'master' && (
                                    <>
                                        <SendInquiryDialog professionalName={seller.name} professionalId={seller.id}>
                                            <Button size="lg" className="w-full"><Send className="mr-2" /> Send Inquiry</Button>
                                        </SendInquiryDialog>
                                        {whatsappLink && <Button size="lg" variant="outline" asChild className="w-full"><Link href={whatsappLink} target="_blank"><MessageCircle className="mr-2" /> Chat</Link></Button>}
                                    </>
                                )}
                                {user && user.uid !== seller.id && <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow} className="w-full"><UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}</Button>}
                            </CardContent>
                        </Card>
                         {socials && Object.values(socials).some(s => s) && (
                            <Card>
                                <CardHeader><CardTitle className="font-headline text-lg">Socials</CardTitle></CardHeader>
                                <CardContent className="flex items-center gap-2">
                                    {socials.linkedin && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#0077B5]"><Link href={socials.linkedin} target="_blank"><Linkedin/></Link></Button>}
                                    {socials.twitter && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1DA1F2]"><Link href={socials.twitter} target="_blank"><Twitter/></Link></Button>}
                                    {socials.instagram && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#E4405F]"><Link href={socials.instagram} target="_blank"><Instagram/></Link></Button>}
                                    {socials.facebook && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1877F2]"><Link href={socials.facebook} target="_blank"><Facebook/></Link></Button>}
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
);


export default function SellerProfilePage() {
  const params = useParams();
  const sellerId = params.id as string;
  const [seller, setSeller] = useState<Provider | null>(null);
  const [properties, setProperties] = useState<Property[]>([]);
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { follow, unfollow, isFollowing } = useFollow();
  const [followerCount, setFollowerCount] = useState(0);

  const isFollowed = isFollowing(sellerId);

  const handleFollow = () => {
      if (isFollowed) {
          unfollow(sellerId);
      } else {
          follow(sellerId);
      }
  }

  useEffect(() => {
    if (!sellerId) return;

    const followersRef = ref(db, `professional-followers/${sellerId}`);
    const unsubscribeFollowers = onValue(followersRef, (snapshot) => {
        setFollowerCount(snapshot.size);
    });

    const fetchSeller = async () => {
      setLoading(true);
      const userRef = ref(db, `users/${sellerId}`);
      try {
        const snapshot = await get(userRef);
        if (snapshot.exists()) {
           const data = snapshot.val();
            const sellerData: Provider = {
              id: sellerId,
              name: data.companyName,
              specialty: data.specialty || 'Real Estate',
              experienceLevel: data.experienceLevel,
              location: data.location || 'Not specified',
              locationUrl: data.locationUrl,
              description: data.description || 'No description available.',
              image: data.image || 'https://i.pravatar.cc/300',
              dataAiHint: 'real estate agent portrait',
              rating: 4.8, 
              phone: data.phone,
              email: data.email,
              website: data.website,
              status: data.status || 'in-progress',
              gstNumber: data.gstNumber,
              socials: data.socials,
              workHistory: data.workHistory,
              skills: data.skills,
              catalogPdfUrl: data.catalogPdfUrl,
              role: 'seller',
              theme: data.theme || 'default',
              coverImage: data.coverImage,
              galleryImages: data.galleryImages,
              profileVideoUrl: data.profileVideoUrl,
            };
            setSeller(sellerData);

            const propertiesQuery = query(ref(db, 'properties'), orderByChild('sellerId'), equalTo(sellerId));
            onValue(propertiesQuery, (snapshot) => {
                setProperties(snapshot.exists() ? Object.values(snapshot.val()) : []);
            });

            const auctionsQuery = query(ref(db, 'auctions'), orderByChild('sellerId'), equalTo(sellerId));
            onValue(auctionsQuery, (snapshot) => {
                setAuctions(snapshot.exists() ? Object.values(snapshot.val()) : []);
            });

        }
      } catch (error) {
        console.error("Error fetching seller data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSeller();
    return () => unsubscribeFollowers();
  }, [sellerId]);

  const embedUrl = getEmbedUrl(seller?.locationUrl);
  const whatsappMessage = `Hello ${seller?.name}, I found you on Homelya SMNP Nirman and I'm interested in your services.`;
  const whatsappLink = seller?.phone ? `https://wa.me/${seller.phone.replace(/\D/g, '')}?text=${encodeURIComponent(whatsappMessage)}` : null;
  const socials = seller?.socials;
  const skillsList = seller?.skills?.split(',').map(skill => skill.trim()).filter(skill => skill);
  const galleryImages = Array.isArray(seller?.galleryImages) ? seller.galleryImages.filter(Boolean) : [];

  if (loading) {
    return (
       <div className="space-y-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
             <Skeleton className="h-48 w-full" />
             <Skeleton className="h-64 w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-96 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!seller) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Seller not found</h2>
        <p className="text-muted-foreground">The seller you are looking for does not exist.</p>
      </div>
    );
  }
  
  const layoutProps = {
      seller, properties, auctions, embedUrl, whatsappLink, socials, skillsList, galleryImages, user, isFollowed, handleFollow, followerCount
  };

  switch (seller.theme) {
      case 'modern':
          return <ModernLayout {...layoutProps} />;
      case 'creative':
          return <CreativeLayout {...layoutProps} />;
      case 'premium':
          return <PremiumLayout {...layoutProps} />;
      default:
          return <DefaultLayout {...layoutProps} />;
  }
}
