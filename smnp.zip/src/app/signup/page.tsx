

'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Loader2, Globe, Map } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { useRouter, useSearchParams } from 'next/navigation';
import { createUserWithEmailAndPassword, updateProfile, GoogleAuthProvider, signInWithRedirect, getRedirectResult, type User, sendEmailVerification } from 'firebase/auth';
import { auth, db } from '@/lib/firebase';
import { ref, set, get } from "firebase/database";
import { useEffect, useState, Suspense } from 'react';
import Image from 'next/image';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const indianStates = [
    'Andaman and Nicobar Islands', 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 
    'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 
    'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 
    'Mizoram', 'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 
    'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
].sort();

const formSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  email: z.string().email({ message: 'Please enter a valid email.' }),
  phone: z.string().min(9, { message: 'Please enter a valid phone number.' }),
  country: z.enum(['india', 'dubai']),
  state: z.string().optional(),
  city: z.string().min(2, { message: 'City is required.' }),
  pincode: z.string().optional(),
  password: z.string().min(6, { message: 'Password must be at least 6 characters.' }),
}).superRefine((data, ctx) => {
    if (data.country === 'india' && !data.state) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'State is required for registrations in India.',
            path: ['state'],
        });
    }
    if (data.country === 'india' && data.pincode && !/^\d{6}$/.test(data.pincode)) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'Please enter a valid 6-digit Indian pincode.',
            path: ['pincode'],
        });
    }
});


const GoogleIcon = () => (
    <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24">
        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"></path>
        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"></path>
        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"></path>
        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"></path>
    </svg>
);

async function handleAuthSuccess(user: User, router: any, toast: any, redirectUrl: string | null, formData?: z.infer<typeof formSchema>) {
    const userRef = ref(db, `users/${user.uid}`);
    const snapshot = await get(userRef);

    if (!snapshot.exists()) {
       await set(userRef, {
            displayName: formData?.name || user.displayName,
            email: formData?.email || user.email,
            phone: formData?.phone || '',
            country: formData?.country || 'india', // Default to India if not specified
            state: formData?.state || '',
            city: formData?.city || '',
            location: formData?.city || 'Not specified',
            pincode: formData?.pincode || '',
            role: 'user', 
            status: 'verified',
            consultationsUsed: 0,
        });
    }
    
    toast({
        title: 'Account Created',
        description: 'Welcome! A verification link has been sent to your email.',
    });

    if (redirectUrl) {
        router.push(redirectUrl);
    } else {
        router.push('/professional-dashboard');
    }
}

function SignupPageContent() {
  const { toast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [country, setCountry] = useState<'india' | 'dubai' | null>(null);


  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
        name: '',
        email: '',
        phone: '',
        pincode: '',
        city: '',
        password: ''
    }
  });

  const handleSetCountry = (selectedCountry: 'india' | 'dubai') => {
    setCountry(selectedCountry);
    form.setValue('country', selectedCountry);
  }

  useEffect(() => {
    // This page only handles email/password signup. 
    // Google redirect results are handled on the login page to centralize the logic.
    // If a user initiated Google sign-in from here, they will be redirected back to the login page to complete it.
  }, []);

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, values.email, values.password);
      const user = userCredential.user;
      
      await updateProfile(user, {
          displayName: values.name
      });
      
      await sendEmailVerification(user);

      const fullPhoneNumber = `${values.country === 'india' ? '+91' : '+971'}${values.phone}`;
      
      const redirectUrl = searchParams.get('redirect');
      await handleAuthSuccess(user, router, toast, redirectUrl, {...values, phone: fullPhoneNumber});

    } catch (error: any) {
      console.error('Signup failed:', error);
      toast({
        variant: 'destructive',
        title: 'Signup Failed',
        description: error.message || 'An unknown error occurred.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    const provider = new GoogleAuthProvider();
    await signInWithRedirect(auth, provider);
  }
  
  if (!country) {
      return (
        <div className="flex min-h-[calc(100vh-8rem)] w-full items-center justify-center p-4">
            <div className="w-full max-w-lg overflow-hidden">
                <Card className="border-0 md:border md:shadow-lg">
                  <CardHeader className="text-center p-8">
                    <CardTitle className="font-headline text-2xl">Create an Account</CardTitle>
                    <CardDescription>First, please tell us where you are.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 p-8 pt-0">
                    <Button className="w-full h-16 text-lg" onClick={() => handleSetCountry('india')}>
                      <Map className="mr-4" /> I am in India
                    </Button>
                    <Button className="w-full h-16 text-lg" onClick={() => handleSetCountry('dubai')}>
                      <Globe className="mr-4" /> I am in Dubai
                    </Button>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-4 p-8 pt-0">
                      <p className="text-sm text-center text-muted-foreground">
                        Already have an account?{' '}
                        <Link href="/login" className="font-semibold text-primary hover:underline">
                          Log In
                        </Link>
                      </p>
                  </CardFooter>
                </Card>
            </div>
        </div>
      );
  }

  return (
    <div className="flex min-h-[calc(100vh-8rem)] w-full items-center justify-center p-4">
      <div className="grid w-full max-w-4xl grid-cols-1 md:grid-cols-2 overflow-hidden rounded-lg border shadow-lg">
         <div className="p-8 bg-card">
            <Card className="border-0 shadow-none">
              
                <CardHeader className="text-center p-0 mb-8">
                  <CardTitle className="font-headline text-2xl">Create an Account</CardTitle>
                  <CardDescription>Join Homelya to start building your dream home.</CardDescription>
                   <Button variant="link" onClick={() => setCountry(null)}>Change Country</Button>
                </CardHeader>
                <CardContent className="space-y-4 p-0">
                    <Button variant="outline" className="w-full" onClick={handleGoogleSignIn} disabled={googleLoading}>
                        {googleLoading ? <Loader2 className="animate-spin" /> : <><GoogleIcon /> Continue with Google</>}
                    </Button>
                    <div className="my-4 flex items-center">
                        <Separator className="flex-1" />
                        <span className="mx-4 text-xs text-muted-foreground">OR</span>
                        <Separator className="flex-1" />
                    </div>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                                <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Phone Number</FormLabel>
                                <div className="flex items-center">
                                    <span className="inline-flex items-center px-3 h-10 rounded-l-md border border-r-0 border-input bg-background text-sm">
                                        {country === 'india' ? '+91' : '+971'}
                                    </span>
                                    <FormControl>
                                        <Input placeholder={country === 'india' ? '9876543210' : '501234567'} {...field} className="rounded-l-none" />
                                    </FormControl>
                                </div>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                             <FormField
                                control={form.control}
                                name="city"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>City</FormLabel>
                                    <FormControl>
                                        <Input placeholder={country === 'india' ? "e.g., Ranchi" : "e.g., Dubai"} {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                        </div>
                         {country === 'india' && (
                           <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                               <FormField
                                    control={form.control}
                                    name="state"
                                    render={({ field }) => (
                                        <FormItem>
                                        <FormLabel>State</FormLabel>
                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                            <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select your state" />
                                            </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                            {indianStates.map(state => <SelectItem key={state} value={state}>{state}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="pincode"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Pincode (Optional)</FormLabel>
                                        <FormControl>
                                        <Input placeholder="e.g., 834001" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />
                            </div>
                        )}
                        <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                                <Input placeholder="you@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                                <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <Button type="submit" className="w-full" disabled={loading}>
                          {loading ? <Loader2 className="animate-spin" /> : 'Create Account'}
                        </Button>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex flex-col gap-4 p-0 mt-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    Already have an account?{' '}
                    <Link href="/login" className="font-semibold text-primary hover:underline">
                      Log In
                    </Link>
                  </p>
                  <Separator />
                  <p className="text-sm text-muted-foreground">
                    Are you a professional?{' '}
                    <Link href="/professional-auth/signup" className="font-semibold text-primary hover:underline">
                      Register Here
                    </Link>
                  </p>
                </CardFooter>
            </Card>
        </div>
        <div className="hidden md:block relative">
           <Image 
            src="https://picsum.photos/600/800"
            alt="Interior design"
            width={600}
            height={800}
            className="object-cover w-full h-full"
            data-ai-hint="modern interior"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent p-8 flex flex-col justify-end">
            <h2 className="font-headline text-3xl font-bold text-white">Design, Build, and Furnish</h2>
            <p className="text-white/80 mt-2">One platform for all your home construction needs.</p>
          </div>
        </div>
      </div>
    </div>
  );
}


export default function SignupPage() {
    return (
        <Suspense fallback={<div>Loading...</div>}>
            <SignupPageContent />
        </Suspense>
    )
}
