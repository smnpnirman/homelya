
'use client';

import { useState, useMemo, useEffect } from 'react';
import PageHeader from '@/components/page-header';
import ItemCard from '@/components/item-card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search } from 'lucide-react';
import { db } from '@/lib/firebase';
import { ref, onValue, query, orderByChild, equalTo } from 'firebase/database';
import type { AppEvent } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';

export default function EventsPage() {
  const [events, setEvents] = useState<AppEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    setLoading(true);
    const eventsQuery = query(ref(db, 'events'), orderByChild('status'), equalTo('approved'));
    const unsubscribe = onValue(eventsQuery, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const eventsList: AppEvent[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key],
          dataAiHint: 'event stage crowd',
        })).sort((a,b) => new Date(a.eventDate).getTime() - new Date(b.eventDate).getTime());
        setEvents(eventsList);
      } else {
        setEvents([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const eventTypes = useMemo(() => [...new Set(events.map((e) => e.eventType))], [events]);

  const filteredEvents = useMemo(() => {
    return events.filter((event) => {
      const searchMatch = (event.name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
                          (event.description?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
                          (event.locationOrUrl?.toLowerCase() || '').includes(searchTerm.toLowerCase());
      const typeMatch = typeFilter === 'all' || event.eventType === typeFilter;
      return searchMatch && typeMatch;
    });
  }, [searchTerm, typeFilter, events]);
  
  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
       <div key={i} className="space-y-2">
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-6 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-10 w-full" />
      </div>
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader 
        title="Upcoming Events"
        description="Join our community events, workshops, and webinars."
      />

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search events..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {eventTypes.map(type => (
              <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? renderSkeletons() : filteredEvents.map((event) => (
          <ItemCard key={event.id} item={event} itemType="event" />
        ))}
      </div>
       {filteredEvents.length === 0 && !loading && (
        <div className="text-center col-span-full py-12">
            <h3 className="font-headline text-xl font-semibold">No Events Found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters.</p>
        </div>
       )}
    </div>
  );
}
