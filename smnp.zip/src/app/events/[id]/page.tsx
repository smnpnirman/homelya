'use client';

import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Calendar, Globe, IndianRupee, Loader2, MapPin, Ticket as TicketIcon, CheckCircle } from 'lucide-react';
import PageHeader from '@/components/page-header';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useEffect, useState } from 'react';
import type { AppEvent, Provider } from '@/lib/types';
import { db, auth } from '@/lib/firebase';
import { ref, get, set, serverTimestamp, runTransaction, push, query, orderByChild, equalTo } from 'firebase/database';
import { Skeleton } from '@/components/ui/skeleton';
import ShareButton from '@/components/share-button';
import { format } from 'date-fns';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';


const bookingFormSchema = z.object({
    name: z.string().min(2, 'Name is required.'),
    email: z.string().email('A valid email is required.'),
    phone: z.string().optional(),
});
type BookingFormValues = z.infer<typeof bookingFormSchema>;

export default function EventDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const eventId = params.id as string;
  
  const [appEvent, setAppEvent] = useState<AppEvent | null>(null);
  const [organizer, setOrganizer] = useState<Provider | null>(null);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [alreadyBooked, setAlreadyBooked] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isBookingSuccess, setIsBookingSuccess] = useState(false);
  const [newBookingId, setNewBookingId] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const [countryCode, setCountryCode] = useState('+91');


  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
    },
  });

  useEffect(() => {
    if (user) {
      form.reset({
        name: user.displayName || '',
        email: user.email || '',
        phone: user.phoneNumber?.replace(/^\+\d{1,3}/, '') || ''
      })
    }
  }, [user, form]);


  useEffect(() => {
    if (!eventId) return;

    const fetchEventData = async () => {
      setLoading(true);
      try {
        const eventRef = ref(db, `events/${eventId}`);
        const eventSnapshot = await get(eventRef);
        if (eventSnapshot.exists()) {
          const eventData = { id: eventId, ...eventSnapshot.val() } as AppEvent;
          setAppEvent(eventData);

          if (eventData.professionalId) {
            const organizerRef = ref(db, `users/${eventData.professionalId}`);
            const organizerSnapshot = await get(organizerRef);
            if (organizerSnapshot.exists()) {
              const organizerData = organizerSnapshot.val();
              setOrganizer({ 
                  id: eventData.professionalId,
                  ...organizerData,
                  name: organizerData.companyName,
                  specialty: organizerData.specialty
              });
            }
          }
        }
      } catch (error) {
        console.error("Error fetching event data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchEventData();
  }, [eventId]);

  useEffect(() => {
    if (user && eventId) {
      const bookingsQuery = query(ref(db, 'bookings'), orderByChild('userId_eventId'), equalTo(`${user.uid}_${eventId}`));
      get(bookingsQuery).then(snapshot => {
        if (snapshot.exists()) {
          setAlreadyBooked(true);
        }
      });
    }
  }, [user, eventId]);
  
  const handleBookingSubmit = async (data: BookingFormValues) => {
      if (!user) {
          router.push(`/login?redirect=/events/${eventId}`);
          return;
      }
      if (!appEvent) return;

      setBooking(true);
      
      const eventRef = ref(db, `events/${eventId}`);

      try {
          if (alreadyBooked) {
            throw new Error('You have already booked a ticket for this event.');
          }

          const eventTransactionResult = await runTransaction(eventRef, (currentEvent) => {
              if (currentEvent) {
                  if (currentEvent.ticketsBooked < currentEvent.totalTickets) {
                      currentEvent.ticketsBooked = (currentEvent.ticketsBooked || 0) + 1;
                  } else {
                      return; // Abort transaction if tickets are sold out.
                  }
              }
              return currentEvent;
          });

          if (!eventTransactionResult.committed) {
              throw new Error("Sorry, tickets are sold out!");
          }
          
          const bookingRef = ref(db, `bookings`);
          const newBookingRef = push(bookingRef);
          const bookingId = newBookingRef.key;

          if (!bookingId) {
              throw new Error("Could not generate booking ID.");
          }

          const phone = data.phone ? `${countryCode}${data.phone}` : (user?.phoneNumber || '');

          await set(newBookingRef, {
              eventId: eventId,
              eventTitle: appEvent.name || 'Untitled Event',
              userId: user.uid,
              userName: data.name || user.displayName || 'Anonymous',
              userEmail: data.email || user.email || '',
              userPhone: phone,
              timestamp: serverTimestamp(),
              userId_eventId: `${user.uid}_${eventId}`,
          });
          
          setNewBookingId(bookingId);
          setIsBookingOpen(false);
          setIsBookingSuccess(true);

      } catch(error: any) {
           toast({ variant: 'destructive', title: 'Booking Failed', description: error.message });
           setBooking(false);
      }
  }

  if (loading) {
     return (
      <div className="space-y-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <Skeleton className="w-full aspect-video rounded-lg" />
          </div>
          <div className="space-y-6">
              <Skeleton className="h-12 w-3/4" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!appEvent) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Event not found</h2>
        <p className="text-muted-foreground">The event you are looking for does not exist.</p>
      </div>
    );
  }

  const isSoldOut = appEvent.ticketsBooked >= appEvent.totalTickets;

  const handleOpenChange = (open: boolean) => {
    if (open && !user) {
        router.push(`/login?redirect=/events/${eventId}`);
        return;
    }
    setIsBookingOpen(open);
  }

  return (
    <>
      <div className="space-y-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            <Image
              src={appEvent.image || 'https://picsum.photos/1200/800'}
              alt={appEvent.name || 'Event image'}
              width={1200}
              height={800}
              className="rounded-lg object-cover w-full aspect-video"
              data-ai-hint={appEvent.dataAiHint}
            />
            <div className="space-y-4 pt-4 border-t">
              <h2 className="font-headline text-2xl font-bold">About the Event</h2>
              <p className="text-muted-foreground whitespace-pre-wrap">{appEvent.description}</p>
            </div>
          </div>
          <div className="space-y-6">
              <div className="flex justify-between items-start">
                <PageHeader title={appEvent.name} className="p-0 border-b pb-4 flex-1" />
                <ShareButton title={appEvent.name} text={`Check out this event: "${appEvent.name}" on Homelya.`} />
              </div>
              
              <div className="space-y-4 text-lg">
                  <p className="flex items-center gap-3"><Calendar className="h-5 w-5 text-primary"/> <strong>{format(new Date(appEvent.eventDate), 'PPP')}</strong></p>
                  {appEvent.eventType === 'offline' ? (
                      <p className="flex items-center gap-3"><MapPin className="h-5 w-5 text-primary"/> {appEvent.locationOrUrl}</p>
                  ) : (
                      <Button asChild>
                          <a href={appEvent.locationOrUrl} target="_blank" rel="noopener noreferrer">
                              <Globe className="mr-2 h-5 w-5"/> Join Online Meeting
                          </a>
                      </Button>
                  )}
              </div>
              
              <Card className="bg-primary/5 border-primary/10">
                  <CardHeader>
                      <CardTitle className="font-headline text-2xl">Book Your Ticket</CardTitle>
                  </CardHeader>
                  <CardContent>
                      <p className="text-4xl font-bold flex items-center">
                          {appEvent.ticketPrice > 0 ? <><IndianRupee /> {appEvent.ticketPrice.toLocaleString('en-IN')}</> : 'Free'}
                      </p>
                      <p className="text-sm text-muted-foreground mt-2">{appEvent.totalTickets - appEvent.ticketsBooked} / {appEvent.totalTickets} tickets remaining</p>
                  </CardContent>
                  <CardFooter>
                      <Dialog open={isBookingOpen} onOpenChange={handleOpenChange}>
                          <DialogTrigger asChild>
                              <Button size="lg" className="w-full" disabled={isSoldOut || alreadyBooked}>
                                  <TicketIcon />
                                  {alreadyBooked ? 'Already Booked' : isSoldOut ? 'Sold Out' : 'Book Now'}
                              </Button>
                          </DialogTrigger>
                          <DialogContent>
                              <DialogHeader>
                                  <DialogTitle>Confirm Your Booking</DialogTitle>
                                  <DialogDescription>Please confirm your details for the event: "{appEvent.name}".</DialogDescription>
                              </DialogHeader>
                              <Form {...form}>
                                  <form onSubmit={form.handleSubmit(handleBookingSubmit)} className="space-y-4">
                                      <FormField
                                          control={form.control}
                                          name="name"
                                          render={({ field }) => (
                                              <FormItem>
                                              <FormLabel>Full Name</FormLabel>
                                              <FormControl><Input {...field} /></FormControl>
                                              <FormMessage />
                                              </FormItem>
                                          )}
                                      />
                                      <FormField
                                          control={form.control}
                                          name="email"
                                          render={({ field }) => (
                                              <FormItem>
                                              <FormLabel>Email</FormLabel>
                                              <FormControl><Input type="email" {...field} /></FormControl>
                                              <FormMessage />
                                              </FormItem>
                                          )}
                                      />
                                      <FormField
                                          control={form.control}
                                          name="phone"
                                          render={({ field }) => (
                                              <FormItem>
                                              <FormLabel>Phone (Optional)</FormLabel>
                                                <div className="flex items-center">
                                                    <Select defaultValue={countryCode} onValueChange={setCountryCode}>
                                                        <SelectTrigger className="w-[100px] rounded-r-none">
                                                            <SelectValue placeholder="Code" />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="+91">IN +91</SelectItem>
                                                            <SelectItem value="+971">AE +971</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                    <FormControl><Input type="tel" {...field} className="rounded-l-none" /></FormControl>
                                                </div>
                                              <FormMessage />
                                              </FormItem>
                                          )}
                                      />
                                      <DialogFooter>
                                          <Button type="submit" disabled={booking}>
                                              {booking ? <Loader2 className="animate-spin" /> : <TicketIcon />}
                                              {booking ? 'Booking...' : 'Confirm & Book'}
                                          </Button>
                                      </DialogFooter>
                                  </form>
                              </Form>
                          </DialogContent>
                      </Dialog>
                  </CardFooter>
              </Card>
          </div>
        </div>

      {organizer && <section>
          <h2 className="font-headline text-2xl font-bold mb-4">Hosted By</h2>
          <Card>
              <CardHeader className="flex flex-row items-center gap-4">
                  <Image src={organizer.image || ''} alt={organizer.name || 'Organizer logo'} width={60} height={60} className="rounded-full" />
                  <div>
                      <CardTitle>{organizer.name}</CardTitle>
                      <CardDescription>{organizer.specialty}</CardDescription>
                  </div>
              </CardHeader>
              <CardFooter>
                  <Button asChild variant="outline">
                      <Link href={`/${organizer.role}s/${organizer.id}`}>View Profile</Link>
                  </Button>
              </CardFooter>
          </Card>
        </section>}
      </div>
      <AlertDialog open={isBookingSuccess} onOpenChange={setIsBookingSuccess}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex justify-center">
                <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
            </div>
            <AlertDialogTitle className="text-center">Booking Confirmed!</AlertDialogTitle>
            <AlertDialogDescription className="text-center">
             Your booking is confirmed! You can view your ticket now. On the ticket page, you will find a button to email a copy to yourself for your records.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-center pt-4">
            <AlertDialogCancel>Close</AlertDialogCancel>
            <AlertDialogAction asChild>
              <Link href={`/event-ticket/${newBookingId}`}>View Ticket</Link>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
