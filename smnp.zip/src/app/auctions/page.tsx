
'use client';

import { useState, useMemo, useEffect } from 'react';
import PageHeader from '@/components/page-header';
import ItemCard from '@/components/item-card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search } from 'lucide-react';
import { db } from '@/lib/firebase';
import { ref, onValue } from 'firebase/database';
import type { Auction } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';

export default function AuctionsPage() {
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    setLoading(true);
    const auctionsRef = ref(db, 'auctions');
    const unsubscribe = onValue(auctionsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const auctionsList: Auction[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key],
          image: data[key].images ? data[key].images[0] : 'https://picsum.photos/600/400',
          dataAiHint: data[key].dataAiHint || 'property exterior',
        }));
        setAuctions(auctionsList);
      } else {
        setAuctions([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const propertyTypes = useMemo(() => [...new Set(auctions.map((p) => p.propertyType))], [auctions]);

  const filteredAuctions = useMemo(() => {
    return auctions.filter((auction) => {
      const searchMatch = auction.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          auction.location?.toLowerCase().includes(searchTerm.toLowerCase());
      const typeMatch = typeFilter === 'all' || auction.propertyType === typeFilter;
      return searchMatch && typeMatch && auction.status === 'active';
    });
  }, [searchTerm, typeFilter, auctions]);
  
  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
       <div key={i} className="space-y-2">
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-6 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-10 w-full" />
      </div>
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader 
        title="Live Auctions"
        description="Place your bid on exclusive properties before the timer runs out."
      />

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search by location or title..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {propertyTypes.map(type => (
              <SelectItem key={type} value={type}>{type}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? renderSkeletons() : filteredAuctions.map((auction) => (
          <ItemCard key={auction.id} item={auction} itemType="auction" />
        ))}
      </div>
       {filteredAuctions.length === 0 && !loading && (
        <div className="text-center col-span-full py-12">
            <h3 className="font-headline text-xl font-semibold">No Active Auctions Found</h3>
            <p className="text-muted-foreground">Please check back later for new auction listings.</p>
        </div>
       )}
    </div>
  );
}
