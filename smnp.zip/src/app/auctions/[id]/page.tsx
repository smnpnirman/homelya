
'use client';

import { useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Bed, Bath, IndianRupee, Ruler, MapPin, Building, ExternalLink, Gavel, Loader2, User, Crown, Clock } from 'lucide-react';
import PageHeader from '@/components/page-header';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useEffect, useState } from 'react';
import type { Auction, Provider, Bid } from '@/lib/types';
import { db } from '@/lib/firebase';
import { ref, onValue, runTransaction, serverTimestamp, set, push } from 'firebase/database';
import { Skeleton } from '@/components/ui/skeleton';
import ShareButton from '@/components/share-button';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { useAuth } from '@/hooks/use-auth';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { format, formatDistanceToNowStrict } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

function CountdownTimer({ endTime }: { endTime: number }) {
    const [timeLeft, setTimeLeft] = useState('');

    useEffect(() => {
        const calculateTimeLeft = () => {
            const now = new Date().getTime();
            const distance = endTime - now;

            if (distance < 0) {
                return 'Auction Ended';
            }

            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            return `${days}d ${hours}h ${minutes}m ${seconds}s`;
        };

        setTimeLeft(calculateTimeLeft());
        const timer = setInterval(() => setTimeLeft(calculateTimeLeft()), 1000);

        return () => clearInterval(timer);
    }, [endTime]);

    return (
         <div className="bg-destructive/10 border-2 border-dashed border-destructive text-destructive p-4 rounded-lg text-center">
            <p className="text-sm font-semibold">Time Left</p>
            <p className="text-3xl font-bold font-mono tracking-wider">{timeLeft}</p>
        </div>
    );
}


export default function AuctionDetailsPage() {
  const params = useParams();
  const auctionId = params.id as string;
  const { user, userData } = useAuth();
  const isDubai = userData?.country === 'dubai';
  const { toast } = useToast();
  
  const [auction, setAuction] = useState<Auction | null>(null);
  const [seller, setSeller] = useState<Provider | null>(null);
  const [loading, setLoading] = useState(true);
  const [bidAmount, setBidAmount] = useState(0);
  const [isBidding, setIsBidding] = useState(false);

  useEffect(() => {
    if (!auctionId) return;

    setLoading(true);
    const auctionRef = ref(db, `auctions/${auctionId}`);
    
    const unsubscribe = onValue(auctionRef, (snapshot) => {
        if (snapshot.exists()) {
          const auctionData = { id: auctionId, ...snapshot.val() };
          setAuction(auctionData);
          setBidAmount(auctionData.currentBid + auctionData.bidIncrement);

          if (auctionData.sellerId && !seller) {
            const sellerRef = ref(db, `users/${auctionData.sellerId}`);
            onValue(sellerRef, (sellerSnapshot) => {
              if (sellerSnapshot.exists()) {
                 const sellerDataFromDb = sellerSnapshot.val();
                  setSeller({ 
                    id: auctionData.sellerId, 
                    ...sellerDataFromDb, 
                    image: sellerDataFromDb.image || 'https://i.pravatar.cc/150', 
                    dataAiHint: 'agent portrait' 
                  });
              }
            });
          }
        }
         setLoading(false);
    });
    
    return () => unsubscribe();
  }, [auctionId, seller]);

  const handlePlaceBid = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!user) {
          toast({ variant: 'destructive', title: 'Login Required', description: 'You must be logged in to place a bid.' });
          return;
      }
      if (!auction) return;
      if (bidAmount < auction.currentBid + auction.bidIncrement) {
          toast({ variant: 'destructive', title: 'Invalid Bid', description: `Your bid must be at least ₹${(auction.currentBid + auction.bidIncrement).toLocaleString('en-IN')}.`});
          return;
      }
       if (new Date().getTime() > auction.endTime) {
            toast({ variant: "destructive", title: "Auction Ended", description: "This auction has already ended." });
            return;
        }

      setIsBidding(true);
      const auctionRef = ref(db, `auctions/${auctionId}`);
      try {
          const result = await runTransaction(auctionRef, (currentData) => {
              if (currentData) {
                  if (bidAmount > currentData.currentBid) {
                      currentData.currentBid = bidAmount;
                      if (!currentData.bids) {
                          currentData.bids = {};
                      }
                      const newBidRef = push(ref(db, `auctions/${auctionId}/bids`));
                      currentData.bids[newBidRef.key!] = {
                          userId: user.uid,
                          userName: user.displayName,
                          amount: bidAmount,
                          timestamp: serverTimestamp(),
                      };
                  } else {
                      return; // Abort transaction
                  }
              }
              return currentData;
          });

          if (result.committed) {
              toast({ title: 'Bid Placed!', description: `Your bid of ₹${bidAmount.toLocaleString('en-IN')} has been successfully placed.`});
          } else {
              toast({ variant: 'destructive', title: 'Bid Too Low', description: 'Someone placed a higher bid just before you. Please increase your bid.'});
          }
      } catch (error: any) {
          console.error("Error placing bid:", error);
          toast({ variant: 'destructive', title: 'Error', description: 'Could not place your bid. Please try again.' });
      } finally {
          setIsBidding(false);
      }
  }
  
  const bids = auction?.bids ? Object.values(auction.bids).sort((a,b) => b.amount - a.amount) : [];

  if (loading) {
     return (
      <div className="space-y-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            <Skeleton className="w-full aspect-video rounded-lg" />
          </div>
          <div className="space-y-6">
              <Skeleton className="h-12 w-3/4" />
              <Skeleton className="h-8 w-1/2" />
              <Skeleton className="h-24 w-full" />
              <div className="grid grid-cols-2 gap-4">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
              </div>
              <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!auction) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Auction not found</h2>
        <p className="text-muted-foreground">The auction you are looking for does not exist.</p>
      </div>
    );
  }
  
  const isAuctionEnded = new Date().getTime() > auction.endTime;


  return (
    <div className="space-y-8">
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-4">
            <Carousel className="w-full">
                <CarouselContent>
                    {auction.images?.map((img, index) => (
                        <CarouselItem key={index} className="relative group">
                            <Image
                                src={img}
                                alt={`${auction.name} - Image ${index + 1}`}
                                width={1200}
                                height={800}
                                className="rounded-lg object-cover w-full aspect-video"
                                data-ai-hint={auction.dataAiHint || 'property exterior'}
                            />
                        </CarouselItem>
                    ))}
                </CarouselContent>
                <CarouselPrevious className="left-4"/>
                <CarouselNext className="right-4" />
            </Carousel>
             <div className="space-y-4 pt-4 border-t">
                <h2 className="font-headline text-2xl font-bold">Description</h2>
                <p className="text-muted-foreground whitespace-pre-wrap">{auction.description}</p>
             </div>
        </div>
        <div className="space-y-6">
            <div className="flex justify-between items-start">
              <PageHeader title={auction.name} className="p-0 border-b pb-4 flex-1" />
              <ShareButton title={auction.name} text={`Check out this auction: "${auction.name}" on Homelya.`} />
            </div>
             <p className="text-sm text-muted-foreground">Current Bid</p>
             <p className="text-4xl font-bold flex items-center">
                 {isDubai ? 'AED ' : <IndianRupee />} {auction.currentBid?.toLocaleString(isDubai ? undefined : 'en-IN')}
             </p>
            
            <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-muted/50 p-4 rounded-lg">
                    <Bed className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{auction.bedrooms}</p>
                    <p className="text-sm text-muted-foreground">Bedrooms</p>
                </div>
                 <div className="bg-muted/50 p-4 rounded-lg">
                    <Bath className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{auction.bathrooms}</p>
                    <p className="text-sm text-muted-foreground">Bathrooms</p>
                </div>
                 <div className="bg-muted/50 p-4 rounded-lg">
                    <Ruler className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{auction.area.toLocaleString('en-IN')}</p>
                    <p className="text-sm text-muted-foreground">sq. ft.</p>
                </div>
                 <div className="bg-muted/50 p-4 rounded-lg">
                    <Building className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{auction.propertyType}</p>
                    <p className="text-sm text-muted-foreground">Type</p>
                </div>
            </div>
            <CountdownTimer endTime={auction.endTime} />
        </div>
      </div>

    <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
            <Card>
                <CardHeader>
                    <CardTitle className="font-headline">Bidding History</CardTitle>
                </CardHeader>
                <CardContent>
                    {bids.length === 0 ? (
                        <p className="text-muted-foreground text-center py-8">No bids yet. Be the first to bid!</p>
                    ) : (
                        <ul className="space-y-4">
                            {bids.map((bid, index) => (
                                <li key={index} className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        {index === 0 && !isAuctionEnded ? <Crown className="h-5 w-5 text-yellow-500" /> : <Gavel className="h-5 w-5 text-muted-foreground" />}
                                        <div>
                                            <p className="font-semibold">{bid.userName === user?.displayName ? 'You' : bid.userName}</p>
                                            <p className="text-xs text-muted-foreground">{formatDistanceToNowStrict(new Date(bid.timestamp))} ago</p>
                                        </div>
                                    </div>
                                    <Badge variant={index === 0 && !isAuctionEnded ? 'default' : 'secondary'} className="text-base">₹{bid.amount.toLocaleString('en-IN')}</Badge>
                                </li>
                            ))}
                        </ul>
                    )}
                </CardContent>
            </Card>
        </div>
        <div>
             <Card>
                <CardHeader>
                    <CardTitle className="font-headline">Place Your Bid</CardTitle>
                    <CardDescription>Minimum bid is ₹{(auction.currentBid + auction.bidIncrement).toLocaleString('en-IN')}</CardDescription>
                </CardHeader>
                <form onSubmit={handlePlaceBid}>
                    <CardContent>
                        <Input 
                            type="number"
                            value={bidAmount}
                            onChange={(e) => setBidAmount(Number(e.target.value))}
                            min={auction.currentBid + auction.bidIncrement}
                            step={auction.bidIncrement}
                            disabled={isBidding || isAuctionEnded || user?.uid === auction.sellerId}
                            className="text-lg h-12"
                        />
                    </CardContent>
                    <CardFooter>
                        <Button className="w-full" size="lg" type="submit" disabled={isBidding || isAuctionEnded || user?.uid === auction.sellerId}>
                            {isBidding ? <Loader2 className="animate-spin" /> : <Gavel />}
                             {isAuctionEnded ? 'Auction Ended' : user?.uid === auction.sellerId ? 'Cannot Bid on Own Auction' : 'Place Bid'}
                        </Button>
                    </CardFooter>
                </form>
            </Card>
        </div>
    </div>

     {seller && <section>
        <h2 className="font-headline text-2xl font-bold mb-4">Listed By</h2>
         <Card>
            <CardContent className="p-4 flex items-center gap-6">
                <Image src={seller.image!} alt={seller.name || 'Seller profile image'} width={100} height={100} className="rounded-full aspect-square object-cover" />
                <div className="flex-1">
                    <h3 className="font-headline font-bold text-xl">{seller.name}</h3>
                    <p className="text-muted-foreground">{seller.specialty}</p>
                </div>
            </CardContent>
         </Card>
      </section>}
    </div>
  );
}
