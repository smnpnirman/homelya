
'use client';

import React, { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Calculator, Loader2, Bot, IndianRupee, CheckCircle, ArrowRight, RotateCw } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { constructionCostEstimator, type ConstructionCostEstimatorOutput } from '@/ai/flows/estimation-calculator-flow';
import Link from 'next/link';

const FormSchema = z.object({
  plotArea: z.coerce.number().min(100, 'Plot area must be at least 100 sqft.'),
  floors: z.preprocess(
    (a) => (a === '' ? undefined : a),
    z.coerce.number({ invalid_type_error: 'Please enter a number.' }).min(1, 'Must have at least 1 floor.')
  ),
  quality: z.enum(['basic', 'standard', 'premium'], {
    required_error: 'Please select a material quality.',
  }),
  location: z.string().min(2, 'Please enter a location.'),
});

type EstimatorFormProps = {
  onLoading: () => void;
  onSuccess: (output: ConstructionCostEstimatorOutput) => void;
  onError: () => void;
};

function EstimatorForm({ onLoading, onSuccess, onError }: EstimatorFormProps) {
  const { toast } = useToast();
  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      plotArea: 1000,
      floors: 1,
      quality: 'standard',
      location: 'Ranchi',
    },
  });

  async function onSubmit(data: z.infer<typeof FormSchema>) {
    onLoading();
    try {
      const result = await constructionCostEstimator(data);
      onSuccess(result);
      toast({
        title: 'Estimation Ready!',
        description: 'Your project cost estimation has been generated.',
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: 'Failed to generate AI estimation. Please try again.',
      });
      onError();
    }
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
            <CardTitle className="font-headline text-xl">Project Details</CardTitle>
            <CardDescription>Provide the details below to get a cost estimate.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="plotArea"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Plot Area (sqft)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="e.g., 1200" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="floors"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number of Floors</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="e.g., 2" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="quality"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Material Quality</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select quality" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="standard">Standard</SelectItem>
                        <SelectItem value="premium">Premium</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Ranchi" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg">
              <Calculator className="mr-2 h-5 w-5" />
              Estimate Cost
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}


export default function EstimatorView() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ConstructionCostEstimatorOutput | null>(null);

  const handleSuccess = (output: ConstructionCostEstimatorOutput) => {
    setResult(output);
    setLoading(false);
  };
  
  const handleReset = () => {
    setResult(null);
    setLoading(false);
  }
  
  const handleError = () => {
    setLoading(false);
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center text-center p-8 rounded-lg border bg-card text-card-foreground shadow-sm min-h-[400px]">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <h2 className="font-headline text-2xl font-bold">Calculating your estimate...</h2>
        <p className="text-muted-foreground">Our AI is running the numbers for your project. This might take a moment.</p>
      </div>
    );
  }

  if (result) {
    return (
      <div className="space-y-6">
        <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <div>
                        <CardTitle className="font-headline text-2xl flex items-center gap-2">
                            <Bot className="text-primary"/> Your AI-Powered Estimate
                        </CardTitle>
                        <CardDescription>
                            Here is the estimated cost breakdown and guidance for your project.
                        </CardDescription>
                    </div>
                    <Button variant="outline" onClick={handleReset}>
                        <RotateCw className="mr-2 h-4 w-4" />
                        New Estimate
                    </Button>
                </div>
            </CardHeader>
        </Card>
        <div className="grid lg:grid-cols-3 gap-6 items-start">
            <div className="lg:col-span-1 space-y-6">
                 <Card>
                    <CardHeader>
                        <CardTitle className="font-headline">Total Estimated Cost</CardTitle>
                        <CardDescription>{result.estimatedCost.sqftRate}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold text-primary">{result.estimatedCost.total}</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline">Cost Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Materials</span>
                            <span className="font-semibold">{result.estimatedCost.materials}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Labor</span>
                            <span className="font-semibold">{result.estimatedCost.labor}</span>
                        </div>
                         <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Permits & Fees</span>
                            <span className="font-semibold">{result.estimatedCost.permits}</span>
                        </div>
                    </CardContent>
                </Card>
            </div>
            <div className="lg:col-span-2">
                <Card>
                    <CardHeader>
                         <CardTitle className="font-headline">Professional Guidance</CardTitle>
                         <CardDescription>{result.guidance.summary}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                         <div>
                            <h3 className="font-semibold mb-2">Next Steps</h3>
                            <ul className="space-y-2">
                                {result.guidance.nextSteps.map((step, index) => (
                                    <li key={index} className="flex items-start gap-2">
                                    <ArrowRight className="h-4 w-4 text-primary mt-1 shrink-0" />
                                    <span className="text-sm text-muted-foreground">{step}</span>
                                    </li>
                                ))}
                            </ul>
                         </div>
                         <div>
                            <h3 className="font-semibold mb-2">Key Recommendations</h3>
                            <ul className="space-y-2">
                                {result.guidance.recommendations.map((rec, index) => (
                                    <li key={index} className="flex items-start gap-2">
                                    <CheckCircle className="h-4 w-4 text-green-500 mt-1 shrink-0" />
                                    <span className="text-sm text-muted-foreground">{rec}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button asChild>
                            <Link href="/designers">
                                Find a Professional <ArrowRight className="ml-2"/>
                            </Link>
                        </Button>
                    </CardFooter>
                </Card>
            </div>
        </div>
      </div>
    );
  }

  return <EstimatorForm onLoading={() => setLoading(true)} onSuccess={handleSuccess} onError={handleError} />;
}
