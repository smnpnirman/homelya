import PageHeader from "@/components/page-header";
import EstimatorView from "./estimator-view";

export default function AiEstimatorPage() {
  return (
    <div className="space-y-8">
      <PageHeader 
        title="AI Construction Cost Estimator"
        description="Get a detailed cost breakdown and professional guidance for your building project."
      />
      <EstimatorView />
    </div>
  );
}
