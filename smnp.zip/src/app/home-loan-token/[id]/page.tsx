

'use client';

import { useParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, get } from 'firebase/database';
import PageHeader from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { Loader2, Download, CheckCircle, User, Mail, Hash, Phone, Briefcase, IndianRupee, Landmark, MapPin } from 'lucide-react';
import Logo from '@/components/logo';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import html2canvas from 'html2canvas';
import { amountToWords } from '@/lib/in-words';
import { useAuth } from '@/hooks/use-auth';

interface LoanInquiry {
    id: string;
    fullName: string;
    email: string;
    phone: string;
    state: string;
    district: string;
    pincode: string;
    loanAmount: number;
    annualIncome: number;
    employmentType: 'salaried' | 'self-employed';
    transactionId: string;
    applicationFee: number;
    timestamp: number;
    status: 'payment-pending' | 'verifying' | 'processing' | 'approved' | 'rejected';
}

function getStatusMessage(status: LoanInquiry['status']) {
    switch (status) {
        case 'payment-pending':
            return "Status: Payment Verification Pending";
        case 'verifying':
            return "Status: Verifying";
        case 'processing':
            return "Status: Processing";
        case 'approved':
            return "Status: Approved";
        case 'rejected':
            return "Status: Rejected";
        default:
            return "Status: Submitted";
    }
}

export default function HomeLoanTokenPage() {
  const params = useParams();
  const inquiryId = params.id as string;
  const { userData } = useAuth();
  const isDubai = userData?.country === 'dubai';
  const [inquiry, setInquiry] = useState<LoanInquiry | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const tokenRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!inquiryId) return;

    const fetchInquiry = async () => {
      setLoading(true);
      const inquiryRef = ref(db, `home-loan-inquiries/${inquiryId}`);
      try {
        const snapshot = await get(inquiryRef);
        if (snapshot.exists()) {
          setInquiry({ id: inquiryId, ...snapshot.val() });
        }
      } catch (error) {
        console.error("Error fetching home loan inquiry data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchInquiry();
  }, [inquiryId]);

  const handleDownload = async () => {
    if (!tokenRef.current) return;
    setDownloading(true);
    try {
        const canvas = await html2canvas(tokenRef.current, { 
            backgroundColor: null,
            scale: 2,
        });
        const link = document.createElement('a');
        link.download = `homelya-loan-token-${inquiryId}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
    } catch(error) {
        console.error("Error downloading token:", error);
    } finally {
        setDownloading(false);
    }
  };

  const formattedTokenId = `SMHL-${inquiryId.slice(-6).toUpperCase()}`;

  if (loading) {
    return (
        <div className="space-y-8 max-w-2xl mx-auto">
            <PageHeader title="Loading Your Application Token..." />
            <Card>
                <CardContent className="p-8">
                    <Skeleton className="h-96 w-full" />
                </CardContent>
            </Card>
        </div>
    )
  }

  if (!inquiry) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Application Not Found</h2>
        <p className="text-muted-foreground">The home loan application token you are looking for does not exist.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <PageHeader
        title="Application Submitted Successfully!"
        description="Here is your confirmation token. A loan expert will contact you shortly."
      />
      <div 
        ref={tokenRef} 
        className="bg-card border rounded-lg p-8 space-y-6"
      >
        <div className="flex justify-between items-start">
            <Logo />
            <div className="text-right">
                <h2 className="font-bold text-lg">Home Loan Application</h2>
                <p className="text-xs text-muted-foreground">{getStatusMessage(inquiry.status)}</p>
            </div>
        </div>
        <Separator />
        <Card className="bg-primary/5">
            <CardHeader>
                <div className="flex items-center gap-2">
                    <CheckCircle className="text-green-500"/>
                    <CardTitle className="font-headline text-xl">Your application has been received</CardTitle>
                </div>
                <CardDescription>
                    Our team will verify your payment and be in touch at <span className="font-semibold">{inquiry.email}</span>.
                </CardDescription>
            </CardHeader>
        </Card>
        <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div className="space-y-4">
                <h3 className="font-semibold text-lg">Applicant Details</h3>
                <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-primary" />
                    <span>{inquiry.fullName}</span>
                </div>
                <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-primary" />
                    <span>{inquiry.email}</span>
                </div>
                 <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-primary" />
                    <span>{inquiry.phone}</span>
                </div>
                <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-primary mt-0.5" />
                    <span>{inquiry.district}, {inquiry.state}, {inquiry.pincode}</span>
                </div>
                <div className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4 text-primary" />
                    <span className="capitalize">{inquiry.employmentType}</span>
                </div>
            </div>
            <div className="space-y-4">
                 <h3 className="font-semibold text-lg">Loan & Payment Details</h3>
                 <div className="flex items-start gap-2">
                    <Landmark className="h-4 w-4 text-primary mt-0.5" />
                    <div>
                        <p>Loan Amount: {isDubai ? `AED ${inquiry.loanAmount.toLocaleString()}` : `₹${inquiry.loanAmount.toLocaleString('en-IN')}`}</p>
                        <p className="text-xs text-muted-foreground">({amountToWords(inquiry.loanAmount)})</p>
                    </div>
                </div>
                <div className="flex items-start gap-2">
                    <IndianRupee className="h-4 w-4 text-primary mt-0.5" />
                     <div>
                        <p>Annual Income: {isDubai ? `AED ${inquiry.annualIncome.toLocaleString()}` : `₹${inquiry.annualIncome.toLocaleString('en-IN')}`}</p>
                        <p className="text-xs text-muted-foreground">({amountToWords(inquiry.annualIncome)})</p>
                    </div>
                </div>
                 <div className="flex items-center gap-2">
                    <Hash className="h-4 w-4 text-primary" />
                    <span className="break-all">Application ID: {formattedTokenId}</span>
                </div>
                <div className="flex items-center gap-2">
                    <Hash className="h-4 w-4 text-primary" />
                    <span className="break-all">Transaction ID: {inquiry.transactionId}</span>
                </div>
            </div>
        </div>
        <Separator/>
        <p className="text-xs text-muted-foreground text-center">
            Submitted on: {format(new Date(inquiry.timestamp), 'PPP p')}
        </p>
      </div>

      <div className="text-center">
        <Button size="lg" onClick={handleDownload} disabled={downloading}>
            {downloading ? <Loader2 className="mr-2 animate-spin" /> : <Download className="mr-2" />}
            {downloading ? "Downloading..." : "Download Token"}
        </Button>
      </div>
    </div>
  );
}
