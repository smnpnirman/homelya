

'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ArrowRight, Bot, Paintbrush, Warehouse, Wrench, Briefcase, Search, CheckCircle, Star, MapPin, LocateFixed, Send, Loader2, ShieldCheck, Gift, Landmark, Building, IndianRupee, Calculator, Gavel } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { designs as placeholderDesigns } from '@/lib/placeholder-data';
import ItemCard from '@/components/item-card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { db } from '@/lib/firebase';
import { get, ref, push, set, serverTimestamp, query, limitToFirst, onValue } from 'firebase/database';
import CityGrid from '@/components/city-grid';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import type { Design, Provider, Supplier } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { useRouter } from 'next/navigation';
import FeaturedCarousel from '@/components/featured-carousel';
import ProfessionalSearch from '@/components/professional-search';
import { useAuth } from '@/hooks/use-auth';
import FestivalBanner from '@/components/festival-banner';
import Logo from '@/components/logo';
import OffersCarousel from '@/components/offers-carousel';

async function getLocations() {
    try {
        const usersRef = ref(db, 'users');
        const snapshot = await get(usersRef);
        if (snapshot.exists()) {
            const users = snapshot.val();
            const locations = Object.values(users)
                // @ts-ignore
                .map((user: { location?: string }) => user.location)
                .filter((location): location is string => !!location && location.trim() !== '' && location !== 'Not specified');
            
            const uniqueLocations = [...new Set(locations)];
            return uniqueLocations;
        }
    } catch (error) {
        console.error("Error fetching locations:", error);
    }
    return [];
}

const additionalLocations = [
    'Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro', 'Deoghar', 'Hazaribagh', 'Giridih', 'Ramgarh',
    'Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur',
    'Raipur', 'Bhilai', 'Bilaspur', 'Korba',
    'Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai', 'Kolkata', 'Pune', 'Ahmedabad', 'Jaipur', 'Lucknow',
    'Dubai'
];

const testimonials = [
{
    name: 'Rohan & Priya S.',
    location: 'Ranchi',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704d',
    text: "Homelya made our dream home a reality. From finding the perfect architect to sourcing quality materials, everything was seamless. The AI configurator was surprisingly accurate and helpful!"
},
{
    name: 'Mehta Constructions',
    location: 'Jamshedpur',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704e',
    text: "As a constructor, joining Homelya has been a game-changer. We've connected with serious clients and showcased our work to a wider audience. The platform is professional and easy to use."
},
{
    name: 'Anita K.',
    location: 'Dhanbad',
    avatar: 'https://i.ibb.co/CpSdyCyY/IMG-20250824-195931.jpg',
    text: "I was overwhelmed with the process of building a house. Homelya simplified it. I found a fantastic local designer and reliable suppliers all in one place. Highly recommended!"
}
];


function QuickInquiryForm() {
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setLoading(true);

        const form = e.currentTarget;
        const formData = new FormData(form);
        const inquiryData = {
            name: formData.get('name') as string,
            phone: formData.get('phone') as string,
            message: formData.get('message') as string,
            timestamp: serverTimestamp(),
            status: 'new',
            source: 'Homepage Quick Inquiry',
        };

        try {
            const inquiriesRef = ref(db, 'general-inquiries');
            await push(inquiriesRef, inquiryData);
            
            toast({
                title: 'Inquiry Sent!',
                description: `Thank you for your message. Our team will get back to you shortly.`,
            });
            form.reset();
        } catch (error) {
            console.error("Failed to send inquiry:", error);
            toast({
                variant: "destructive",
                title: 'Failed to Send Inquiry',
                description: 'There was a problem sending your message. Please try again later.',
            });
        } finally {
            setLoading(false);
        }
    };
    
    return (
        <Card>
            <CardHeader>
                <CardTitle className="font-headline text-xl">Quick Inquiry</CardTitle>
                <CardDescription>
                  Have a question? Fill out the form and our team will get back to you.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <form className="space-y-4" onSubmit={handleSubmit}>
                    <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Name</Label>
                            <Input id="name" name="name" placeholder="Your Name" required/>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="phone">Phone</Label>
                            <Input id="phone" name="phone" type="tel" placeholder="Your Phone Number" required/>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="message">Your Requirement</Label>
                        <Textarea id="message" name="message" placeholder="I'm looking for..." required/>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                        {loading ? <Loader2 className="animate-spin" /> : <Send className="mr-2" />}
                        {loading ? 'Submitting...' : 'Submit Inquiry'}
                    </Button>
                </form>
            </CardContent>
        </Card>
    )
}


export default function Home() {
  const { user } = useAuth();
  const [locations, setLocations] = useState<string[]>([]);
  const [featuredDesigns, setFeaturedDesigns] = useState<Design[]>([]);
  const [featuredDesigners, setFeaturedDesigners] = useState<Provider[]>([]);
  const [featuredConstructors, setFeaturedConstructors] = useState<Provider[]>([]);
  const [featuredSuppliers, setFeaturedSuppliers] = useState<Supplier[]>([]);
  const [featuredSellers, setFeaturedSellers] = useState<Provider[]>([]);
  const [featuredBrokers, setFeaturedBrokers] = useState<Provider[]>([]);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let designsUnsubscribe: () => void = () => {};
    let usersUnsubscribe: () => void = () => {};

    async function loadInitialData() {
        setLoading(true);
        
        try {
            const fetchedLocations = await getLocations();
            const allLocations = [...new Set([...additionalLocations, ...(fetchedLocations || [])])].sort();
            setLocations(allLocations);

            const designsQuery = query(ref(db, 'designs'), limitToFirst(8));
            designsUnsubscribe = onValue(designsQuery, (snapshot) => {
                if (snapshot.exists()) {
                    const designsData = snapshot.val();
                    const designsList: Design[] = Object.keys(designsData).map(key => ({
                        id: key, ...designsData[key],
                        image: designsData[key].image || 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxNXx8SG91c2UlMjB8ZW58MHx8fHwxNzU2ODY1MjUzfDA&ixlib=rb-4.1.0&q=80&w=1080',
                        dataAiHint: designsData[key].dataAiHint || 'modern house',
                    }));
                    setFeaturedDesigns(designsList);
                } else {
                    setFeaturedDesigns(placeholderDesigns.slice(0, 8));
                }
            });

            const usersRef = ref(db, 'users');
            usersUnsubscribe = onValue(usersRef, (snapshot) => {
                if (snapshot.exists()) {
                    const usersData = snapshot.val();
                    const allUsers: any[] = Object.keys(usersData).map(key => ({
                      id: key,
                      ...usersData[key]
                    }));

                    const extractProviders = (role: 'designer' | 'constructor' | 'supplier' | 'seller' | 'broker'): any[] => {
                      return allUsers
                        .filter(user => user.role === role)
                        .map(user => ({
                          id: user.id,
                          name: user.companyName,
                          specialty: user.specialty || (role === 'supplier' ? user.category : (role === 'seller' || role === 'broker') ? 'Real Estate' : 'Not specified'),
                          category: user.category,
                          location: user.location || 'Not specified',
                          description: user.description || 'No description available.',
                          image: user.image || 'https://picsum.photos/400/300',
                          dataAiHint: role === 'designer' ? 'architect portrait' : role === 'constructor' ? 'building construction' : role === 'supplier' ? 'warehouse shelves' : role === 'seller' ? 'real estate agent' : 'broker portrait',
                          rating: 4.5 + Math.random() * 0.5,
                          status: user.status || 'in-progress',
                          role: role
                      }));
                    };
                    
                    const shuffleArray = (array: any[]) => {
                        for (let i = array.length - 1; i > 0; i--) {
                            const j = Math.floor(Math.random() * (i + 1));
                            [array[i], array[j]] = [array[j], array[i]];
                        }
                        return array;
                    }
                    
                    setFeaturedDesigners(shuffleArray(extractProviders('designer')).slice(0,8));
                    setFeaturedConstructors(shuffleArray(extractProviders('constructor')).slice(0,8));
                    setFeaturedSuppliers(shuffleArray(extractProviders('supplier')).slice(0,8));
                    setFeaturedSellers(shuffleArray(extractProviders('seller')).slice(0,8));
                    setFeaturedBrokers(shuffleArray(extractProviders('broker')).slice(0,8));
                }
                setLoading(false);
            });
        } catch (error) {
            console.error("Error loading initial data:", error);
            setLoading(false);
        }
    }

    loadInitialData();

    return () => {
      designsUnsubscribe();
      usersUnsubscribe();
    }
  }, []);
  
  const howItWorksSteps = [
    { icon: Bot, title: "Discover & Plan", description: "Use our AI Configurator or browse our catalogs to find what you need.", href: "/ai-configurator" },
    { icon: Briefcase, title: "Connect & Hire", description: "Connect with top-rated professionals and hire the best team for your project.", href: "/designers" },
    { icon: CheckCircle, title: "Build & Complete", description: "Turn your vision into reality with your chosen team and materials.", href: "/constructors" }
  ];

  const quickAccessLinks = [
      { href: "/ai-configurator", icon: Bot, title: "AI Home Planner", description: "Get AI-powered design and material recommendations." },
      { href: "/ai-estimator", icon: Calculator, title: "Cost Estimator", description: "Calculate your project's estimated cost in minutes." },
      { href: "/designs", icon: Paintbrush, title: "Browse Designs", description: "Explore our curated collection of home designs." },
      { href: "/properties", icon: Building, title: "Browse Properties", description: "Find apartments, plots, and houses for sale." },
      { href: "/auctions", icon: Gavel, title: "Live Auctions", description: "Bid on exclusive properties in live auctions." },
      { href: "/home-loan", icon: Landmark, title: "Home Loans", description: "Get assistance with financing for your dream home." },
      { href: "/designers", icon: Wrench, title: "Find a Professional", description: "Search for designers, constructors, and suppliers." },
      { href: "/free-consultation", icon: Gift, title: "Free Consultation", description: "Book a free session with an industry expert." },
  ]
  
   const partners = [
    { name: "HDFC Bank", logo: "https://i.ibb.co/P927s1T/hdfc-logo.png" },
    { name: "ICICI Bank", logo: "https://i.ibb.co/bXW7v2w/icici-logo.png" },
    { name: "State Bank of India", logo: "https://i.ibb.co/sVq1p2x/sbi-logo.png" },
    { name: "Axis Bank", logo: "https://i.ibb.co/L9nZzBC/axis-logo.png" },
    { name: "Kotak Mahindra Bank", logo: "https://i.ibb.co/N7K2xV7/kotak-logo.png" },
    { name: "Bank of Baroda", logo: "https://i.ibb.co/1GX5qGqt/bob-logo.png" },
  ];

  return (
    <div className="flex flex-col gap-12 md:gap-20">
      <section className="relative -mx-4 sm:-mx-6 lg:-mx-8">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-orange-50 to-red-50 dark:from-slate-900/80 dark:via-slate-950 dark:to-black"></div>
        <div className="absolute inset-0 bg-grid-slate-100/[0.04] bg-[10px_10px] [mask-image:linear-gradient(to_bottom,white,transparent)] dark:bg-grid-slate-700/[0.1]"></div>
        <div className="relative z-10 container text-center pt-16 md:pt-24 pb-8">
          <div className="flex flex-col items-center">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tighter text-balance bg-gradient-to-r from-primary via-orange-500 to-red-500 bg-clip-text text-transparent">
              Build Your Future, Anywhere in India.
            </h1>
            <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
              Your trusted partner for designer homes, expert constructors, and quality material suppliers across the nation.
            </p>
          </div>
           <div className="w-full mt-8 animate-fade-in-up" style={{ animationFillMode: 'backwards' }}>
            <ProfessionalSearch />
             <div className="mt-4">
                <Button asChild variant="outline">
                    <Link href="/map-search">
                        <MapPin className="mr-2 h-4 w-4"/> Access Map
                    </Link>
                </Button>
            </div>
          </div>
        </div>
      </section>

      <div className="container space-y-12 md:space-y-20">
        <FestivalBanner />

        <OffersCarousel />
        
        <section>
            <div className="text-center">
                <h2 className="text-3xl font-bold">How It Works</h2>
                <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">A streamlined process to bring your dream home to life in just three simple steps.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6 mt-10">
                {howItWorksSteps.map((step, index) => (
                    <Card key={index} className="text-center animate-fade-in-up flex flex-col group hover:border-primary/50 transition-all transform hover:-translate-y-1 hover:shadow-lg" style={{ animationDelay: `${index * 150}ms` }}>
                        <CardHeader>
                            <div className="mx-auto bg-primary/10 text-primary rounded-full h-16 w-16 flex items-center justify-center ring-8 ring-background">
                                <step.icon className="h-8 w-8" />
                            </div>
                        </CardHeader>
                        <CardContent className="flex-1">
                            <h3 className="text-xl font-bold">{step.title}</h3>
                            <p className="text-muted-foreground mt-2">{step.description}</p>
                        </CardContent>
                        <CardFooter>
                            <Button asChild variant="ghost" className="w-full text-primary">
                                <Link href={step.href}>
                                    Get Started <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                                </Link>
                            </Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </section>
        
        <section>
            <div className="text-center">
                <h2 className="text-3xl font-bold">Explore Our Services</h2>
                <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">Quickly access all our features to start your journey.</p>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-10">
                {quickAccessLinks.map((link, index) => (
                    <Link key={link.href} href={link.href} className="group">
                        <Card className="h-full text-center animate-fade-in-up hover:border-primary/50 transition-all transform hover:-translate-y-1 hover:shadow-lg" style={{ animationDelay: `${index * 75}ms` }}>
                            <CardContent className="p-6">
                                <div className="mx-auto bg-primary/10 text-primary rounded-lg h-14 w-14 flex items-center justify-center transition-all group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground">
                                    <link.icon className="h-7 w-7" />
                                </div>
                                <h3 className="text-lg font-bold mt-4">{link.title}</h3>
                                <p className="text-muted-foreground text-sm mt-1">{link.description}</p>
                            </CardContent>
                        </Card>
                    </Link>
                ))}
            </div>
        </section>

        <section>
            <div className="text-center">
                <h2 className="text-3xl font-bold">Our Partners</h2>
                <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">We are proud to collaborate with leading banks to facilitate your home loan needs.</p>
            </div>
            <div className="mt-10 relative">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                    <div className="w-40 h-40 rounded-full bg-primary/5 border-2 border-dashed border-primary/20"></div>
                </div>
                <div className="absolute top-1/2 left-1/2 w-[50%] h-[40%] -translate-x-1/2 -translate-y-1/2 border-b-2 border-dashed border-primary/20"></div>
                <div className="absolute top-1/2 left-1/2 w-[50%] h-[40%] -translate-x-1/2 -translate-y-1/2 border-t-2 border-dashed border-primary/20"></div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center relative">
                    {partners.map((partner, index) => (
                        <div key={partner.name} className="flex justify-center animate-fade-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                            <div className="w-32 h-32 flex items-center justify-center bg-card p-4 rounded-full shadow-md border-2 border-background hover:border-primary/20 transition-all">
                                <Image
                                    src={partner.logo}
                                    alt={`${partner.name} Logo`}
                                    width={100}
                                    height={40}
                                    className="object-contain"
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>

        <section className="space-y-6">
            <Card className="bg-gradient-to-r from-accent to-orange-400 text-accent-foreground p-8 md:p-12">
                <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="flex items-center gap-6">
                        <Gift className="w-16 h-16 shrink-0" />
                        <div>
                            <h2 className="text-3xl font-bold">Get 2 Free Consultations!</h2>
                            <p className="text-lg text-accent-foreground/80 mt-1">Sign up today and get free expert advice to kickstart your project.</p>
                        </div>
                    </div>
                    <Button asChild size="lg" variant="secondary" className="bg-white/90 hover:bg-white text-accent font-bold mt-4 md:mt-0 flex-shrink-0">
                        <Link href={user ? "/free-consultation" : "/signup?redirect=/free-consultation"}>
                            Claim Your Offer <ArrowRight className="ml-2"/>
                        </Link>
                    </Button>
                </div>
            </Card>
            <Card className="bg-gradient-to-r from-primary to-blue-400 text-primary-foreground p-8 md:p-12">
                <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="flex items-center gap-6">
                        <Landmark className="w-16 h-16 shrink-0" />
                        <div>
                            <h2 className="text-3xl font-bold">Need a Home Loan?</h2>
                            <p className="text-lg text-primary-foreground/80 mt-1">We offer expert assistance to help you secure the best financing for your dream home.</p>
                        </div>
                    </div>
                    <Button asChild size="lg" variant="secondary" className="bg-white/90 hover:bg-white text-primary font-bold mt-4 md:mt-0 flex-shrink-0">
                        <Link href="/home-loan">
                            Apply Now <ArrowRight className="ml-2"/>
                        </Link>
                    </Button>
                </div>
            </Card>
            <Card className="bg-gradient-to-r from-green-600 to-emerald-500 text-white p-8 md:p-12">
                <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="flex items-center gap-6">
                        <Building className="w-16 h-16 shrink-0" />
                        <div>
                            <h2 className="text-3xl font-bold">Buy or Sell Property</h2>
                            <p className="text-lg text-white/80 mt-1">Explore our marketplace for properties or list your own for sale.</p>
                        </div>
                    </div>
                    <Button asChild size="lg" variant="secondary" className="bg-white/90 hover:bg-white text-green-600 font-bold mt-4 md:mt-0 flex-shrink-0">
                        <Link href="/properties">
                            Browse Marketplace <ArrowRight className="ml-2"/>
                        </Link>
                    </Button>
                </div>
            </Card>
        </section>
        
        <FeaturedCarousel
            title="Design Marketplace"
            viewAllLink="/designs"
            items={featuredDesigns}
            itemType="design"
            loading={loading}
            skeletons={4}
        />

        <FeaturedCarousel 
            title="Featured Designers"
            viewAllLink="/designers"
            items={featuredDesigners}
            itemType="designer"
            loading={loading}
            skeletons={4}
        />

        <FeaturedCarousel
            title="Featured Constructors"
            viewAllLink="/constructors"
            items={featuredConstructors}
            itemType="constructor"
            loading={loading}
            skeletons={4}
        />

        <FeaturedCarousel
            title="Featured Suppliers"
            viewAllLink="/suppliers"
            items={featuredSuppliers}
            itemType="supplier"
            loading={loading}
            skeletons={4}
        />

        <FeaturedCarousel
            title="Featured Sellers"
            viewAllLink="/sellers"
            items={featuredSellers}
            itemType="seller"
            loading={loading}
            skeletons={4}
        />

        <FeaturedCarousel
            title="Featured Brokers"
            viewAllLink="/brokers"
            items={featuredBrokers}
            itemType="broker"
            loading={loading}
            skeletons={4}
        />

        <section className="bg-muted/50 py-12 md:py-20 -mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8">
            <div className="container">
                <div className="text-center">
                    <h2 className="text-3xl font-bold">What Our Users Say</h2>
                    <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">Real stories from homeowners and professionals who trust Homelya.</p>
                </div>
                <Carousel
                    opts={{ align: "start", loop: true }}
                    className="w-full mt-10"
                >
                    <CarouselContent>
                    {testimonials.map((testimonial, index) => (
                        <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                        <div className="p-1 h-full">
                            <Card className="h-full flex flex-col">
                            <CardContent className="p-6 flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                {Array(5).fill(0).map((_, i) => <Star key={i} className="w-5 h-5 text-yellow-500 fill-yellow-400" />)}
                                </div>
                                <p className="text-muted-foreground">"{testimonial.text}"</p>
                            </CardContent>
                            <CardFooter className="p-6 pt-0 mt-auto">
                                <div className="flex items-center gap-4">
                                    <Avatar>
                                        <AvatarImage src={testimonial.avatar} />
                                        <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{testimonial.name}</p>
                                        <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                                    </div>
                                </div>
                            </CardFooter>
                            </Card>
                        </div>
                        </CarouselItem>
                    ))}
                    </CarouselContent>
                    <CarouselPrevious className="hidden md:flex"/>
                    <CarouselNext className="hidden md:flex"/>
                </Carousel>
            </div>
        </section>
        
        <section>
            <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center bg-muted/40 p-8 rounded-lg">
                <div>
                    <Image 
                        src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxCdWlsZGluZyUyMHxlbnwwfHx8fDE3NTY4NjUxNjh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                        width={600}
                        height={400}
                        alt="Architectural drawing"
                        className="rounded-lg object-cover"
                        data-ai-hint="architecture blueprint"
                    />
                </div>
                <QuickInquiryForm />
            </div>
        </section>

        <section className="animate-fade-in-up">
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="space-y-4">
                <h2 className="text-3xl font-bold">From the Founder's Desk</h2>
                <p className="text-muted-foreground text-lg">"At Homelya, our mission is to empower every individual to build their dream home with confidence. We're leveraging technology to bring transparency, reliability, and choice to the construction industry, creating a seamless experience from design to reality."</p>
                <div>
                    <p className="font-bold">Nikhil Kumar</p>
                    <p className="text-sm text-muted-foreground">Founder, Homelya</p>
                </div>
            </div>
            <div className="relative flex justify-center items-center">
              <div className="absolute bg-red-500/20 rounded-full w-64 h-64 blur-3xl animate-ping-slow"></div>
              <p className="font-horror text-5xl text-red-600 -rotate-12 absolute -left-4 top-1/2 -translate-y-1/2">LETS BUILD</p>
              <Image
                src="https://i.ibb.co/j9bPfKHJ/IMG-20251222-185812-385.webp"
                width={400}
                height={400}
                alt="Nikhil Kumar, Founder of Homelya"
                className="rounded-full object-cover shadow-lg aspect-square relative z-10"
                data-ai-hint="male portrait"
              />
            </div>
          </div>
        </section>

        <section className="bg-primary/90 -mx-4 sm:-mx-6 lg:-mx-8">
            <div className="container py-12 md:py-20">
                <div className="rounded-lg text-primary-foreground p-8 md:p-12 lg:p-16 flex flex-col lg:flex-row items-center justify-between gap-8">
                    <div className="text-center lg:text-left">
                        <h2 className="text-3xl font-bold">Are you a Professional?</h2>
                        <p className="mt-2 text-lg text-primary-foreground/80 max-w-2xl">
                        Join our network of talented designers, reliable constructors, and trusted suppliers. Showcase your work and connect with new clients across India.
                        </p>
                    </div>
                    <div className="flex-shrink-0">
                        <Button asChild size="lg" variant="secondary" className="text-lg py-7 px-10 bg-background/20 hover:bg-background/30 text-white">
                            <Link href="/professional-auth/signup">
                                <Briefcase className="mr-2 h-5 w-5" />
                                Register as a Partner
                            </Link>
                        </Button>
                    </div>
                </div>
            </div>
        </section>
        
        <section>
            <div className="text-center">
                <h2 className="text-3xl font-bold">Find us in your city</h2>
                <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">We are constantly expanding our network to serve you better across the nation.</p>
                <CityGrid cities={locations} />
            </div>
        </section>
      </div>
    </div>
  );
}

    