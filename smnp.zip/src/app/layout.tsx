

'use client';

import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { Home, Bot, Paintbrush, Wrench, Warehouse, Heart, LifeBuoy, LogIn, LogOut, User, DollarSign, LayoutDashboard, Shield, MessageSquare, Bell, CalendarCheck, Landmark, Building, Calculator, Users, Gavel, LineChart, PieChart, Megaphone, View, Rss, MapPin, Sparkles, Handshake, Map, CalendarDays, Briefcase } from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import './globals.css';
import { cn } from '@/lib/utils';
import { SidebarProvider, Sidebar, SidebarTrigger, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarInset, SidebarFooter, SidebarGroup, SidebarGroupLabel, SidebarMenuSub, SidebarMenuSubButton, SidebarMenuSubItem } from '@/components/ui/sidebar';
import Link from 'next/link';
import Logo from '@/components/logo';
import { FavoritesProvider } from '@/contexts/favorites-context';
import PageHeader from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { AuthProvider, AuthContext } from '@/contexts/auth-context';
import { useContext, useState, useEffect, Fragment } from 'react';
import { auth, db } from '@/lib/firebase';
import { signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ref, onValue } from 'firebase/database';
import { FollowProvider } from '@/contexts/follow-context';
import { ThemeProvider } from '@/contexts/theme-provider';
import { ThemeToggle } from '@/components/theme-toggle';
import type { VerificationStatus } from '@/lib/types';
import VastuChatWidget from '@/components/vastu-chat-widget';
import { ComparisonProvider } from '@/contexts/comparison-context';
import ComparisonBar from '@/components/comparison-bar';


const fontSans = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
});

const navConfig = {
  general: [
    { href: '/', icon: <Home />, label: 'Home' },
  ],
  aiTools: {
    label: "AI Tools",
    items: [
      { href: '/ai-configurator', icon: <Bot />, label: 'AI Configurator' },
      { href: '/ai-estimator', icon: <Calculator />, label: 'AI Estimator' },
    ]
  },
  explore: {
    label: "Explore",
    items: [
      { href: '/designs', icon: <Paintbrush />, label: 'Designs' },
      { href: '/properties', icon: <Building />, label: 'Properties' },
      { href: '/auctions', icon: <Gavel />, label: 'Auctions' },
      { href: '/events', icon: <CalendarDays />, label: 'Events' },
      { href: '/map-search', icon: <Map />, label: 'Map Search' },
    ]
  },
  findProfessional: {
    label: "Find a Professional",
    items: [
      { href: '/designers', icon: <Paintbrush />, label: 'Designers' },
      { href: '/constructors', icon: <Wrench />, label: 'Constructors' },
      { href: '/suppliers', icon: <Warehouse />, label: 'Suppliers' },
      { href: '/sellers', icon: <Gavel />, label: 'Sellers' },
      { href: '/brokers', icon: <Briefcase />, label: 'Brokers' },
      { href: '/mentors', icon: <Handshake />, label: 'Find a Mentor' },
    ]
  },
  services: [
    { href: '/home-loan', icon: <Landmark />, label: 'Home Loan' },
    { href: '/analytics', icon: <PieChart />, label: 'Analytics' },
    { href: '/support', icon: <LifeBuoy />, label: 'Support' },
  ],
  userDashboard: {
      label: "My Dashboard",
      items: [
        { href: '/professional-dashboard', icon: <LayoutDashboard />, label: 'Overview' },
        { href: '/favorites', icon: <Heart />, label: 'Favorites' },
        { href: '/professional-dashboard/my-bookings', icon: <CalendarCheck />, label: 'My Bookings' },
    ]
  },
  userCommunity: {
    label: "Community",
    items: [
      { href: '/professional-dashboard/following', icon: <Users />, label: 'Following' },
      { href: '/professional-dashboard/community-feed', icon: <Rss />, label: 'Community Feed' },
    ]
  },
  professionalDashboard: {
    label: "Dashboard",
    items: [
      { href: '/professional-dashboard', icon: <LayoutDashboard />, label: 'Overview' },
      { href: '/professional-dashboard/my-designs', icon: <Paintbrush />, label: 'My Designs' },
      { href: '/professional-dashboard/inquiries', icon: <MessageSquare />, label: 'Inquiries' },
      { href: '/professional-dashboard/my-bookings', icon: <CalendarCheck />, label: 'Consultations' },
      { href: '/professional-dashboard/events', icon: <CalendarDays />, label: 'My Events' },
      { href: '/professional-dashboard/notifications', icon: <Bell />, label: 'Notifications' },
      { href: '/billing', icon: <DollarSign />, label: 'Billing' },
    ]
  },
  professionalTools: {
    label: "Tools",
    items: [
      { href: '/professional-dashboard/advertising', icon: <Megaphone />, label: 'Advertising' },
      { href: '/professional-dashboard/vr-order', icon: <View />, label: 'VR Kit' },
      { href: '/professional-dashboard/address-verification', icon: <MapPin />, label: 'Address Verification' },
    ]
  },
  masterFeatures: {
    label: "Master Features",
    items: [
      { href: '/professional-dashboard/leads', icon: <Sparkles />, label: 'My Leads' },
      { href: '/professional-dashboard/community', icon: <Rss />, label: 'My Community' },
    ]
  },
  admin: [
    { href: '/admin', icon: <Shield />, label: 'Admin Dashboard' },
  ]
};

function AppLayout({ children }: { children: React.ReactNode }) {
  const { user } = useContext(AuthContext);
  const router = useRouter();
  const [userData, setUserData] = useState<{role: string; status: VerificationStatus} | null>(null);

  useEffect(() => {
    if (user) {
      const userRef = ref(db, 'users/' + user.uid);
      const unsubscribe = onValue(userRef, (snapshot) => {
        const data = snapshot.val();
        setUserData(data || { role: 'user', status: 'verified' });
      });
      return () => unsubscribe();
    } else {
        setUserData(null);
    }
  }, [user]);

  const handleLogout = async () => {
    await signOut(auth);
    router.push('/');
  };
  
  const getInitials = (email: string | null | undefined) => {
    if (!email) return 'U';
    return email.substring(0, 2).toUpperCase();
  }

  const isMaster = userData?.status === 'master';
  const isProfessional = userData?.role === 'designer' || userData?.role === 'constructor' || userData?.role === 'supplier' || userData?.role === 'seller' || userData?.role === 'broker';
  const isAdmin = userData?.role === 'admin';
  const isRegularUser = userData?.role === 'user';
  
  const renderNavGroup = (items: {href: string, icon: JSX.Element, label: string}[]) => (
    items.map(item => (
      <SidebarMenuItem key={item.href}>
        <SidebarMenuButton asChild>
          <Link href={item.href}>{item.icon}<span>{item.label}</span></Link>
        </SidebarMenuButton>
      </SidebarMenuItem>
    ))
  );
  
  const renderNavSubMenu = (group: {label: string, items: {href: string, icon: JSX.Element, label: string}[]}) => (
    <SidebarMenuItem>
      <SidebarMenuButton>{group.items[0].icon}<span>{group.label}</span></SidebarMenuButton>
      <SidebarMenuSub>
        {group.items.map(item => (
          <SidebarMenuSubItem key={item.href}><SidebarMenuSubButton asChild><Link href={item.href}>{item.label}</Link></SidebarMenuSubButton></SidebarMenuSubItem>
        ))}
      </SidebarMenuSub>
    </SidebarMenuItem>
  );

  return (
    <ComparisonProvider>
      <FollowProvider>
        <FavoritesProvider>
          <SidebarProvider>
            <Sidebar>
              <SidebarContent>
                <SidebarHeader>
                  <Logo />
                </SidebarHeader>
                <SidebarMenu>
                  {isAdmin ? (
                    <>
                      {renderNavGroup(navConfig.admin)}
                      <SidebarGroup>
                        <SidebarGroupLabel>General</SidebarGroupLabel>
                        {renderNavGroup(navConfig.general)}
                        {renderNavSubMenu(navConfig.aiTools)}
                        {renderNavSubMenu(navConfig.explore)}
                        {renderNavSubMenu(navConfig.findProfessional)}
                        {renderNavGroup(navConfig.services)}
                      </SidebarGroup>
                    </>
                  ) : isProfessional ? (
                    <>
                      {isMaster && renderNavSubMenu(navConfig.masterFeatures)}
                      {renderNavSubMenu(navConfig.professionalDashboard)}
                      {renderNavSubMenu(navConfig.professionalTools)}
                      <SidebarGroup>
                          <SidebarGroupLabel>General</SidebarGroupLabel>
                          {renderNavGroup(navConfig.general)}
                      </SidebarGroup>
                    </>
                  ) : isRegularUser && user ? (
                    <>
                      {renderNavSubMenu(navConfig.userDashboard)}
                      {renderNavSubMenu(navConfig.userCommunity)}
                      <SidebarGroup>
                        <SidebarGroupLabel>General</SidebarGroupLabel>
                        {renderNavGroup(navConfig.general)}
                        {renderNavSubMenu(navConfig.explore)}
                        {renderNavSubMenu(navConfig.findProfessional)}
                      </SidebarGroup>
                    </>
                  ) : (
                    <>
                      {renderNavGroup(navConfig.general)}
                      {renderNavSubMenu(navConfig.aiTools)}
                      {renderNavSubMenu(navConfig.explore)}
                      {renderNavSubMenu(navConfig.findProfessional)}
                      {renderNavGroup(navConfig.services)}
                    </>
                  )}
                </SidebarMenu>
                <SidebarFooter>
                    <div className="flex items-center justify-between p-2">
                      {user ? (
                          <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                  <AvatarImage src={user.photoURL ?? undefined} />
                                  <AvatarFallback>{getInitials(user.email)}</AvatarFallback>
                              </Avatar>
                              <div className="flex flex-col overflow-hidden">
                                  <span className="text-sm font-medium text-sidebar-foreground truncate">{user.displayName || user.email}</span>
                                  {userData?.role && <span className="text-xs text-sidebar-foreground/70 capitalize">{userData?.role}</span>}
                              </div>
                          </div>
                      ) : <div></div>}
                      <ThemeToggle />
                    </div>
                  <SidebarMenu>
                    {user ? (
                      <SidebarMenuItem>
                        <SidebarMenuButton onClick={handleLogout}>
                          <LogOut />
                          <span>Logout</span>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ) : (
                      <SidebarMenuItem>
                        <SidebarMenuButton asChild>
                          <Link href="/login">
                            <LogIn />
                            <span>Login</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    )}
                  </SidebarMenu>
                </SidebarFooter>
              </SidebarContent>
            </Sidebar>
            <SidebarInset>
              <div className="flex h-full flex-col">
                <div className="md:hidden sticky top-0 bg-background z-10 border-b">
                  <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                      <PageHeader showTrigger={true} />
                  </div>
                </div>
                <main className="flex-1 p-4 md:p-6">
                  <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    {children}
                  </div>
                </main>
                <footer className="border-t bg-background/50">
                    <div className="container mx-auto px-8 py-6 flex flex-col sm:flex-row justify-between items-center gap-4">
                            <p className="text-sm text-muted-foreground">&copy; 2024 Homelya. All rights reserved.</p>
                        <div className="flex items-center gap-6">
                            <Link href="/terms" className="text-sm text-muted-foreground hover:text-primary">
                                Terms of Service
                            </Link>
                            <Link href="/privacy" className="text-sm text-muted-foreground hover:text-primary">
                                Privacy Policy
                            </Link>
                        </div>
                    </div>
                </footer>
                <VastuChatWidget />
              </div>
              <ComparisonBar />
            </SidebarInset>
          </SidebarProvider>
          <Toaster />
        </FavoritesProvider>
      </FollowProvider>
    </ComparisonProvider>
  )
}


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <title>Homelya - Nirman with all options</title>
        <meta name="description" content="Your trusted partner in home building solutions in Jharkhand." />
      </head>
      <body className={cn('font-sans antialiased', fontSans.variable)}>
         <AuthProvider>
            <ThemeProvider
                attribute="class"
                defaultTheme="system"
                enableSystem
                disableTransitionOnChange
            >
                <AppLayout>{children}</AppLayout>
            </ThemeProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
