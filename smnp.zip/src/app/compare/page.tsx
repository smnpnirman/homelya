
'use client';

import { useComparison } from '@/hooks/use-comparison';
import PageHeader from '@/components/page-header';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Scale, Trash2 } from 'lucide-react';
import Image from 'next/image';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import type { Design, Provider, Property, Item, ItemType } from '@/lib/types';
import { Badge } from '@/components/ui/badge';

const getPropertyAttributes = (item: Property) => [
    { name: 'Property Type', value: item.propertyType },
    { name: 'Location', value: item.location },
    { name: 'Area (sqft)', value: item.area.toLocaleString('en-IN') },
    { name: 'Bedrooms', value: item.bedrooms },
    { name: 'Bathrooms', value: item.bathrooms },
    { name: 'Price', value: `₹${item.price.toLocaleString('en-IN')}` },
];

const getProfessionalAttributes = (item: Provider) => [
    { name: 'Role', value: <Badge variant="outline" className="capitalize">{item.role}</Badge> },
    { name: 'Specialty', value: item.specialty || (item as any).category },
    { name: 'Location', value: item.location },
    { name: 'Rating', value: item.rating?.toFixed(1) },
    { name: 'Status', value: <Badge variant={item.status === 'verified' || item.status === 'master' ? 'default' : 'secondary'}>{item.status}</Badge> },
];

const getDesignAttributes = (item: Design) => [
    { name: 'Style', value: item.style },
    { name: 'Bedrooms', value: item.bedrooms },
    { name: 'Bathrooms', value: item.bathrooms },
    { name: 'Price', value: item.price ? `₹${item.price.toLocaleString('en-IN')}` : 'N/A' },
];

const getComparisonGroup = (type: ItemType | null): string | null => {
    if (!type) return null;
    if (['designer', 'constructor', 'supplier', 'seller'].includes(type)) {
        return 'professional';
    }
    return type;
}

export default function ComparePage() {
    const { items, itemType, removeItem, clearAll } = useComparison();

    if (items.length === 0) {
        return (
            <div className="text-center py-16">
                <div className="mx-auto bg-muted text-muted-foreground h-24 w-24 rounded-full flex items-center justify-center">
                    <Scale className="h-12 w-12"/>
                </div>
                <h2 className="mt-6 font-headline text-2xl">Nothing to Compare</h2>
                <p className="mt-2 text-muted-foreground">Add items to comparison to see them side-by-side.</p>
                <Button asChild className="mt-6">
                    <Link href="/designs">Start Browsing</Link>
                </Button>
            </div>
        )
    }

    const comparisonGroup = getComparisonGroup(itemType);

    let attributeNames: string[] = [];
    if (items.length > 0 && comparisonGroup) {
        if (comparisonGroup === 'design') attributeNames = getDesignAttributes(items[0] as Design).map(a => a.name);
        else if (comparisonGroup === 'property') attributeNames = getPropertyAttributes(items[0] as Property).map(a => a.name);
        else if (comparisonGroup === 'professional') attributeNames = getProfessionalAttributes(items[0] as Provider).map(a => a.name);
    }
    
    const getAttributeValue = (item: Item, attributeName: string) => {
        let attributes: {name: string, value: any}[] = [];
        if (comparisonGroup === 'design') attributes = getDesignAttributes(item as Design);
        else if (comparisonGroup === 'property') attributes = getPropertyAttributes(item as Property);
        else if (comparisonGroup === 'professional') attributes = getProfessionalAttributes(item as Provider);
        
        return attributes.find(a => a.name === attributeName)?.value;
    };

    const getItemTypeForLink = (item: Item): ItemType => {
        if ('role' in item && ['designer', 'constructor', 'supplier', 'seller'].includes(item.role)) {
            return item.role as ItemType;
        }
        if ('propertyType' in item) {
            return 'property';
        }
        return 'design';
    }

    return (
        <div className="space-y-8">
            <PageHeader title="Compare Items">
                <Button variant="outline" onClick={clearAll}>
                    <Trash2 className="mr-2 h-4 w-4"/>
                    Clear All
                </Button>
            </PageHeader>
            <Card>
                <CardContent className="p-0">
                    <div className="overflow-x-auto">
                        <Table className="min-w-[800px]">
                            <TableHeader>
                                <TableRow>
                                    <TableHead className="w-[200px] font-semibold">Feature</TableHead>
                                    {items.map(item => {
                                        const linkItemType = getItemTypeForLink(item);
                                        return (
                                        <TableHead key={item.id} className="w-1/4">
                                            <div className="flex flex-col items-center text-center gap-2">
                                                <Link href={`/${linkItemType}s/${item.id}`}>
                                                    <Image
                                                        src={item.image || 'https://picsum.photos/200'}
                                                        alt={item.name}
                                                        width={150}
                                                        height={150}
                                                        className="rounded-md object-cover aspect-square"
                                                    />
                                                </Link>
                                                <Link href={`/${linkItemType}s/${item.id}`} className="font-semibold hover:underline">{item.name}</Link>
                                                <Button variant="ghost" size="sm" onClick={() => removeItem(item.id)}>
                                                    <Trash2 className="mr-2 h-4 w-4"/> Remove
                                                </Button>
                                            </div>
                                        </TableHead>
                                    )})}
                                    {Array.from({ length: 3 - items.length }).map((_, index) => (
                                        <TableHead key={`placeholder-${index}`} className="w-1/4">
                                            <div className="flex flex-col items-center justify-center h-full text-center gap-2 p-4 border-2 border-dashed rounded-lg min-h-[250px]">
                                            <p className="text-muted-foreground">Add another item to compare</p>
                                            <Button asChild variant="secondary">
                                                <Link href={`/${itemType}s`}>Browse</Link>
                                            </Button>
                                            </div>
                                        </TableHead>
                                    ))}
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {attributeNames.map(name => (
                                    <TableRow key={name}>
                                        <TableCell className="font-semibold">{name}</TableCell>
                                        {items.map(item => (
                                            <TableCell key={item.id} className="text-center">
                                                {getAttributeValue(item, name)}
                                            </TableCell>
                                        ))}
                                        {Array.from({ length: 3 - items.length }).map((_, index) => (
                                            <TableCell key={`placeholder-cell-${index}`}></TableCell>
                                        ))}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}
