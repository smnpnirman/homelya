
'use client';

import { useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Bed, Bath, IndianRupee, Ruler, MapPin, Building, Phone, MessageSquare, ExternalLink } from 'lucide-react';
import PageHeader from '@/components/page-header';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useEffect, useState } from 'react';
import type { Property, Provider } from '@/lib/types';
import { db } from '@/lib/firebase';
import { ref, get } from 'firebase/database';
import { Skeleton } from '@/components/ui/skeleton';
import ShareButton from '@/components/share-button';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import SendInquiryDialog from '@/components/send-inquiry-dialog';
import { useAuth } from '@/hooks/use-auth';

export default function PropertyDetailsPage() {
  const params = useParams();
  const propertyId = params.id as string;
  const { userData } = useAuth();
  const isDubai = userData?.country === 'dubai';
  
  const [property, setProperty] = useState<Property | null>(null);
  const [seller, setSeller] = useState<Provider | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!propertyId) return;

    const fetchPropertyAndSeller = async () => {
      setLoading(true);
      try {
        const propertyRef = ref(db, `properties/${propertyId}`);
        const propertySnapshot = await get(propertyRef);
        if (propertySnapshot.exists()) {
          const propertyData = { id: propertyId, ...propertySnapshot.val() };
          setProperty(propertyData);

          if (propertyData.sellerId) {
            const sellerRef = ref(db, `users/${propertyData.sellerId}`);
            const sellerSnapshot = await get(sellerRef);
            if (sellerSnapshot.exists()) {
              const sellerDataFromDb = sellerSnapshot.val();
              setSeller({ 
                id: propertyData.sellerId, 
                ...sellerDataFromDb, 
                image: sellerDataFromDb.image || 'https://i.pravatar.cc/150', 
                dataAiHint: 'agent portrait' 
              });
            }
          }
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPropertyAndSeller();
  }, [propertyId]);
  

  if (loading) {
     return (
      <div className="space-y-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            <Skeleton className="w-full aspect-video rounded-lg" />
            <div className="grid grid-cols-4 gap-4">
                <Skeleton className="w-full aspect-square rounded-lg" />
                <Skeleton className="w-full aspect-square rounded-lg" />
                <Skeleton className="w-full aspect-square rounded-lg" />
                <Skeleton className="w-full aspect-square rounded-lg" />
            </div>
          </div>
          <div className="space-y-6">
              <Skeleton className="h-12 w-3/4" />
              <Skeleton className="h-8 w-1/2" />
              <Skeleton className="h-24 w-full" />
              <div className="grid grid-cols-2 gap-4">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
              </div>
              <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Property not found</h2>
        <p className="text-muted-foreground">The property you are looking for does not exist.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-4">
            <Carousel className="w-full">
                <CarouselContent>
                    {property.images?.map((img, index) => (
                        <CarouselItem key={index} className="relative group">
                            <Image
                                src={img}
                                alt={`${property.name} - Image ${index + 1}`}
                                width={1200}
                                height={800}
                                className="rounded-lg object-cover w-full aspect-video"
                                data-ai-hint={property.dataAiHint || 'property exterior'}
                            />
                            <Button asChild size="icon" variant="secondary" className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                <a href={img} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="h-5 w-5" />
                                    <span className="sr-only">View full image</span>
                                </a>
                            </Button>
                        </CarouselItem>
                    ))}
                </CarouselContent>
                <CarouselPrevious className="left-4"/>
                <CarouselNext className="right-4" />
            </Carousel>
             <div className="space-y-4 pt-4 border-t">
                <h2 className="font-headline text-2xl font-bold">Description</h2>
                <p className="text-muted-foreground whitespace-pre-wrap">{property.description}</p>
             </div>
        </div>
        <div className="space-y-6">
            <div className="flex justify-between items-start">
              <PageHeader title={property.name} className="p-0 border-b pb-4 flex-1" />
              <ShareButton title={property.name} text={`Check out this property: "${property.name}" on Homelya.`} />
            </div>
             <p className="text-4xl font-bold flex items-center">
                 {isDubai ? 'AED ' : <IndianRupee />} {property.price?.toLocaleString(isDubai ? undefined : 'en-IN')}
             </p>
            
            <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-muted/50 p-4 rounded-lg">
                    <Bed className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{property.bedrooms}</p>
                    <p className="text-sm text-muted-foreground">Bedrooms</p>
                </div>
                 <div className="bg-muted/50 p-4 rounded-lg">
                    <Bath className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{property.bathrooms}</p>
                    <p className="text-sm text-muted-foreground">Bathrooms</p>
                </div>
                 <div className="bg-muted/50 p-4 rounded-lg">
                    <Ruler className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{property.area.toLocaleString('en-IN')}</p>
                    <p className="text-sm text-muted-foreground">sq. ft.</p>
                </div>
                 <div className="bg-muted/50 p-4 rounded-lg">
                    <Building className="mx-auto h-8 w-8 text-primary"/>
                    <p className="font-bold text-lg mt-2">{property.propertyType}</p>
                    <p className="text-sm text-muted-foreground">Type</p>
                </div>
            </div>

            <div className="bg-muted/50 p-4 rounded-lg flex items-center gap-3">
                <MapPin className="h-6 w-6 text-primary shrink-0"/>
                <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="font-semibold text-lg">{property.location}</p>
                </div>
            </div>
            
        </div>
      </div>

     {seller && <section>
        <h2 className="font-headline text-2xl font-bold mb-4">Listed By</h2>
         <Card>
            <CardContent className="p-4 flex flex-col md:flex-row items-center gap-6">
                <Image src={seller.image!} alt={seller.name || 'Seller profile image'} width={100} height={100} className="rounded-full aspect-square object-cover" />
                <div className="flex-1 text-center md:text-left">
                    <h3 className="font-headline font-bold text-xl">{seller.name}</h3>
                    <p className="text-muted-foreground">{seller.specialty}</p>
                </div>
                <div className="flex flex-wrap gap-2 justify-center">
                    <SendInquiryDialog professionalId={seller.id} professionalName={seller.name} productName={property.name}>
                        <Button>
                            <MessageSquare /> Send Inquiry
                        </Button>
                    </SendInquiryDialog>
                    {seller.phone && 
                        <Button variant="outline" asChild>
                            <a href={`tel:${seller.phone}`}><Phone /> Call Now</a>
                        </Button>
                    }
                </div>
            </CardContent>
         </Card>
      </section>}
    </div>
  );
}
