

'use client';

import { useState, useMemo, useEffect, useCallback } from 'react';
import PageHeader from '@/components/page-header';
import ProfessionalListItem from '@/components/professional-list-item';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search } from 'lucide-react';
import { db } from '@/lib/firebase';
import { ref, onValue, set, push, serverTimestamp } from 'firebase/database';
import type { Supplier, Provider } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import AdBanner from '@/components/ad-banner';

export default function SuppliersPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');

  useEffect(() => {
    setLoading(true);
    const usersRef = ref(db, 'users');
    const unsubscribe = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const allUsers: any[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));

        const suppliersList: Supplier[] = allUsers
          .filter(user => user.role === 'supplier')
          .map(user => ({
            id: user.id,
            name: user.companyName,
            category: user.specialty || 'Not specified', // Using specialty as category
            location: user.location || 'Not specified',
            description: user.description || 'No description available.',
            image: user.image || 'https://picsum.photos/300/300',
            dataAiHint: 'warehouse shelves',
            rating: 4.5 + Math.random() * 0.5, // Placeholder rating
            status: user.status || 'in-progress',
            phone: user.phone,
        }));
        setSuppliers(suppliersList);
      } else {
        setSuppliers([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const supplierCategories = useMemo(() => [...new Set(suppliers.map((s) => s.category))], [suppliers]);
  const supplierLocations = useMemo(() => [...new Set(suppliers.map((s) => s.location))], [suppliers]);

  const generateLeadsForMasters = useCallback((location: string, masterProfessionals: Provider[]) => {
    if (!user || !location || masterProfessionals.length === 0) return;

    // Prevents professionals from getting leads from their own searches
    const currentUserIsProfessional = masterProfessionals.some(p => p.id === user.uid);
    if(currentUserIsProfessional) return;

    masterProfessionals.forEach(prof => {
        const leadRef = ref(db, `leads/${prof.id}`);
        const newLeadRef = push(leadRef);
        set(newLeadRef, {
            userName: user.displayName,
            userEmail: user.email,
            userPhone: user.phoneNumber || '',
            searchedLocation: location,
            timestamp: serverTimestamp(),
        }).catch(err => console.error("Failed to generate lead for", prof.id, err));
    });

    toast({
        title: "Master Professionals Notified",
        description: `Top professionals in ${location} have been notified of your interest.`,
    });

  }, [user, toast]);

  const filteredSuppliers = useMemo(() => {
    const filtered = suppliers.filter((supplier) => {
      const searchMatch = supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          supplier.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          supplier.category?.toLowerCase().includes(searchTerm.toLowerCase());
      const categoryMatch = categoryFilter === 'all' || supplier.category === categoryFilter;
      const locationMatch = locationFilter === 'all' || supplier.location === locationFilter;
      return searchMatch && categoryMatch && locationMatch;
    });

     if (locationFilter !== 'all') {
        const masterProfessionalsInLocation = filtered.filter(d => d.status === 'master');
        if (masterProfessionalsInLocation.length > 0) {
            generateLeadsForMasters(locationFilter, masterProfessionalsInLocation as Provider[]);
        }
    }
    
    return filtered;

  }, [searchTerm, categoryFilter, locationFilter, suppliers, generateLeadsForMasters]);

  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
       <Skeleton key={i} className="h-48 w-full" />
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader 
        title="Material Suppliers"
        description="Source high-quality materials from trusted suppliers in your area."
      />

      <AdBanner targetLocation={locationFilter !== 'all' ? locationFilter : undefined} />
      
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search suppliers by name, category..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter} disabled={loading}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {supplierCategories.map(category => (
              <SelectItem key={category} value={category}>{category}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={locationFilter} onValueChange={setLocationFilter} disabled={loading}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by location" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Locations</SelectItem>
            {supplierLocations.map(location => (
              <SelectItem key={location} value={location}>{location}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-6">
        {loading ? renderSkeletons() : filteredSuppliers.map((supplier) => (
          <ProfessionalListItem key={supplier.id} professional={supplier} itemType="supplier" />
        ))}
      </div>
      {!loading && filteredSuppliers.length === 0 && (
        <div className="text-center col-span-full py-12">
            <h3 className="font-headline text-xl font-semibold">No Suppliers Found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters, or check back later.</p>
        </div>
       )}
    </div>
  );
}
