import PageHeader from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Mail, Phone } from 'lucide-react';

export default function SupportPage() {
  return (
    <div className="space-y-8">
      <PageHeader
        title="Customer Support"
        description="We're here to help. Contact us with any questions or concerns."
      />
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <form>
            <CardHeader>
              <CardTitle className="font-headline">Send us a Message</CardTitle>
              <CardDescription>Our team will get back to you as soon as possible.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="first-name">First Name</Label>
                  <Input id="first-name" placeholder="John" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name">Last Name</Label>
                  <Input id="last-name" placeholder="Doe" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input type="email" id="email" placeholder="john.doe@example.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea id="message" placeholder="How can we help you today?" rows={5} />
              </div>
            </CardContent>
            <CardFooter>
              <Button>Send Message</Button>
            </CardFooter>
          </form>
        </Card>
        <div className="space-y-6">
          <h3 className="font-headline text-2xl font-bold">Contact Information</h3>
          <p className="text-muted-foreground">
            For immediate assistance, you can also reach us through the following channels. Our office hours are Monday to Saturday, 10:00 AM to 6:00 PM.
          </p>
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 text-primary p-3 rounded-lg">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <h4 className="font-semibold">Phone</h4>
                <p className="text-muted-foreground">
                  <a href="tel:+911234567890" className="hover:text-primary transition-colors">+91 123 456 7890</a>
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 text-primary p-3 rounded-lg">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <h4 className="font-semibold">Email</h4>
                <p className="text-muted-foreground">
                  <a href="mailto:support@homelya.com" className="hover:text-primary transition-colors">support@homelya.com</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
