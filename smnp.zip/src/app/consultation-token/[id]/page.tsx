
'use client';

import { useParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, get } from 'firebase/database';
import PageHeader from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { Loader2, Download, CheckCircle, Calendar, User, Mail, FileText, Hash, Phone, Briefcase } from 'lucide-react';
import Logo from '@/components/logo';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import html2canvas from 'html2canvas';

interface Consultation {
    id: string;
    userId: string;
    userName: string;
    userEmail: string;
    userPhone?: string;
    date: string;
    details: string;
    status: 'Pending' | 'Payment Pending' | 'Scheduled' | 'Completed' | 'Cancelled';
    timestamp: number;
    transactionId?: string;
    professionalNeeded: 'designer' | 'constructor' | 'supplier';
}

export default function ConsultationTokenPage() {
  const params = useParams();
  const consultationId = params.id as string;
  const [consultation, setConsultation] = useState<Consultation | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const tokenRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!consultationId) return;

    const fetchConsultation = async () => {
      setLoading(true);
      const consultationRef = ref(db, `consultations/${consultationId}`);
      try {
        const snapshot = await get(consultationRef);
        if (snapshot.exists()) {
          setConsultation({ id: consultationId, ...snapshot.val() });
        }
      } catch (error) {
        console.error("Error fetching consultation data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchConsultation();
  }, [consultationId]);

  const handleDownload = async () => {
    if (!tokenRef.current) return;
    setDownloading(true);
    try {
        const canvas = await html2canvas(tokenRef.current, { 
            backgroundColor: null, // Use transparent background
            scale: 2, // Increase resolution
        });
        const link = document.createElement('a');
        link.download = `homelya-consultation-token-${consultationId}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
    } catch(error) {
        console.error("Error downloading token:", error);
    } finally {
        setDownloading(false);
    }
  };

  const formattedTokenId = `SMNP-${consultationId.slice(-6).toUpperCase()}`;

  if (loading) {
    return (
        <div className="space-y-8 max-w-2xl mx-auto">
            <PageHeader title="Loading Your Token..." />
            <Card>
                <CardContent className="p-8">
                    <Skeleton className="h-96 w-full" />
                </CardContent>
            </Card>
        </div>
    )
  }

  if (!consultation) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Consultation Not Found</h2>
        <p className="text-muted-foreground">The consultation token you are looking for does not exist.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <PageHeader
        title="Consultation Booked Successfully!"
        description="Here is your confirmation token. Our team will contact you shortly."
      />
      <div 
        ref={tokenRef} 
        className="bg-card border rounded-lg p-8 space-y-6"
      >
        <div className="flex justify-between items-start">
            <Logo />
            <div className="text-right">
                <h2 className="font-bold text-lg">Consultation Token</h2>
                <p className="text-xs text-muted-foreground">Status: {consultation.status}</p>
            </div>
        </div>
        <Separator />
        <Card className="bg-primary/5">
            <CardHeader>
                <div className="flex items-center gap-2">
                    <CheckCircle className="text-green-500"/>
                    <CardTitle className="font-headline text-xl">Your request has been received</CardTitle>
                </div>
                <CardDescription>
                    We will be in touch with you at <span className="font-semibold">{consultation.userEmail}</span> to confirm your appointment.
                </CardDescription>
            </CardHeader>
        </Card>
        <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div className="space-y-4">
                <h3 className="font-semibold text-lg">Details</h3>
                <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-primary" />
                    <span>{consultation.userName}</span>
                </div>
                <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-primary" />
                    <span>{consultation.userEmail}</span>
                </div>
                 {consultation.userPhone && <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-primary" />
                    <span>{consultation.userPhone}</span>
                </div>}
                <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span>Requested Date: {format(new Date(consultation.date), 'PPP')}</span>
                </div>
                 <div className="flex items-center gap-2">
                    <Hash className="h-4 w-4 text-primary" />
                    <span className="break-all">ID: {formattedTokenId}</span>
                </div>
                 {consultation.professionalNeeded && <div className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4 text-primary" />
                    <span className="capitalize">Needed: {consultation.professionalNeeded}</span>
                </div>}
            </div>
            <div className="space-y-4">
                 <h3 className="font-semibold text-lg">Your Message</h3>
                <div className="flex items-start gap-2">
                    <FileText className="h-4 w-4 text-primary mt-1 shrink-0" />
                    <p className="text-muted-foreground whitespace-pre-wrap">{consultation.details}</p>
                </div>
            </div>
        </div>
        <Separator/>
        <p className="text-xs text-muted-foreground text-center">
            Booked on: {format(new Date(consultation.timestamp), 'PPP p')}
        </p>
      </div>

      <div className="text-center">
        <Button size="lg" onClick={handleDownload} disabled={downloading}>
            {downloading ? <Loader2 className="mr-2 animate-spin" /> : <Download className="mr-2" />}
            {downloading ? "Downloading..." : "Download Token"}
        </Button>
      </div>
    </div>
  );
}
