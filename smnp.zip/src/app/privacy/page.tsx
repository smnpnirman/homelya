
import PageHeader from "@/components/page-header";
import { Card, CardContent } from "@/components/ui/card";

export default function PrivacyPolicyPage() {
  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <PageHeader
        title="Privacy Policy"
        description="Last updated: October 26, 2024"
      />
      <Card>
        <CardContent className="pt-6 space-y-4">
          <p>
            At Homelya, accessible from homelya.com, one of our main priorities
            is the privacy of our visitors. This Privacy Policy document
            contains types of information that is collected and recorded by
            Homelya and how we use it.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Log Files</h2>
          <p>
            Homelya follows a standard procedure of using log files. These files
            log visitors when they visit websites. The information collected by
            log files include internet protocol (IP) addresses, browser type,
            Internet Service Provider (ISP), date and time stamp, referring/exit
            pages, and possibly the number of clicks.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Cookies and Web Beacons</h2>
          <p>
            Like any other website, Homelya uses 'cookies'. These cookies are
            used to store information including visitors' preferences, and the
            pages on the website that the visitor accessed or visited. The
            information is used to optimize the users' experience by customizing
            our web page content based on visitors' browser type and/or other
            information.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Our Advertising Partners</h2>
          <p>
            Some of advertisers on our site may use cookies and web beacons. Our
            advertising partners are listed below. Each of our advertising
            partners has their own Privacy Policy for their policies on user
            data.
          </p>
          <ul className="list-disc pl-6">
            <li>Google</li>
          </ul>

          <h2 className="font-headline text-xl font-bold pt-4">Privacy Policies</h2>
          <p>
            You may consult this list to find the Privacy Policy for each of the
            advertising partners of Homelya.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Third Party Privacy Policies</h2>
          <p>
            Homelya's Privacy Policy does not apply to other advertisers or
            websites. Thus, we are advising you to consult the respective
            Privacy Policies of these third-party ad servers for more detailed
            information.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Children's Information</h2>
          <p>
            Another part of our priority is adding protection for children while
            using the internet. We encourage parents and guardians to observe,
            participate in, and/or monitor and guide their online activity.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Online Privacy Policy Only</h2>
          <p>
            This Privacy Policy applies only to our online activities and is
            valid for visitors to our website with regards to the information
            that they shared and/or collect in Homelya. This policy is not
            applicable to any information collected offline or via channels
            other than this website.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
