
'use client';

import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, get, onValue, query, orderByChild } from 'firebase/database';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDistanceToNow } from 'date-fns';
import { Rss, UserPlus, Video } from 'lucide-react';
import type { Provider } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/hooks/use-auth';
import { useFollow } from '@/hooks/use-follow';
import { Button } from '@/components/ui/button';
import { getYouTubeEmbedUrl, getInstagramEmbedUrl } from '@/lib/utils';

interface Post {
    id: string;
    content: string;
    timestamp: number;
    videoUrl?: string;
}

const VideoEmbed = ({ url }: { url: string }) => {
    const youtubeUrl = getYouTubeEmbedUrl(url);
    if (youtubeUrl) {
        return (
            <iframe
                src={youtubeUrl}
                width="100%"
                className="aspect-video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
            ></iframe>
        );
    }
    
    const instagramUrl = getInstagramEmbedUrl(url);
    if (instagramUrl) {
         return (
             <iframe 
                src={instagramUrl}
                width="100%"
                className="aspect-video"
                frameBorder="0"
                allowFullScreen
            ></iframe>
         );
    }

    return <a href={url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{url}</a>;
}

export default function CommunityFeedPage() {
  const params = useParams();
  const professionalId = params.professionalId as string;
  
  const { user } = useAuth();
  const { follow, unfollow, isFollowing } = useFollow();
  const [professional, setProfessional] = useState<Provider | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  const isFollowed = isFollowing(professionalId);

  const handleFollow = () => {
    if (isFollowed) {
      unfollow(professionalId);
    } else {
      follow(professionalId);
    }
  };

  useEffect(() => {
    if (!professionalId) return;

    const fetchProfessional = async () => {
      setLoading(true);
      const professionalRef = ref(db, `users/${professionalId}`);
      try {
        const snapshot = await get(professionalRef);
        if (snapshot.exists()) {
          setProfessional({ id: professionalId, ...snapshot.val() });

          const postsQuery = query(ref(db, `community-posts/${professionalId}`), orderByChild('timestamp'));
          onValue(postsQuery, (postSnapshot) => {
            const data = postSnapshot.val();
            const postsList: Post[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => a.timestamp - b.timestamp) : []; // Sort ascending for chat view
            setPosts(postsList);
          });
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProfessional();
  }, [professionalId]);

  if (loading) {
    return (
      <div className="space-y-8 max-w-3xl mx-auto">
        <div className="flex items-center gap-4">
          <Skeleton className="h-16 w-16 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-5 w-48" />
          </div>
        </div>
        <div className="space-y-6">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
        </div>
      </div>
    );
  }

  if (!professional) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Community Not Found</h2>
        <p className="text-muted-foreground">The professional you are looking for does not exist or has not created a community.</p>
      </div>
    );
  }
  
  const getInitials = (name?: string) => {
      if (!name) return 'P';
      return name.substring(0, 2).toUpperCase();
  }

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      <Card className="overflow-hidden">
        <CardHeader className="flex flex-row items-center gap-4 bg-muted/50 p-4">
            <Avatar className="h-14 w-14 border">
                <AvatarImage src={professional.image} alt={professional.name} />
                <AvatarFallback>{getInitials(professional.name)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <CardTitle className="font-headline text-xl">{professional.name}</CardTitle>
                <CardDescription>{professional.specialty}</CardDescription>
            </div>
            {user && user.uid !== professional.id && (
                <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow}>
                    <UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}
                </Button>
            )}
        </CardHeader>
        <CardContent className="p-4 md:p-6 space-y-6 bg-card h-[60vh] overflow-y-auto">
            {posts.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                    <Rss className="mx-auto h-16 w-16 text-muted-foreground" />
                    <h3 className="mt-4 text-xl font-semibold">No posts yet.</h3>
                    <p className="mt-1 text-muted-foreground">This professional hasn't posted any updates yet.</p>
                </div>
            ) : (
                posts.map(post => (
                    <div key={post.id} className="flex items-end gap-3">
                        <Avatar className="h-10 w-10 border">
                            <AvatarImage src={professional.image} alt={professional.name} />
                            <AvatarFallback>{getInitials(professional.name)}</AvatarFallback>
                        </Avatar>
                        <div className="flex flex-col items-start max-w-lg">
                            <div className="bg-primary/10 text-primary-foreground p-3 rounded-2xl rounded-bl-none">
                                <p className="text-sm text-foreground whitespace-pre-wrap">{post.content}</p>
                                {post.videoUrl && (
                                    <div className="mt-2 rounded-lg overflow-hidden">
                                        <VideoEmbed url={post.videoUrl} />
                                    </div>
                                )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-1 ml-1">
                                {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}
                            </p>
                        </div>
                    </div>
                ))
            )}
        </CardContent>
      </Card>
    </div>
  );
}
