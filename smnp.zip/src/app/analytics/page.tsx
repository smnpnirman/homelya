
'use client';

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PageHeader from "@/components/page-header";
import LiveSalesDashboard from "@/components/dashboards/live-sales-dashboard";
import AuctionDashboard from "@/components/dashboards/auction-dashboard";

export default function AnalyticsPage() {
  return (
    <div className="space-y-8">
      <PageHeader
        title="Analytics Dashboards"
        description="View live sales and auction data in one place."
      />
      <Tabs defaultValue="sales" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="sales">Live Sales</TabsTrigger>
          <TabsTrigger value="auctions">Auctions</TabsTrigger>
        </TabsList>
        <TabsContent value="sales">
            <LiveSalesDashboard />
        </TabsContent>
        <TabsContent value="auctions">
            <AuctionDashboard />
        </TabsContent>
      </Tabs>
    </div>
  );
}
