
'use client';

import { useState, useMemo, useEffect } from 'react';
import PageHeader from '@/components/page-header';
import ItemCard from '@/components/item-card';
import { db } from '@/lib/firebase';
import { ref, onValue } from 'firebase/database';
import type { Design, DesignCategory } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const designCategories: DesignCategory[] = ["Architectural Plan", "Interior Design", "Wall Art", "Furniture Design"];

export default function DesignsPage() {
  const [designs, setDesigns] = useState<Design[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    setLoading(true);
    const designsRef = ref(db, 'designs');
    const unsubscribe = onValue(designsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const designsList: Design[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key],
          image: data[key].image || 'https://picsum.photos/600/400',
          dataAiHint: data[key].dataAiHint || 'modern house',
        }));
        setDesigns(designsList);
      } else {
        setDesigns([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const filteredDesigns = useMemo(() => {
    if (activeTab === 'all') return designs;
    return designs.filter((design) => design.category === activeTab);
  }, [activeTab, designs]);
  
  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
       <div key={i} className="space-y-2">
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-6 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-10 w-full" />
      </div>
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader 
        title="Design Marketplace"
        description="Browse our curated collection of architectural plans, interior designs, and more."
      />

      <Tabs defaultValue="all" onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="all">All</TabsTrigger>
          {designCategories.map(cat => (
             <TabsTrigger key={cat} value={cat}>{cat}</TabsTrigger>
          ))}
        </TabsList>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? renderSkeletons() : filteredDesigns.map((design) => (
            <ItemCard key={design.id} item={design} itemType="design" />
            ))}
        </div>
        {!loading && filteredDesigns.length === 0 && (
            <div className="text-center col-span-full py-12">
                <h3 className="font-headline text-xl font-semibold">No Designs Found</h3>
                <p className="text-muted-foreground">There are no designs in this category yet.</p>
            </div>
        )}
      </Tabs>
    </div>
  );
}

    