
'use client';

import { useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Bed, Bath, IndianRupee, MessageSquare, Star } from 'lucide-react';
import PageHeader from '@/components/page-header';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useEffect, useState } from 'react';
import type { Design, Provider } from '@/lib/types';
import { db } from '@/lib/firebase';
import { ref, get } from 'firebase/database';
import { Skeleton } from '@/components/ui/skeleton';
import ShareButton from '@/components/share-button';
import SendInquiryDialog from '@/components/send-inquiry-dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import DesignReviewSystem from '@/components/design-review-system';
import { Badge } from '@/components/ui/badge';
import ItemCard from '@/components/item-card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { useAuth } from '@/hooks/use-auth';
import { getYouTubeEmbedUrl, getInstagramEmbedUrl } from '@/lib/utils';

const VideoEmbed = ({ url }: { url: string }) => {
    const youtubeUrl = getYouTubeEmbedUrl(url);
    if (youtubeUrl) {
        return (
            <iframe
                src={youtubeUrl}
                width="100%"
                className="aspect-video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
            ></iframe>
        );
    }
    
    const instagramUrl = getInstagramEmbedUrl(url);
    if (instagramUrl) {
         return (
             <iframe 
                src={instagramUrl}
                width="100%"
                className="aspect-[9/16] sm:aspect-video"
                frameBorder="0"
                allowFullScreen
            ></iframe>
         );
    }

    return <p>Invalid video URL.</p>;
}

export default function DesignProfilePage() {
  const params = useParams();
  const designId = params.id as string;
  const { userData } = useAuth();
  const isDubai = userData?.country === 'dubai';
  
  const [design, setDesign] = useState<Design | null>(null);
  const [relatedDesigner, setRelatedDesigner] = useState<Provider | null>(null);
  const [relatedDesigns, setRelatedDesigns] = useState<Design[]>([]);
  const [loading, setLoading] = useState(true);
  const [avgRating, setAvgRating] = useState(0);
  const [reviewCount, setReviewCount] = useState(0);

  useEffect(() => {
    if (!designId) return;

    const fetchDesignData = async () => {
      setLoading(true);
      setRelatedDesigns([]); // Reset related designs on new fetch
      try {
        const designRef = ref(db, `designs/${designId}`);
        const designSnapshot = await get(designRef);

        if (designSnapshot.exists()) {
          const designData: Design = { id: designId, ...designSnapshot.val() };
          setDesign(designData);

          // Fetch designer
          if (designData.designerId) {
            const designerRef = ref(db, `users/${designData.designerId}`);
            const designerSnapshot = await get(designerRef);
            if (designerSnapshot.exists()) {
              const designerDataFromDb = designerSnapshot.val();
              setRelatedDesigner({ 
                id: designData.designerId, 
                ...designerDataFromDb, 
                image: designerDataFromDb.image || 'https://i.pravatar.cc/150', 
                dataAiHint: 'architect portrait' 
              });
            }
          }

          // Fetch related designs
          const allDesignsRef = ref(db, 'designs');
          const allDesignsSnapshot = await get(allDesignsRef);
          if (allDesignsSnapshot.exists()) {
              const allDesignsData = allDesignsSnapshot.val();
              const related = Object.keys(allDesignsData)
                  .map(key => ({ id: key, ...allDesignsData[key], image: allDesignsData[key].image || `https://picsum.photos/seed/${key}/600/400` }))
                  .filter((d): d is Design => d.category === designData.category && d.id !== designId)
                  .slice(0, 3); // Take first 3 related designs
              setRelatedDesigns(related);
          }

        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDesignData();
  }, [designId]);

  const handleStatsUpdate = (average: number, count: number) => {
    setAvgRating(average);
    setReviewCount(count);
  };
  

  if (loading) {
     return (
      <div className="space-y-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <Skeleton className="w-full aspect-[3/2] rounded-lg" />
          </div>
          <div className="space-y-6">
              <Skeleton className="h-12 w-3/4" />
              <Skeleton className="h-24 w-full" />
              <div className="grid grid-cols-2 gap-4">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
              </div>
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!design) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Design not found</h2>
        <p className="text-muted-foreground">The design you are looking for does not exist.</p>
      </div>
    );
  }

  const designImages = Array.isArray(design.images) ? design.images : (design.images ? Object.values(design.images) : []);
  const imagesToShow = designImages.length > 0 ? designImages : [design.image || 'https://picsum.photos/1200/800'];

  return (
    <div className="space-y-8">
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-4">
            <Carousel className="w-full rounded-lg overflow-hidden">
                <CarouselContent>
                    {imagesToShow.map((img, index) => (
                        <CarouselItem key={index}>
                            <Image
                                src={img}
                                alt={`${design.name} - Image ${index + 1}`}
                                width={1200}
                                height={800}
                                className="object-cover w-full aspect-[3/2]"
                                data-ai-hint={design.dataAiHint || 'modern house'}
                            />
                        </CarouselItem>
                    ))}
                </CarouselContent>
                {imagesToShow.length > 1 && (
                    <>
                        <CarouselPrevious className="left-4"/>
                        <CarouselNext className="right-4"/>
                    </>
                )}
            </Carousel>
            {design.videoUrl && (
                <div className="space-y-4 pt-4 border-t">
                    <h2 className="font-headline text-2xl font-bold">Video Showcase</h2>
                    <div className="aspect-video rounded-lg overflow-hidden">
                        <VideoEmbed url={design.videoUrl}/>
                    </div>
                </div>
            )}
             <div className="space-y-4 pt-4 border-t">
                <h2 className="font-headline text-2xl font-bold">Description</h2>
                <p className="text-muted-foreground whitespace-pre-wrap">{design.description}</p>
             </div>
        </div>
        <div className="space-y-6">
            <div className="flex justify-between items-start">
              <div className="flex-1 space-y-2">
                <Badge variant="secondary">{design.category}</Badge>
                <PageHeader title={design.name} className="p-0" />
                 {reviewCount > 0 && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-0.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                            key={star}
                            className={`h-4 w-4 ${
                                avgRating >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
                            }`}
                            />
                        ))}
                        </div>
                        <span className="font-semibold">{avgRating.toFixed(1)}</span>
                        <span>({reviewCount} reviews)</span>
                    </div>
                )}
              </div>
              <ShareButton title={design.name} text={`Check out the "${design.name}" design on Homelya.`} />
            </div>
            
            <p className="text-muted-foreground text-lg">{design.description}</p>
            
            {(design.bedrooms || design.bathrooms) ? (
              <div className="grid grid-cols-2 gap-4 text-center">
                {design.bedrooms && design.bedrooms > 0 && (
                  <div className="bg-muted/50 p-4 rounded-lg">
                      <Bed className="mx-auto h-8 w-8 text-primary"/>
                      <p className="font-bold text-lg mt-2">{design.bedrooms}</p>
                      <p className="text-sm text-muted-foreground">Bedrooms</p>
                  </div>
                )}
                {design.bathrooms && design.bathrooms > 0 && (
                  <div className="bg-muted/50 p-4 rounded-lg">
                      <Bath className="mx-auto h-8 w-8 text-primary"/>
                      <p className="font-bold text-lg mt-2">{design.bathrooms}</p>
                      <p className="text-sm text-muted-foreground">Bathrooms</p>
                  </div>
                )}
              </div>
            ) : null}


             <div className="bg-muted/50 p-4 rounded-lg text-center">
                <p className="text-sm text-muted-foreground">Style</p>
                <p className="font-bold text-lg">{design.style}</p>
            </div>
            
            <Card className="bg-primary/5 border-primary/10">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Purchase</CardTitle>
                    <CardDescription>Get the complete file for this design product.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-4xl font-bold flex items-center">
                        {isDubai ? 'AED ' : <IndianRupee />} {design.price?.toLocaleString(isDubai ? undefined : 'en-IN') || '50,000'}
                    </p>
                </CardContent>
                <CardFooter>
                    <Button size="lg" className="w-full" asChild>
                        <Link href={`/payment/${design.id}`}>Buy Now</Link>
                    </Button>
                </CardFooter>
            </Card>
            {relatedDesigner && (
              <Card>
                  <CardHeader>
                      <CardTitle className="font-headline text-lg">Designed By</CardTitle>
                  </CardHeader>
                  <CardContent>
                      <div className="flex items-center gap-4">
                      <Link href={`/designers/${relatedDesigner.id}`}>
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={relatedDesigner.image} alt={relatedDesigner.name} />
                            <AvatarFallback>{relatedDesigner.name?.charAt(0)}</AvatarFallback>
                          </Avatar>
                      </Link>
                      <div>
                          <Link href={`/designers/${relatedDesigner.id}`} className="font-semibold hover:underline">
                              {relatedDesigner.name}
                          </Link>
                          <p className="text-sm text-muted-foreground">{relatedDesigner.specialty}</p>
                      </div>
                      </div>
                  </CardContent>
                  <CardFooter className="grid grid-cols-2 gap-2">
                      <SendInquiryDialog professionalId={relatedDesigner.id} professionalName={relatedDesigner.name}>
                          <Button variant="outline" className="w-full">
                              <MessageSquare className="mr-2 h-4 w-4" />
                              Contact
                          </Button>
                      </SendInquiryDialog>
                      <Button asChild className="w-full">
                          <Link href={`/designers/${relatedDesigner.id}`}>View Profile</Link>
                      </Button>
                  </CardFooter>
              </Card>
            )}
        </div>
      </div>
      <DesignReviewSystem designId={designId} onStatsUpdate={handleStatsUpdate} />

      {relatedDesigns.length > 0 && (
        <section className="pt-8 border-t">
            <h2 className="font-headline text-2xl font-bold mb-4">Related Designs</h2>
            <Carousel
                opts={{
                    align: "start",
                    loop: relatedDesigns.length > 3,
                }}
                className="w-full"
            >
                <CarouselContent>
                    {relatedDesigns.map((relatedDesign) => (
                        <CarouselItem key={relatedDesign.id} className="basis-1/2 md:basis-1/3 lg:basis-1/4">
                             <div className="p-1 h-full">
                                <ItemCard item={relatedDesign} itemType="design" />
                             </div>
                        </CarouselItem>
                    ))}
                </CarouselContent>
                <CarouselPrevious className="hidden md:flex"/>
                <CarouselNext className="hidden md:flex"/>
            </Carousel>
        </section>
      )}
    </div>
  );
}
