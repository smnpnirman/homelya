
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, update } from "firebase/database";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import { format } from "date-fns";

interface Consultation {
    id: string;
    userId: string;
    userName: string;
    userEmail: string;
    date: string;
    details: string;
    status: 'Pending' | 'Payment Pending' | 'Scheduled' | 'Completed' | 'Cancelled';
    timestamp: number;
    transactionId?: string;
    professionalNeeded?: 'designer' | 'constructor' | 'supplier';
    completedByUid?: string;
    completedByName?: string;
    completionTimestamp?: number;
}

function consultationStatusToJsx(status: Consultation['status']) {
    switch(status) {
        case 'Pending':
            return <Badge variant="outline">Pending</Badge>;
        case 'Payment Pending':
            return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700">Payment Pending</Badge>;
        case 'Scheduled':
            return <Badge variant="default">Scheduled</Badge>;
        case 'Completed':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700">Completed</Badge>;
        case 'Cancelled':
            return <Badge variant="destructive">Cancelled</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function ManageConsultationsPage() {
    const { user } = useAuth();
    const router = useRouter();
    const { toast } = useToast();
    const [allConsultations, setAllConsultations] = useState<Consultation[]>([]);
    const [loadingConsultations, setLoadingConsultations] = useState(true);
    
    useEffect(() => {
        setLoadingConsultations(true);
        const consultationsRef = ref(db, 'consultations');
        const unsubscribeConsultations = onValue(consultationsRef, (snapshot) => {
            const data = snapshot.val();
            const consultationsList: Consultation[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.timestamp - a.timestamp) : [];
            setAllConsultations(consultationsList);
            setLoadingConsultations(false);
        }, { onlyOnce: false });

        return () => {
            unsubscribeConsultations();
        };
    }, []);

    const handleShowToken = (consultationId: string) => {
        router.push(`/consultation-token/${consultationId}`);
    }

    const handleConfirmPayment = async (consultationId: string) => {
        const consultationRef = ref(db, `consultations/${consultationId}`);
        try {
          await update(consultationRef, { status: 'Pending' });
          toast({
            title: 'Payment Confirmed!',
            description: 'The consultation is now visible to professionals.',
          });
        } catch (error) {
          console.error('Error confirming payment:', error);
          toast({
            variant: 'destructive',
            title: 'Confirmation Failed',
            description: 'Could not update the consultation status.',
          });
        }
    };

    if (!user) {
        return (
          <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                <CardDescription>You must be logged in as an admin to view this page.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        );
    }
  
    return (
        <div className="space-y-8">
            <PageHeader
                title="Consultation Requests"
                description="Manage free and paid consultation requests from users."
            />
            <Card>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>User</TableHead>
                                <TableHead>Professional Needed</TableHead>
                                <TableHead>Transaction ID</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Completed By</TableHead>
                                <TableHead>Requested On</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loadingConsultations ? (
                                Array.from({length: 5}).map((_, i) => (
                                    <TableRow key={i}>
                                        <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell className="text-right"><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                                    </TableRow>
                                ))
                            ) : allConsultations.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={7} className="h-24 text-center">
                                        No consultation requests found.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                allConsultations.map(consult => (
                                    <TableRow key={consult.id}>
                                        <TableCell className="font-medium">{consult.userName}</TableCell>
                                        <TableCell className="capitalize">{consult.professionalNeeded || 'Any'}</TableCell>
                                        <TableCell className="font-mono text-xs">{consult.transactionId || 'N/A'}</TableCell>
                                        <TableCell>{consultationStatusToJsx(consult.status)}</TableCell>
                                        <TableCell>
                                            {consult.status === 'Completed' ? (
                                                <div>
                                                    <p className="font-medium">{consult.completedByName || 'N/A'}</p>
                                                    {consult.completionTimestamp && 
                                                        <p className="text-xs text-muted-foreground">{format(new Date(consult.completionTimestamp), 'PPP')}</p>
                                                    }
                                                </div>
                                            ) : (
                                                <span className="text-muted-foreground">N/A</span>
                                            )}
                                        </TableCell>
                                        <TableCell>{format(new Date(consult.timestamp), 'PPP p')}</TableCell>
                                        <TableCell className="text-right">
                                                {consult.status === 'Payment Pending' ? (
                                                <Button variant="secondary" size="sm" onClick={() => handleConfirmPayment(consult.id)}>
                                                    <CheckCircle className="mr-2 h-3.5 w-3.5" />
                                                    Confirm Payment
                                                </Button>
                                            ) : (
                                                <Button variant="outline" size="sm" onClick={() => handleShowToken(consult.id)}>
                                                    <FileText className="mr-2 h-3.5 w-3.5" />
                                                    Show Token
                                                </Button>
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
