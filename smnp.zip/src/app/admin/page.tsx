

'use client';

import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Users, LayoutTemplate, MessageSquare, Landmark, FileText, ArrowRight, View, Megaphone, MapPin, CalendarDays, Sparkles, Tag } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

const adminLinks = [
    { href: "/admin/manage-users", icon: Users, title: "Manage Users", description: "View, verify, and manage all user and professional accounts." },
    { href: "/admin/manage-designs", icon: LayoutTemplate, title: "Manage Designs", description: "Add, edit, or remove home designs from the platform." },
    { href: "/admin/manage-consultations", icon: MessageSquare, title: "Manage Consultations", description: "Oversee all free and paid consultation requests from users." },
    { href: "/admin/manage-loans", icon: Landmark, title: "Manage Home Loans", description: "Review and update the status of home loan applications." },
    { href: "/admin/manage-inquiries", icon: FileText, title: "Manage Inquiries", description: "Access all inquiries sent through the platform." },
    { href: "/admin/manage-vr-orders", icon: View, title: "Manage VR Orders", description: "Approve and assign VR kits to professionals." },
    { href: "/admin/manage-ads", icon: Megaphone, title: "Manage Ads", description: "Approve and manage professional advertisements." },
    { href: "/admin/manage-address-verifications", icon: MapPin, title: "Address Verifications", description: "Approve and manage address verification requests." },
    { href: "/admin/manage-events", icon: CalendarDays, title: "Manage Events", description: "Review, approve, and manage all professional events." },
    { href: "/admin/manage-banners", icon: Sparkles, title: "Manage Banners", description: "Create and manage promotional festival banners." },
    { href: "/admin/manage-offers", icon: Tag, title: "Manage Offers", description: "Create and manage promotional offers and discounts." },
];

export default function AdminPage() {
    const { user } = useAuth();

    // A basic check, ideally should check role from DB too
    if (!user) {
        return (
            <div className="text-center py-12">
                <Card className="max-w-md mx-auto">
                    <CardHeader>
                        <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                        <CardDescription>You must be logged in as an admin to view this page.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button asChild>
                            <Link href="/login">Login</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }
  return (
    <div className="space-y-8">
      <PageHeader
        title="Admin Dashboard"
        description="Manage users, inquiries, and settings for the entire platform."
      />

       <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {adminLinks.map((link) => (
                <Card key={link.href} className="flex flex-col">
                    <CardHeader>
                        <div className="flex items-center gap-4">
                            <div className="bg-primary/10 text-primary p-3 rounded-lg">
                                <link.icon className="h-6 w-6" />
                            </div>
                            <CardTitle className="font-headline">{link.title}</CardTitle>
                        </div>
                    </CardHeader>
                    <CardContent className="flex-1">
                        <CardDescription>{link.description}</CardDescription>
                    </CardContent>
                    <CardContent>
                        <Button asChild className="w-full">
                            <Link href={link.href}>
                                Go to {link.title} <ArrowRight className="ml-2"/>
                            </Link>
                        </Button>
                    </CardContent>
                </Card>
            ))}
        </div>
    </div>
  );
}
