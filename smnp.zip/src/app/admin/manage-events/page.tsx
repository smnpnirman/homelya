
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, update } from "firebase/database";
import type { AppEvent, EventStatus } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, ChevronDown, Clock, XCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

// Helper function to render status badge
function eventStatusToJsx(status: EventStatus) {
    switch(status) {
        case 'pending':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><Clock className="mr-1.5" />Pending</Badge>;
        case 'approved':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="mr-1.5" />Approved</Badge>;
        case 'rejected':
            return <Badge variant="destructive"><XCircle className="mr-1.5" />Rejected</Badge>;
        case 'completed':
            return <Badge variant="secondary">Completed</Badge>;
        case 'cancelled':
            return <Badge variant="destructive">Cancelled</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function ManageEventsPage() {
    const { user } = useAuth();
    const { toast } = useToast();
    const [allEvents, setAllEvents] = useState<AppEvent[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        const eventsRef = ref(db, 'events');
        const unsubscribe = onValue(eventsRef, (snapshot) => {
            const data = snapshot.val();
            const eventsList: AppEvent[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.createdAt - a.createdAt) : [];
            setAllEvents(eventsList);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const handleUpdateStatus = async (eventId: string, newStatus: EventStatus) => {
        const eventRef = ref(db, `events/${eventId}`);
        try {
            await update(eventRef, { status: newStatus });
            toast({
                title: 'Event Status Updated!',
                description: `The event status has been changed to "${newStatus}".`,
            });
        } catch (error) {
            console.error("Error updating event status:", error);
            toast({
                variant: "destructive",
                title: "Update Failed",
                description: "Could not update the event status.",
            });
        }
    }
    
    if (!user) { // Assuming admin role check is implicit in '/admin' layout/route guard
        return (
          <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                <CardDescription>You must be an admin to view this page.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        );
    }

    return (
        <div className="space-y-8">
            <PageHeader
                title="Event Management"
                description="Review, approve, and manage all professional events."
            />
            <Card>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Event Title</TableHead>
                                <TableHead>Professional</TableHead>
                                <TableHead>Event Date</TableHead>
                                <TableHead>Type</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                Array.from({length: 5}).map((_, i) => (
                                    <TableRow key={i}>
                                        <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell className="text-right"><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                                    </TableRow>
                                ))
                            ) : allEvents.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-24 text-center">
                                        No events found.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                allEvents.map(appEvent => (
                                    <TableRow key={appEvent.id}>
                                        <TableCell className="font-medium">{appEvent.name}</TableCell>
                                        <TableCell>{appEvent.professionalName}</TableCell>
                                        <TableCell>{format(new Date(appEvent.eventDate), 'PPP')}</TableCell>
                                        <TableCell className="capitalize">{appEvent.eventType}</TableCell>
                                        <TableCell>{eventStatusToJsx(appEvent.status)}</TableCell>
                                        <TableCell className="text-right">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" size="sm">
                                                        Update Status
                                                        <ChevronDown className="ml-2 h-4 w-4" />
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(appEvent.id, 'pending')}>Pending</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(appEvent.id, 'approved')}>Approve</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(appEvent.id, 'completed')}>Complete</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(appEvent.id, 'cancelled')}>Cancel</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(appEvent.id, 'rejected')} className="text-red-600">Reject</DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
