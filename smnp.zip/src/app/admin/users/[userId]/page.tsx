
import { db } from '@/lib/firebase';
import { ref, get } from 'firebase/database';
import PageHeader from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Mail, Phone, Briefcase, MapPin, BadgePercent, Building, FileText, CheckCircle, Clock, Fingerprint } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { Provider, VerificationStatus } from '@/lib/types';
import { notFound } from 'next/navigation';

type UserProfile = Provider & {
  role: string;
  pincode: string;
  upiId: string;
};

function VerificationStatusBadge({ status }: { status: VerificationStatus }) {
    if (status === 'verified') {
        return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="h-4 w-4 mr-1"/>Verified</Badge>;
    }
    if (status === 'payment-pending') {
        return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700"><Clock className="h-4 w-4 mr-1" />Payment Pending</Badge>;
    }
    return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><Clock className="h-4 w-4 mr-1" />In Progress</Badge>;
}

async function getUserData(userId: string): Promise<UserProfile | null> {
    const userRef = ref(db, `users/${userId}`);
    try {
        const snapshot = await get(userRef);
        if (snapshot.exists()) {
            return snapshot.val();
        }
        return null;
    } catch (error) {
        console.error("Error fetching user data:", error);
        return null;
    }
}


export default async function AdminUserDetailsPage({ params }: { params: { userId: string } }) {
  const userId = params.userId;
  const userProfile = await getUserData(userId);

  if (!userProfile) {
    notFound();
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Professional Profile Details"
        description={`Reviewing profile for ${userProfile.companyName || userProfile.email}`}
      />
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="font-headline text-2xl">{userProfile.companyName}</CardTitle>
              <CardDescription className="capitalize">{userProfile.role}</CardDescription>
            </div>
            <VerificationStatusBadge status={userProfile.status || 'in-progress'} />
          </div>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-x-8 gap-y-6 text-sm">
            {userProfile.smnpId && <div className="flex items-center gap-3 md:col-span-2">
                <Fingerprint className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">SMNP Registration ID</p>
                    <p className="text-muted-foreground font-mono">{userProfile.smnpId}</p>
                </div>
            </div>}
            <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">Email</p>
                    <p className="text-muted-foreground">{userProfile.email}</p>
                </div>
            </div>
             <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">Phone</p>
                    <p className="text-muted-foreground">{userProfile.phone}</p>
                </div>
            </div>
            <div className="flex items-center gap-3">
                <Briefcase className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">Specialty / Category</p>
                    <p className="text-muted-foreground">{userProfile.specialty}</p>
                </div>
            </div>
            <div className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">Location & Pincode</p>
                    <p className="text-muted-foreground">{userProfile.location}, {userProfile.pincode}</p>
                </div>
            </div>
            {userProfile.gstNumber && <div className="flex items-center gap-3">
                <BadgePercent className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">GST Number</p>
                    <p className="text-muted-foreground">{userProfile.gstNumber}</p>
                </div>
            </div>}
            {userProfile.architectureRegistrationNumber && <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">Architecture Registration Number</p>
                    <p className="text-muted-foreground">{userProfile.architectureRegistrationNumber}</p>
                </div>
            </div>}
            {userProfile.localAuthorityRegistrationNumber && <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-primary" />
                <div>
                    <p className="font-semibold">Local Authority Registration No.</p>
                    <p className="text-muted-foreground">{userProfile.localAuthorityRegistrationNumber}</p>
                </div>
            </div>}
            <div className="md:col-span-2 flex items-start gap-3">
                <Building className="h-5 w-5 text-primary mt-1" />
                <div>
                    <p className="font-semibold">Company Description</p>
                    <p className="text-muted-foreground whitespace-pre-wrap">{userProfile.description}</p>
                </div>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
