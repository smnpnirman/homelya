

'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, update, remove, push, serverTimestamp, runTransaction, get } from "firebase/database";
import type { Provider, Supplier, VerificationStatus } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, ShieldAlert, CheckCircle, MoreVertical, Trash2, Edit, Send, Eye, Clock, Gem } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import SendNotificationDialog from "@/components/send-notification-dialog";
import { useRouter } from "next/navigation";

type UserProfile = (Provider | Supplier) & { id: string, role: string, email: string, displayName?: string, gstNumber?: string, smnpId?: string };

function statusToJsx(status: VerificationStatus, role: string) {
    switch (status) {
        case 'verified':
            return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><ShieldCheck className="h-4 w-4 mr-1"/>Verified</Badge>;
        case 'master':
            return <Badge variant="secondary" className="border-purple-500/50 bg-purple-500/10 text-purple-700"><Gem className="h-4 w-4 mr-1"/>Master</Badge>;
        case 'payment-pending':
            return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700"><Clock className="h-4 w-4 mr-1"/>Payment Pending</Badge>;
        case 'master-payment-pending':
            return <Badge variant="secondary" className="border-purple-500/50 bg-purple-500/10 text-purple-700"><Clock className="h-4 w-4 mr-1"/>Master Payment</Badge>;
        case 'in-progress':
             return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><ShieldAlert className="h-4 w-4 mr-1"/>In Process</Badge>;
        case 'user':
             return <Badge variant="outline">User</Badge>;
        default:
            return null;
    }
}

export default function ManageUsersPage() {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [userToNotify, setUserToNotify] = useState<UserProfile | null>(null);

  useEffect(() => {
    setLoadingUsers(true);
    const usersRef = ref(db, 'users');
    const unsubscribeUsers = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      const usersList: UserProfile[] = data ? Object.keys(data).map(key => ({
            id: key,
            role: data[key].role || 'user', // default
            status: data[key].status || (data[key].role === 'user' ? 'user' : 'in-progress'),
            ...data[key],
      })) : [];
      setAllUsers(usersList);
      setLoadingUsers(false);
    }, { onlyOnce: false });

    return () => {
        unsubscribeUsers();
    };
  }, []); 

  const handleVerify = async (userId: string, targetStatus: 'verified' | 'master') => {
    const userRef = ref(db, `users/${userId}`);
    try {
        if (targetStatus === 'master') {
             await update(userRef, { status: 'master' });
             toast({
                title: "Upgraded to Master!",
                description: "The user's status has been updated to 'master'.",
            });
            return;
        }

        const userSnapshot = await get(userRef);
        if (!userSnapshot.exists() || userSnapshot.val().smnpId) {
            await update(userRef, { status: 'verified' });
            toast({
                title: "Professional Verified!",
                description: "The user's status has been updated to 'verified'.",
            });
            return;
        }

        const counterRef = ref(db, 'counters/professionalId');
        const transactionResult = await runTransaction(counterRef, (currentValue) => {
            return (currentValue || 0) + 1;
        });

        const newId = transactionResult.snapshot.val();
        const smnpId = `SMNP${String(newId).padStart(4, '0')}`;

        await update(userRef, { status: 'verified', smnpId: smnpId });
        toast({
            title: "Professional Verified!",
            description: `The user's status has been updated and they have been assigned SMNP ID: ${smnpId}.`,
        });
    } catch (error) {
        console.error("Error verifying user:", error);
        toast({
            variant: "destructive",
            title: "Verification Failed",
            description: "Could not update the user's status.",
        });
    }
  }

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    const userRef = ref(db, `users/${userToDelete.id}`);
    try {
        await remove(userRef);
        toast({
            title: "User Deleted",
            description: `${userToDelete.displayName || userToDelete.email} has been removed from the database.`,
        });
    } catch (error) {
         console.error("Error deleting user:", error);
        toast({
            variant: "destructive",
            title: "Deletion Failed",
            description: "Could not delete the user.",
        });
    } finally {
        setUserToDelete(null);
    }
  }

  const handleSendNotification = async (title: string, message: string) => {
    if (!userToNotify) return false;
     const notificationData = {
        title,
        message,
        timestamp: serverTimestamp(),
        read: false,
    };

    try {
        const notificationsRef = ref(db, `notifications/${userToNotify.id}`);
        await push(notificationsRef, notificationData);
        toast({
            title: "Notification Sent!",
            description: `A notification has been sent to ${userToNotify.displayName || userToNotify.email}.`
        });
        return true;
    } catch(error) {
        console.error("Error sending notification:", error);
        toast({
            variant: "destructive",
            title: "Failed to Send",
            description: "Could not send the notification.",
        });
        return false;
    }
  }

  const handleUpdateProfile = (profId: string) => {
      router.push(`/admin/edit-user/${profId}`);
  }
  
  const handleViewDetails = (userId: string) => {
      router.push(`/admin/users/${userId}`);
  }

  if (!user) { 
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in as an admin to view this page.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-8">
        <PageHeader
          title="User & Professional Management"
          description="View all registered users and manage professional accounts."
        />
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name / Company</TableHead>
                  <TableHead>SMNP ID</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingUsers ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-28" /></TableCell>
                      <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : (
                  allUsers.map(prof => (
                    <TableRow key={prof.id}>
                      <TableCell className="font-medium">{prof.companyName || prof.displayName || prof.email}</TableCell>
                      <TableCell className="font-mono text-xs">{prof.smnpId || 'N/A'}</TableCell>
                      <TableCell className="capitalize">{prof.role}</TableCell>
                      <TableCell>{statusToJsx(prof.status, prof.role)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                              <span className="sr-only">More Actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {prof.role !== 'user' && (
                              <DropdownMenuItem onClick={() => handleViewDetails(prof.id)}>
                                <Eye className="mr-2 h-4 w-4" />
                                View Details
                              </DropdownMenuItem>
                            )}
                            {prof.status === 'payment-pending' && (
                              <DropdownMenuItem onClick={() => handleVerify(prof.id, 'verified')}>
                                <CheckCircle className="mr-2 h-4 w-4" />
                                Approve Basic Verification
                              </DropdownMenuItem>
                            )}
                             {prof.status === 'master-payment-pending' && (
                              <DropdownMenuItem onClick={() => handleVerify(prof.id, 'master')}>
                                <Gem className="mr-2 h-4 w-4" />
                                Approve Master Upgrade
                              </DropdownMenuItem>
                            )}
                            {prof.role !== 'user' && (
                              <DropdownMenuItem onClick={() => handleUpdateProfile(prof.id)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Update Profile
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => setUserToNotify(prof)}>
                              <Send className="mr-2 h-4 w-4" />
                              Send Notification
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-red-600 focus:text-red-600 focus:bg-red-50"
                              onClick={() => setUserToDelete(prof)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete User
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            {!loadingUsers && allUsers.length === 0 && (
              <div className="text-center p-8 text-muted-foreground">
                No users found.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={!!userToDelete} onOpenChange={(open) => !open && setUserToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the user account
              for <span className="font-bold">{userToDelete?.displayName || userToDelete?.email}</span> and remove their data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteUser} className="bg-destructive hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <SendNotificationDialog
        isOpen={!!userToNotify}
        onClose={() => setUserToNotify(null)}
        onSend={handleSendNotification}
        professionalName={userToNotify?.displayName || userToNotify?.email || ''}
      />
    </>
  );
}
