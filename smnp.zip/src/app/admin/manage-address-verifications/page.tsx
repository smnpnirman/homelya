
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, update } from "firebase/database";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, XCircle, Home, Mail, User, ShieldQuestion, Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface VerificationRequest {
    id: string;
    userId: string;
    userName: string;
    address: string;
    status: 'pending' | 'approved' | 'code_sent' | 'verified' | 'rejected' | 'agent_assigned';
    verificationMethod: 'postal_code' | 'agent';
    timestamp: number;
    verificationCode?: string;
}

function statusToJsx(status: VerificationRequest['status']) {
    switch(status) {
        case 'pending':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><Clock className="mr-1.5" />Pending</Badge>;
        case 'approved':
             return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700"><CheckCircle className="mr-1.5" />Approved</Badge>;
        case 'code_sent':
            return <Badge variant="default"><Mail className="mr-1.5" />Code Sent</Badge>;
        case 'agent_assigned':
            return <Badge variant="default"><User className="mr-1.5" />Agent Assigned</Badge>;
        case 'verified':
            return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="mr-1.5" />Verified</Badge>;
        case 'rejected':
            return <Badge variant="destructive"><XCircle className="mr-1.5" />Rejected</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function ManageAddressVerificationsPage() {
    const { user } = useAuth();
    const { toast } = useToast();
    const [requests, setRequests] = useState<VerificationRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const [updatingId, setUpdatingId] = useState<string | null>(null);

    useEffect(() => {
        setLoading(true);
        const requestsRef = ref(db, 'address-verifications');
        const unsubscribe = onValue(requestsRef, (snapshot) => {
            const data = snapshot.val();
            const list: VerificationRequest[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.timestamp - a.timestamp) : [];
            setRequests(list);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);
    
    const generateVerificationCode = () => {
        const randomNumber = Math.floor(100000 + Math.random() * 900000).toString();
        return `SMNP${randomNumber}`;
    }

    const handleUpdateStatus = async (requestId: string, newStatus: VerificationRequest['status'], request: VerificationRequest) => {
        setUpdatingId(requestId);
        const requestRef = ref(db, `address-verifications/${requestId}`);
        try {
            const updates: Partial<VerificationRequest> & { approvedBy?: string, approvedAt?: number, verificationCode?: string } = { status: newStatus };
            if (newStatus === 'approved') {
                updates.approvedBy = user?.uid;
                updates.approvedAt = Date.now();
                
                if (request.verificationMethod === 'postal_code') {
                    updates.verificationCode = generateVerificationCode();
                    updates.status = 'code_sent';
                } else {
                    updates.status = 'agent_assigned';
                }
            }
            await update(requestRef, updates);
            toast({
                title: 'Status Updated!',
                description: `The request status has been updated.`,
            });
        } catch (error) {
            console.error("Error updating status:", error);
            toast({
                variant: "destructive",
                title: "Update Failed",
                description: "Could not update the request status.",
            });
        } finally {
            setUpdatingId(null);
        }
    }
    
    if (!user) {
        return (
          <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                <CardDescription>You must be an admin to view this page.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        );
    }

    return (
        <div className="space-y-8">
            <PageHeader
                title="Address Verification Management"
                description="Review and approve address verification requests from professionals."
            />
            <Card>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Professional</TableHead>
                                <TableHead>Address</TableHead>
                                <TableHead>Method</TableHead>
                                <TableHead>Code</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                Array.from({length: 5}).map((_, i) => (
                                    <TableRow key={i}>
                                        <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-64" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell className="text-right"><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                                    </TableRow>
                                ))
                            ) : requests.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-24 text-center">
                                        No address verification requests found.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                requests.map(req => (
                                    <TableRow key={req.id}>
                                        <TableCell className="font-medium">{req.userName}</TableCell>
                                        <TableCell>{req.address}</TableCell>
                                        <TableCell className="capitalize">{req.verificationMethod.replace('_', ' ')}</TableCell>
                                        <TableCell className="font-mono">{req.verificationCode || 'N/A'}</TableCell>
                                        <TableCell>{statusToJsx(req.status)}</TableCell>
                                        <TableCell className="text-right">
                                            {req.status === 'pending' && (
                                                <AlertDialog>
                                                    <AlertDialogTrigger asChild>
                                                        <Button variant="secondary" size="sm" disabled={updatingId === req.id}>
                                                             {updatingId === req.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldQuestion className="mr-2 h-4 w-4" />}
                                                            Review
                                                        </Button>
                                                    </AlertDialogTrigger>
                                                    <AlertDialogContent>
                                                        <AlertDialogHeader>
                                                        <AlertDialogTitle>Review Verification Request</AlertDialogTitle>
                                                        <AlertDialogDescription>
                                                            Review the address details below. Approving will generate a verification code for postal mail or assign it for agent verification.
                                                        </AlertDialogDescription>
                                                        </AlertDialogHeader>
                                                        <div className="space-y-4 my-4">
                                                            <p><strong>Professional:</strong> {req.userName}</p>
                                                            <p><strong>Address:</strong> {req.address}</p>
                                                            <p><strong>Method:</strong> <span className="capitalize">{req.verificationMethod.replace('_', ' ')}</span></p>
                                                        </div>
                                                        <AlertDialogFooter>
                                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                            <Button variant="destructive" onClick={() => handleUpdateStatus(req.id, 'rejected', req)}>Reject</Button>
                                                            <AlertDialogAction onClick={() => handleUpdateStatus(req.id, 'approved', req)}>
                                                                Approve
                                                            </AlertDialogAction>
                                                        </AlertDialogFooter>
                                                    </AlertDialogContent>
                                                </AlertDialog>
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
