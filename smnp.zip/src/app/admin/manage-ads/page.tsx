
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, update } from "firebase/database";
import type { Advertisement, AdvertisementStatus } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, ChevronDown, Clock, Loader2, Megaphone, XCircle, IndianRupee } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import Image from "next/image";

function adStatusToJsx(status: AdvertisementStatus) {
    switch(status) {
        case 'pending':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><Clock className="mr-1.5" />Pending Approval</Badge>;
        case 'active':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="mr-1.5" />Active</Badge>;
        case 'rejected':
            return <Badge variant="destructive"><XCircle className="mr-1.5" />Rejected</Badge>;
        case 'paused':
            return <Badge variant="outline">Paused</Badge>;
        case 'completed':
            return <Badge variant="secondary">Completed</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function ManageAdsPage() {
    const { user, userData } = useAuth();
    const { toast } = useToast();
    const [allAds, setAllAds] = useState<Advertisement[]>([]);
    const [loading, setLoading] = useState(true);
    const isDubai = userData?.country === 'dubai';

    useEffect(() => {
        setLoading(true);
        const adsRef = ref(db, 'advertisements');
        const unsubscribe = onValue(adsRef, (snapshot) => {
            const data = snapshot.val();
            const adsList: Advertisement[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.createdAt - a.createdAt) : [];
            setAllAds(adsList);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const handleUpdateStatus = async (adId: string, newStatus: AdvertisementStatus) => {
        const adRef = ref(db, `advertisements/${adId}`);
        try {
            await update(adRef, { status: newStatus });
            toast({
                title: 'Ad Status Updated!',
                description: `The ad status has been changed to "${newStatus}".`,
            });
        } catch (error) {
            console.error("Error updating ad status:", error);
            toast({
                variant: "destructive",
                title: "Update Failed",
                description: "Could not update the ad status.",
            });
        }
    }
    
    if (!user) {
        return (
          <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                <CardDescription>You must be logged in as an admin to view this page.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        );
    }

    return (
        <div className="space-y-8">
            <PageHeader
                title="Advertisement Management"
                description="Review, approve, and manage all professional ad campaigns."
            />
            <Card>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Image</TableHead>
                                <TableHead>Campaign</TableHead>
                                <TableHead>Professional</TableHead>
                                <TableHead>Budget</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Created On</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                Array.from({length: 5}).map((_, i) => (
                                    <TableRow key={i}>
                                        <TableCell><Skeleton className="h-10 w-16" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell className="text-right"><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                                    </TableRow>
                                ))
                            ) : allAds.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={7} className="h-24 text-center">
                                        No advertisements found.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                allAds.map(ad => (
                                    <TableRow key={ad.id}>
                                        <TableCell>
                                            <Image src={ad.adImage} alt={ad.campaignName} width={64} height={40} className="rounded-md object-cover" />
                                        </TableCell>
                                        <TableCell className="font-medium">{ad.campaignName}</TableCell>
                                        <TableCell>{ad.professionalName}</TableCell>
                                        <TableCell>
                                            {isDubai ? `AED ${ad.budget.toLocaleString()}` : <>&#8377;{ad.budget.toLocaleString('en-IN')}</>}
                                        </TableCell>
                                        <TableCell>{adStatusToJsx(ad.status)}</TableCell>
                                        <TableCell>{format(new Date(ad.createdAt), 'PPP')}</TableCell>
                                        <TableCell className="text-right">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" size="sm">
                                                        Update Status
                                                        <ChevronDown className="ml-2 h-4 w-4" />
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(ad.id, 'pending')}>Pending</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(ad.id, 'active')}>Active</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(ad.id, 'paused')}>Pause</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(ad.id, 'completed')}>Complete</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateStatus(ad.id, 'rejected')} className="text-red-600">Reject</DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
