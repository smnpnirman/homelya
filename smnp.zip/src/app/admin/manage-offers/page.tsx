
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, remove, update } from "firebase/database";
import type { Offer } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { MoreVertical, Trash2, Edit, PlusCircle, Tag, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";

export default function ManageOffersPage() {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);
  const [offerToDelete, setOfferToDelete] = useState<Offer | null>(null);

  useEffect(() => {
    setLoading(true);
    const offersRef = ref(db, 'offers');
    const unsubscribe = onValue(offersRef, (snapshot) => {
        const data = snapshot.val();
        const list: Offer[] = data ? Object.keys(data).map(key => ({
            id: key,
            ...data[key],
        })) : [];
        setOffers(list);
        setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleUpdate = (id: string) => {
      router.push(`/admin/manage-offers/edit/${id}`);
  }

  const handleDelete = async () => {
    if (!offerToDelete) return;
    const offerRef = ref(db, `offers/${offerToDelete.id}`);
    try {
        await remove(offerRef);
        toast({
            title: "Offer Deleted",
            description: `The offer "${offerToDelete.title}" has been removed.`,
        });
    } catch (error) {
        toast({
            variant: "destructive",
            title: "Deletion Failed",
        });
    } finally {
        setOfferToDelete(null);
    }
  }

  const handleStatusChange = async (offerId: string, newStatus: 'active' | 'hidden') => {
    const offerRef = ref(db, `offers/${offerId}`);
    try {
        await update(offerRef, { status: newStatus });
        toast({
            title: "Status Updated",
            description: `The offer is now ${newStatus}.`,
        });
    } catch (error) {
        toast({
            variant: "destructive",
            title: "Update Failed",
        });
    }
  };

  if (!user) { // Assuming admin role is checked in a layout
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-8">
        <PageHeader
          title="Manage Offers"
          description="Add, edit, or remove promotional offers."
        >
            <Button asChild>
                <Link href="/admin/manage-offers/new">
                    <PlusCircle className="mr-2 h-4 w-4" /> Add New Offer
                </Link>
            </Button>
        </PageHeader>
        <Card>
            <CardContent className="p-0">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Status</TableHead>
                            <TableHead>Title</TableHead>
                            <TableHead>Discount</TableHead>
                            <TableHead>Code</TableHead>
                            <TableHead>Applicable On</TableHead>
                            <TableHead>Expires On</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {loading ? (
                            Array.from({length: 3}).map((_, i) => (
                                <TableRow key={i}>
                                    <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                    <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                                </TableRow>
                            ))
                        ) : offers.length === 0 ? (
                           <TableRow>
                                <TableCell colSpan={7} className="h-48 text-center">
                                    <div className="flex flex-col items-center gap-4">
                                        <Tag className="h-12 w-12 text-muted-foreground" />
                                        <h3 className="font-semibold text-lg">No offers found.</h3>
                                        <p className="text-muted-foreground">Click the button to add the first offer.</p>
                                        <Button asChild>
                                           <Link href="/admin/manage-offers/new">
                                                <PlusCircle className="mr-2 h-4 w-4" /> Add New Offer
                                            </Link>
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ) : (
                            offers.map(offer => (
                                <TableRow key={offer.id}>
                                    <TableCell>
                                        <Switch
                                            checked={offer.status === 'active'}
                                            onCheckedChange={(checked) => handleStatusChange(offer.id, checked ? 'active' : 'hidden')}
                                            aria-label="Toggle offer status"
                                        />
                                    </TableCell>
                                    <TableCell className="font-medium">{offer.title}</TableCell>
                                    <TableCell><Badge variant="secondary">{offer.discountPercentage}% OFF</Badge></TableCell>
                                    <TableCell className="font-mono">{offer.code || 'N/A'}</TableCell>
                                    <TableCell>{offer.applicableOn}</TableCell>
                                    <TableCell>{format(new Date(offer.expiryDate), 'PPP')}</TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon">
                                                    <MoreVertical className="h-4 w-4" />
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuItem onClick={() => handleUpdate(offer.id)}>
                                                    <Edit className="mr-2 h-4 w-4" />
                                                    Edit
                                                </DropdownMenuItem>
                                                <DropdownMenuSeparator />
                                                <DropdownMenuItem 
                                                    className="text-red-600 focus:text-red-600"
                                                    onClick={() => setOfferToDelete(offer)}
                                                >
                                                    <Trash2 className="mr-2 h-4 w-4" />
                                                    Delete
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
      </div>
      <AlertDialog open={!!offerToDelete} onOpenChange={(open) => !open && setOfferToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the offer
              "<span className="font-bold">{offerToDelete?.title}</span>".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
