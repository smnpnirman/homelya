
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import OfferForm from "../offer-form";
import { useParams } from "next/navigation";

export default function EditOfferPage() {
  const { user } = useAuth();
  const params = useParams();
  const offerId = params.id as string;

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Edit Offer"
        description="Update the details for the selected offer."
      />
      <OfferForm offerId={offerId} />
    </div>
  );
}
