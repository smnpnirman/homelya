
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Save, PlusCircle, Calendar as CalendarIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ref, push, set, get, update } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { Skeleton } from '@/components/ui/skeleton';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Switch } from '@/components/ui/switch';

const offerFormSchema = z.object({
  title: z.string().min(5, 'Title must be at least 5 characters.'),
  description: z.string().min(10, 'Description must be at least 10 characters.'),
  discountPercentage: z.coerce.number().min(1, 'Discount must be at least 1%').max(100, 'Discount cannot exceed 100%'),
  applicableOn: z.string().min(3, 'This field is required.'),
  code: z.string().optional(),
  expiryDate: z.date({ required_error: "An expiry date is required."}),
  status: z.enum(['active', 'hidden']).default('active'),
});

type OfferFormValues = z.infer<typeof offerFormSchema>;

type OfferFormProps = {
  offerId?: string;
}

export default function OfferForm({ offerId }: OfferFormProps) {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(!!offerId);

  const form = useForm<OfferFormValues>({
    resolver: zodResolver(offerFormSchema),
    defaultValues: {
      title: '',
      description: '',
      discountPercentage: 10,
      applicableOn: '',
      code: '',
      status: 'active',
    },
  });

  useEffect(() => {
    if (offerId) {
      setDataLoading(true);
      get(ref(db, `offers/${offerId}`)).then(snapshot => {
        if (snapshot.exists()) {
          const data = snapshot.val();
          form.reset({
              ...data,
              expiryDate: new Date(data.expiryDate),
              status: data.status || 'active',
          });
        }
      }).finally(() => setDataLoading(false));
    }
  }, [offerId, form]);

  const onSubmit = async (data: OfferFormValues) => {
    setLoading(true);
    const offerData = {
        ...data,
        expiryDate: format(data.expiryDate, 'yyyy-MM-dd'),
    };
    
    try {
      if (offerId) {
        await update(ref(db, `offers/${offerId}`), offerData);
        toast({ title: 'Offer Updated!' });
      } else {
        await set(push(ref(db, 'offers')), offerData);
        toast({ title: 'Offer Created!' });
      }
      router.push('/admin/manage-offers');
    } catch (error) {
      toast({ variant: 'destructive', title: 'An error occurred.' });
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
    return <Skeleton className="h-96 w-full" />;
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card>
          <CardHeader>
            <CardTitle>Offer Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
             <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 shadow-sm">
                        <div className="space-y-0.5">
                            <FormLabel>Visibility</FormLabel>
                            <FormDescription>
                                Active offers will be visible to users on the homepage.
                            </FormDescription>
                        </div>
                        <FormControl>
                            <Switch
                            checked={field.value === 'active'}
                            onCheckedChange={(checked) => field.onChange(checked ? 'active' : 'hidden')}
                            />
                        </FormControl>
                    </FormItem>
                )}
            />
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Diwali Special Discount" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="e.g., Get a flat discount on all home designs." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid md:grid-cols-2 gap-6">
                <FormField
                    control={form.control}
                    name="discountPercentage"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Discount Percentage</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="10" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="applicableOn"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Applicable On</FormLabel>
                        <FormControl>
                            <Input placeholder="e.g., All Designs, Consultations" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
            <div className="grid md:grid-cols-2 gap-6">
                <FormField
                    control={form.control}
                    name="code"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Discount Code (Optional)</FormLabel>
                        <FormControl>
                            <Input placeholder="e.g., DIWALI10" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="expiryDate"
                    render={({ field }) => (
                    <FormItem className="flex flex-col">
                        <FormLabel>Expiry Date</FormLabel>
                        <Popover>
                        <PopoverTrigger asChild>
                            <FormControl>
                            <Button
                                variant={"outline"}
                                className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                                )}
                            >
                                {field.value ? (
                                format(field.value, "PPP")
                                ) : (
                                <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                            </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date()}
                            initialFocus
                            />
                        </PopoverContent>
                        </Popover>
                        <FormMessage />
                    </FormItem>
                    )}
                />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={loading}>
              {loading ? <Loader2 className="mr-2 animate-spin" /> : offerId ? <Save className="mr-2" /> : <PlusCircle className="mr-2" />}
              {offerId ? 'Save Changes' : 'Create Offer'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
