
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue } from "firebase/database";
import { Mail, Phone, Briefcase, User } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { format } from "date-fns";

interface Inquiry {
    id: string;
    name: string;
    email: string;
    phone: string;
    message: string;
    timestamp: number;
    professionalId?: string;
    professionalName?: string;
    source?: string;
}

export default function ManageInquiriesPage() {
  const { user } = useAuth();
  const [allInquiries, setAllInquiries] = useState<Inquiry[]>([]);
  const [loadingInquiries, setLoadingInquiries] = useState(true);

  useEffect(() => {
    setLoadingInquiries(true);
    const inquiriesRef = ref(db, 'inquiries');
    const generalInquiriesRef = ref(db, 'general-inquiries');

    let professionalInquiries: Inquiry[] = [];
    let generalInquiries: Inquiry[] = [];
    
    const combineAndSetInquiries = () => {
        setAllInquiries([...professionalInquiries, ...generalInquiries].sort((a,b) => b.timestamp - a.timestamp));
    };

    const unsubscribeInquiries = onValue(inquiriesRef, (snapshot) => {
        const professionalInquiriesData: Inquiry[] = [];
        const usersData = snapshot.val();
        if (usersData) {
            Object.keys(usersData).forEach(professionalId => {
                const inquiriesData = usersData[professionalId];
                if (inquiriesData) {
                    Object.keys(inquiriesData).forEach(key => {
                        professionalInquiriesData.push({
                            id: `${professionalId}-${key}`,
                            professionalId,
                            ...inquiriesData[key]
                        });
                    });
                }
            });
        }
        professionalInquiries = professionalInquiriesData;
        combineAndSetInquiries();
        setLoadingInquiries(false);
    });
    
    const unsubscribeGeneralInquiries = onValue(generalInquiriesRef, (snapshot) => {
        const generalInquiriesData: Inquiry[] = [];
        const data = snapshot.val();
        if (data) {
            Object.keys(data).forEach(key => {
                generalInquiriesData.push({
                    id: `general-${key}`,
                    professionalName: 'General Inquiry',
                    ...data[key]
                })
            })
        }
        generalInquiries = generalInquiriesData;
        combineAndSetInquiries();
        setLoadingInquiries(false);
    });

    return () => {
        unsubscribeInquiries();
        unsubscribeGeneralInquiries();
    };
  }, []); 

  if (!user) { 
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in as an admin to view this page.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="All Inquiries"
        description="View all inquiries sent to professionals and through the general inquiry form."
      />
      <Card>
        <CardContent className="p-0">
          {loadingInquiries ? (
            <div className="space-y-2 p-4">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          ) : allInquiries.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              No inquiries found.
            </div>
          ) : (
            <Accordion type="single" collapsible className="w-full">
              {allInquiries.map((inquiry) => (
                <AccordionItem value={inquiry.id} key={inquiry.id}>
                  <AccordionTrigger className="px-4 py-3 hover:bg-muted/50">
                    <div className="flex justify-between items-center w-full">
                      <div className="flex items-center gap-4 text-left">
                        <User className="text-primary h-5 w-5" />
                        <div>
                          <p className="font-semibold">{inquiry.name}</p>
                          <p className="text-sm text-muted-foreground">Sent on {format(new Date(inquiry.timestamp), 'PPP')}</p>
                        </div>
                      </div>
                      <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground pr-4">
                        <Briefcase className="h-4 w-4" />
                        <span>To: {inquiry.professionalName}</span>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-4 bg-muted/20">
                    <div className="space-y-4 pt-4">
                      <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                        <a href={`mailto:${inquiry.email}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Mail className="h-4 w-4" /> {inquiry.email}</a>
                        <a href={`tel:${inquiry.phone}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Phone className="h-4 w-4" /> {inquiry.phone}</a>
                      </div>
                      <h4 className="font-semibold text-base pt-2">Message</h4>
                      <p className="text-muted-foreground text-sm whitespace-pre-wrap">{inquiry.message}</p>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
