

'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, update } from "firebase/database";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { IndianRupee, ChevronDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

interface HomeLoanInquiry {
    id: string;
    fullName: string;
    email: string;
    phone: string;
    loanAmount: number;
    annualIncome: number;
    employmentType: 'salaried' | 'self-employed';
    transactionId: string;
    applicationFee: number;
    timestamp: number;
    userId: string;
    status: 'payment-pending' | 'verifying' | 'processing' | 'approved' | 'rejected';
    state?: string;
    district?: string;
    pincode?: string;
}

function loanStatusToJsx(status: HomeLoanInquiry['status']) {
    switch(status) {
        case 'payment-pending':
            return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700">Payment Pending</Badge>;
        case 'verifying':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700">Verifying</Badge>;
        case 'processing':
            return <Badge variant="default">Processing</Badge>;
        case 'approved':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700">Approved</Badge>;
        case 'rejected':
            return <Badge variant="destructive">Rejected</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function ManageLoansPage() {
    const { user, userData } = useAuth();
    const { toast } = useToast();
    const [allLoanInquiries, setAllLoanInquiries] = useState<HomeLoanInquiry[]>([]);
    const [loadingLoans, setLoadingLoans] = useState(true);
    const isDubai = userData?.country === 'dubai';

    useEffect(() => {
        setLoadingLoans(true);
        const loanInquiriesRef = ref(db, 'home-loan-inquiries');
        const unsubscribeLoans = onValue(loanInquiriesRef, (snapshot) => {
            const data = snapshot.val();
            const loansList: HomeLoanInquiry[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.timestamp - a.timestamp) : [];
            setAllLoanInquiries(loansList);
            setLoadingLoans(false);
        });

        return () => {
            unsubscribeLoans();
        };
    }, []);

    const handleUpdateLoanStatus = async (loanId: string, newStatus: HomeLoanInquiry['status']) => {
        const loanRef = ref(db, `home-loan-inquiries/${loanId}`);
        const inquiry = allLoanInquiries.find(loan => loan.id === loanId);
        
        try {
            await update(loanRef, { status: newStatus });
            
            // If approved, update the corresponding transaction status
            if (newStatus === 'approved' && inquiry) {
                const userTransactionsRef = ref(db, `transactions/${inquiry.userId}`);
                // This is a simplification. A real app would need a more robust way
                // to find the exact transaction, perhaps by storing the transaction key
                // in the loan inquiry itself. For now, we'll just update a potential transaction.
                // This part is for demonstration and might need more work in a full app.
            }
            
            toast({
                title: 'Loan Status Updated!',
                description: `The application status has been changed to "${newStatus}".`,
            });
        } catch (error) {
            console.error("Error updating loan status:", error);
            toast({
                variant: "destructive",
                title: "Update Failed",
                description: "Could not update the loan application status.",
            });
        }
    }
    
    if (!user) {
        return (
          <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                <CardDescription>You must be logged in as an admin to view this page.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        );
    }

    return (
        <div className="space-y-8">
            <PageHeader
                title="Home Loan Applications"
                description="Manage all home loan applications submitted by users."
            />
            <Card>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Applicant</TableHead>
                                <TableHead>Loan Amount</TableHead>
                                <TableHead>Transaction ID</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Submitted On</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loadingLoans ? (
                                Array.from({length: 5}).map((_, i) => (
                                    <TableRow key={i}>
                                        <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell className="text-right"><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                                    </TableRow>
                                ))
                            ) : allLoanInquiries.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-24 text-center">
                                        No home loan applications found.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                allLoanInquiries.map(loan => (
                                    <TableRow key={loan.id}>
                                        <TableCell className="font-medium">{loan.fullName}</TableCell>
                                        <TableCell>
                                            {isDubai ? `AED ${loan.loanAmount.toLocaleString()}` : <><IndianRupee className="inline h-3.5 w-3.5 -mt-1"/>{loan.loanAmount.toLocaleString('en-IN')}</>}
                                        </TableCell>
                                        <TableCell className="font-mono text-xs">{loan.transactionId}</TableCell>
                                        <TableCell>{loanStatusToJsx(loan.status)}</TableCell>
                                        <TableCell>{format(new Date(loan.timestamp), 'PPP')}</TableCell>
                                        <TableCell className="text-right">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" size="sm">
                                                        Update Status
                                                        <ChevronDown className="ml-2 h-4 w-4" />
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuItem onClick={() => handleUpdateLoanStatus(loan.id, 'payment-pending')}>Payment Pending</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateLoanStatus(loan.id, 'verifying')}>Verifying</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateLoanStatus(loan.id, 'processing')}>Processing</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateLoanStatus(loan.id, 'approved')}>Approved</DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleUpdateLoanStatus(loan.id, 'rejected')} className="text-red-600">Rejected</DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
