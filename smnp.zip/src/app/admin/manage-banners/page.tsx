
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, remove } from "firebase/database";
import type { FestivalGreeting } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { MoreVertical, Trash2, Edit, PlusCircle, Sparkles } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function ManageBannersPage() {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [banners, setBanners] = useState<FestivalGreeting[]>([]);
  const [loading, setLoading] = useState(true);
  const [bannerToDelete, setBannerToDelete] = useState<FestivalGreeting | null>(null);

  useEffect(() => {
    setLoading(true);
    const bannersRef = ref(db, 'festival-greetings');
    const unsubscribe = onValue(bannersRef, (snapshot) => {
        const data = snapshot.val();
        const list: FestivalGreeting[] = data ? Object.keys(data).map(key => ({
            id: key,
            ...data[key],
        })) : [];
        setBanners(list);
        setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleUpdate = (id: string) => {
      router.push(`/admin/manage-banners/edit/${id}`);
  }

  const handleDelete = async () => {
    if (!bannerToDelete) return;
    const bannerRef = ref(db, `festival-greetings/${bannerToDelete.id}`);
    try {
        await remove(bannerRef);
        toast({
            title: "Banner Deleted",
            description: `The banner "${bannerToDelete.title}" has been removed.`,
        });
    } catch (error) {
        toast({
            variant: "destructive",
            title: "Deletion Failed",
        });
    } finally {
        setBannerToDelete(null);
    }
  }

  if (!user) { // Assuming admin role is checked in a layout
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-8">
        <PageHeader
          title="Manage Banners"
          description="Add, edit, or remove festival banners."
        >
            <Button asChild>
                <Link href="/admin/manage-banners/new">
                    <PlusCircle className="mr-2 h-4 w-4" /> Add New Banner
                </Link>
            </Button>
        </PageHeader>
        <Card>
            <CardContent className="p-0">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Image</TableHead>
                            <TableHead>Event Name</TableHead>
                            <TableHead>Title</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {loading ? (
                            Array.from({length: 3}).map((_, i) => (
                                <TableRow key={i}>
                                    <TableCell><Skeleton className="h-16 w-24 rounded-md" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                    <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                                </TableRow>
                            ))
                        ) : banners.length === 0 ? (
                           <TableRow>
                                <TableCell colSpan={4} className="h-48 text-center">
                                    <div className="flex flex-col items-center gap-4">
                                        <Sparkles className="h-12 w-12 text-muted-foreground" />
                                        <h3 className="font-semibold text-lg">No banners found.</h3>
                                        <p className="text-muted-foreground">Click the button to add the first banner.</p>
                                        <Button asChild>
                                           <Link href="/admin/manage-banners/new">
                                                <PlusCircle className="mr-2 h-4 w-4" /> Add New Banner
                                            </Link>
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ) : (
                            banners.map(banner => (
                                <TableRow key={banner.id}>
                                    <TableCell>
                                        <Image src={banner.images?.[0] || 'https://picsum.photos/120/80'} alt={banner.title} width={120} height={80} className="rounded-md object-cover" />
                                    </TableCell>
                                    <TableCell className="font-medium">{banner.eventName}</TableCell>
                                    <TableCell>{banner.title}</TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon">
                                                    <MoreVertical className="h-4 w-4" />
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuItem onClick={() => handleUpdate(banner.id)}>
                                                    <Edit className="mr-2 h-4 w-4" />
                                                    Edit
                                                </DropdownMenuItem>
                                                <DropdownMenuSeparator />
                                                <DropdownMenuItem 
                                                    className="text-red-600 focus:text-red-600"
                                                    onClick={() => setBannerToDelete(banner)}
                                                >
                                                    <Trash2 className="mr-2 h-4 w-4" />
                                                    Delete
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
      </div>
      <AlertDialog open={!!bannerToDelete} onOpenChange={(open) => !open && setBannerToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the banner
              "<span className="font-bold">{bannerToDelete?.title}</span>".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
