
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import BannerForm from "../banner-form";
import { useParams } from "next/navigation";

export default function EditBannerPage() {
  const { user } = useAuth();
  const params = useParams();
  const bannerId = params.id as string;

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Edit Banner"
        description="Update the details for the selected banner."
      />
      <BannerForm bannerId={bannerId} />
    </div>
  );
}
