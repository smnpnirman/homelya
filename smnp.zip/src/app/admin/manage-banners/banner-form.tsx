
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, useFieldArray } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Save, PlusCircle, Trash2, Image as ImageIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ref, push, set, get, update } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';

const bannerFormSchema = z.object({
  eventName: z.string().min(3, 'Event name must be at least 3 characters.'),
  title: z.string().min(5, 'Title must be at least 5 characters.'),
  description: z.string().min(10, 'Description must be at least 10 characters.'),
  images: z.array(z.object({ value: z.string().url({ message: "Please enter a valid URL." }) })),
  readMoreUrl: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')),
});

type BannerFormValues = z.infer<typeof bannerFormSchema>;

type BannerFormProps = {
  bannerId?: string;
}

export default function BannerForm({ bannerId }: BannerFormProps) {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(!!bannerId);

  const form = useForm<BannerFormValues>({
    resolver: zodResolver(bannerFormSchema),
    defaultValues: {
      eventName: '',
      title: '',
      description: '',
      images: [{ value: "" }],
      readMoreUrl: '',
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "images"
  });

  useEffect(() => {
    if (bannerId) {
      setDataLoading(true);
      get(ref(db, `festival-greetings/${bannerId}`)).then(snapshot => {
        if (snapshot.exists()) {
          const data = snapshot.val();
          const images = Array.isArray(data.images) ? data.images.map((url: string) => ({ value: url })) : [{value: ''}];
          form.reset({...data, images});
        }
      }).finally(() => setDataLoading(false));
    }
  }, [bannerId, form]);

  const onSubmit = async (data: BannerFormValues) => {
    setLoading(true);
    const bannerData = {
        ...data,
        images: data.images.map(img => img.value).filter(Boolean)
    };
    
    if (bannerData.images.length === 0) {
        toast({ variant: "destructive", title: "At least one image is required." });
        setLoading(false);
        return;
    }

    try {
      if (bannerId) {
        await update(ref(db, `festival-greetings/${bannerId}`), bannerData);
        toast({ title: 'Banner Updated!' });
      } else {
        await set(push(ref(db, 'festival-greetings')), bannerData);
        toast({ title: 'Banner Created!' });
      }
      router.push('/admin/manage-banners');
    } catch (error) {
      toast({ variant: 'destructive', title: 'An error occurred.' });
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
    return <Skeleton className="h-96 w-full" />;
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card>
          <CardHeader>
            <CardTitle>Banner Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="eventName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Event Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Diwali" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Happy Diwali!" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="e.g., Wishing you a joyous festival of lights." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
                control={form.control}
                name="readMoreUrl"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Read More URL (Optional)</FormLabel>
                    <FormControl>
                        <Input placeholder="https://example.com/blog/post" {...field} />
                    </FormControl>
                    <FormDescription>
                        An optional link for a "Read More" button on the banner.
                    </FormDescription>
                    <FormMessage />
                    </FormItem>
                )}
            />
            
            <div className="space-y-4">
                <FormLabel>Images</FormLabel>
                {fields.map((field, index) => (
                     <FormField
                        key={field.id}
                        control={form.control}
                        name={`images.${index}.value`}
                        render={({ field }) => (
                            <FormItem>
                                <div className="flex gap-2 items-center">
                                    <ImageIcon className="h-4 w-4 text-muted-foreground" />
                                    <FormControl>
                                        <Input placeholder={`Image URL ${index + 1}`} {...field} />
                                    </FormControl>
                                    <Button type="button" variant="ghost" size="icon" className="shrink-0 text-destructive" onClick={() => remove(index)}>
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </div>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                ))}
                <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => append({ value: "" })}
                >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Image URL
                </Button>
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={loading}>
              {loading ? <Loader2 className="mr-2 animate-spin" /> : bannerId ? <Save className="mr-2" /> : <PlusCircle className="mr-2" />}
              {bannerId ? 'Save Changes' : 'Create Banner'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
