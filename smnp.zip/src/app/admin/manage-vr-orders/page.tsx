

'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, update } from "firebase/database";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, IndianRupee, Loader2, Save } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";

interface VROrder {
    id: string;
    professionalId: string;
    professionalName: string;
    timestamp: number;
    transactionId?: string;
    amount: number;
    status: 'payment-pending' | 'verified' | 'rejected';
    vrId?: string;
}

function orderStatusToJsx(status: VROrder['status']) {
    switch(status) {
        case 'payment-pending':
            return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700"><Clock className="mr-1.5" />Payment Pending</Badge>;
        case 'verified':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="mr-1.5" />Verified & Assigned</Badge>;
        case 'rejected':
            return <Badge variant="destructive">Rejected</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function ManageVROrdersPage() {
    const { user } = useAuth();
    const { toast } = useToast();
    const [allOrders, setAllOrders] = useState<VROrder[]>([]);
    const [loading, setLoading] = useState(true);
    const [vrIds, setVrIds] = useState<{[key: string]: string}>({});
    const [saving, setSaving] = useState<{[key: string]: boolean}>({});

    useEffect(() => {
        setLoading(true);
        const ordersRef = ref(db, 'vr-orders');
        const unsubscribeOrders = onValue(ordersRef, (snapshot) => {
            const data = snapshot.val();
            const ordersList: VROrder[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.timestamp - a.timestamp) : [];
            setAllOrders(ordersList);
            setVrIds(ordersList.reduce((acc, order) => {
                acc[order.id] = order.vrId || '';
                return acc;
            }, {} as {[key: string]: string}));
            setLoading(false);
        });

        return () => {
            unsubscribeOrders();
        };
    }, []);
    
    const handleVerifyPayment = async (orderId: string) => {
        const orderRef = ref(db, `vr-orders/${orderId}`);
        try {
            await update(orderRef, { status: 'verified' });
            toast({
                title: 'Payment Verified!',
                description: 'The order is now marked as verified. You can now assign a VR ID.',
            });
        } catch (error) {
            console.error("Error verifying payment:", error);
            toast({
                variant: "destructive",
                title: "Update Failed",
                description: "Could not update the order status.",
            });
        }
    };

    const handleSaveVrId = async (order: VROrder) => {
        const vrId = vrIds[order.id];
        if (!vrId || !vrId.trim()) {
            toast({ variant: 'destructive', title: 'VR ID is required.' });
            return;
        }
        setSaving(prev => ({...prev, [order.id]: true}));
        try {
            const updates: {[key: string]: any} = {};
            updates[`vr-orders/${order.id}/vrId`] = vrId;
            updates[`users/${order.professionalId}/vrId`] = vrId;

            await update(ref(db), updates);
            toast({
                title: 'VR ID Assigned!',
                description: `Successfully assigned VR ID to ${order.professionalName}.`,
            });
        } catch(error) {
            console.error("Error assigning VR ID:", error);
            toast({
                variant: "destructive",
                title: "Assignment Failed",
                description: "Could not assign the VR ID.",
            });
        } finally {
            setSaving(prev => ({...prev, [order.id]: false}));
        }
    }
    
    if (!user) {
        return (
          <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                <CardDescription>You must be logged in as an admin to view this page.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        );
    }

    return (
        <div className="space-y-8">
            <PageHeader
                title="Manage VR Kit Orders"
                description="Verify payments and assign VR Kit IDs to professionals."
            />
            <Card>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Professional</TableHead>
                                <TableHead>Transaction ID</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Ordered On</TableHead>
                                <TableHead>VR Kit ID</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                Array.from({length: 3}).map((_, i) => (
                                    <TableRow key={i}>
                                        <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                        <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                        <TableCell><Skeleton className="h-10 w-36" /></TableCell>
                                        <TableCell className="text-right"><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                                    </TableRow>
                                ))
                            ) : allOrders.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="h-24 text-center">
                                        No VR Kit orders found.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                allOrders.map(order => (
                                    <TableRow key={order.id}>
                                        <TableCell className="font-medium">{order.professionalName}</TableCell>
                                        <TableCell className="font-mono text-xs">{order.transactionId || 'N/A'}</TableCell>
                                        <TableCell>{orderStatusToJsx(order.status)}</TableCell>
                                        <TableCell>{format(new Date(order.timestamp), 'PPP')}</TableCell>
                                        <TableCell>
                                            <Input
                                                placeholder="Enter VR Kit ID"
                                                value={vrIds[order.id]}
                                                onChange={(e) => setVrIds(prev => ({...prev, [order.id]: e.target.value}))}
                                                disabled={order.status !== 'verified' || saving[order.id]}
                                            />
                                        </TableCell>
                                        <TableCell className="text-right space-x-2">
                                            {order.status === 'payment-pending' && (
                                                 <Button variant="secondary" size="sm" onClick={() => handleVerifyPayment(order.id)}>
                                                    <CheckCircle className="mr-2" />
                                                    Verify Payment
                                                </Button>
                                            )}
                                            {order.status === 'verified' && (
                                                <Button 
                                                    size="sm" 
                                                    onClick={() => handleSaveVrId(order)}
                                                    disabled={saving[order.id] || !vrIds[order.id]}
                                                >
                                                    {saving[order.id] ? <Loader2 className="mr-2 animate-spin" /> : <Save className="mr-2"/>}
                                                    Assign ID
                                                </Button>
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
