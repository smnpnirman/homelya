

'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar as CalendarIcon, Loader2, Send, ShieldCheck, Briefcase } from 'lucide-react';
import { useState, useEffect, Suspense } from 'react';
import { ref, push, set, serverTimestamp, get, runTransaction, update } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import PageHeader from '@/components/page-header';
import { useAuth } from '@/hooks/use-auth';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import Image from 'next/image';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const consultationFormSchema = z.object({
  date: z.date({
    required_error: "A date for the consultation is required.",
  }),
  details: z.string().min(20, 'Please provide at least 20 characters of detail about your needs.'),
  professionalNeeded: z.enum(['designer', 'constructor', 'supplier'], {
    required_error: "Please select the type of professional you need.",
  }),
});

type ConsultationFormValues = z.infer<typeof consultationFormSchema>;

type UserData = {
    consultationsUsed: number;
    phone?: string;
    // other user fields
};

function FreeConsultationContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [dataLoading, setDataLoading] = useState(true);

  const form = useForm<ConsultationFormValues>({
    resolver: zodResolver(consultationFormSchema),
    defaultValues: {
        details: '',
    }
  });

  useEffect(() => {
    if (user) {
        const userRef = ref(db, `users/${user.uid}`);
        get(userRef).then(snapshot => {
            if (snapshot.exists()) {
                setUserData(snapshot.val());
            } else {
                setUserData({ consultationsUsed: 0 }); // New user
            }
            setDataLoading(false);
        })
    } else {
        setDataLoading(false);
    }
  }, [user]);

  const consultationsUsed = userData?.consultationsUsed ?? 0;
  const consultationsLeft = 2 - consultationsUsed;
  const isPaidConsultation = consultationsLeft <= 0;
  const price = 999;

  const onSubmit = async (data: ConsultationFormValues, event?: React.BaseSyntheticEvent) => {
    if (!user) {
        toast({ variant: 'destructive', title: 'Error', description: 'You must be logged in.' });
        return;
    }
    setLoading(true);

    const isPaidForm = event?.nativeEvent.submitter?.id === 'paid-submit-button';

    const baseConsultationData = {
      date: format(data.date, 'yyyy-MM-dd'),
      details: data.details,
      professionalNeeded: data.professionalNeeded,
      userId: user.uid,
      userName: user.displayName,
      userEmail: user.email,
      userPhone: userData?.phone || '', // Fix: Ensure phone is always a string
      timestamp: serverTimestamp(),
    };


    if (isPaidForm) {
        // Paid consultation logic
        const transactionId = (event?.target as HTMLFormElement)?.transactionId?.value;

        if (!transactionId?.trim()) {
            toast({
                variant: 'destructive',
                title: 'Transaction ID Required',
                description: 'Please enter the transaction ID from your UPI app.',
            });
            setLoading(false);
            return;
        }

        try {
            const consultationsRef = ref(db, 'consultations');
            const newConsultationRef = push(consultationsRef);
            await set(newConsultationRef, {
                ...baseConsultationData,
                status: 'Payment Pending',
                transactionId: transactionId,
                amount: price,
            });
            
            // Log transaction
            const userTransactionsRef = ref(db, `transactions/${user.uid}`);
            const newTransactionRef = push(userTransactionsRef);
            await set(newTransactionRef, {
                amount: price,
                description: `Paid Consultation Booking`,
                timestamp: serverTimestamp(),
                type: 'purchase',
                status: 'pending'
            });

            toast({
                title: 'Paid Consultation Submitted!',
                description: 'Our team will verify your payment and contact you soon.',
            });
            router.push(`/consultation-token/${newConsultationRef.key}`);
        } catch (error: any) {
             console.error('Failed to book paid consultation:', error);
            toast({
                variant: 'destructive',
                title: 'Booking Failed',
                description: error.message || 'Could not book your paid consultation. Please try again.',
            });
        }

    } else {
        // Free consultation logic
        const userRef = ref(db, `users/${user.uid}`);
        try {
            const transactionResult = await runTransaction(userRef, (currentUserData) => {
                 if (currentUserData === null) {
                    return {
                        displayName: user.displayName,
                        email: user.email,
                        role: 'user',
                        consultationsUsed: 1,
                        phone: userData?.phone,
                    };
                }
                const used = currentUserData.consultationsUsed || 0;
                if (used >= 2) {
                    return; 
                }
                currentUserData.consultationsUsed = used + 1;
                return currentUserData;
            });
            
            if (!transactionResult.committed) {
                throw new Error("You have used all your free consultations.");
            }

            const consultationsRef = ref(db, 'consultations');
            const newConsultationRef = push(consultationsRef);
            await set(newConsultationRef, {
                ...baseConsultationData,
                status: 'Pending',
            });

            toast({
                title: 'Consultation Booked!',
                description: 'Our team will contact you soon to confirm the details.',
            });
            router.push(`/consultation-token/${newConsultationRef.key}`);

        } catch (error: any) {
            console.error('Failed to book consultation:', error);
            toast({
                variant: 'destructive',
                title: 'Booking Failed',
                description: error.message || 'Could not book your consultation. Please try again.',
            });
        }
    }
    setLoading(false);
  };


  if (dataLoading) {
      return (
        <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      );
  }

  if (!user) {
      return (
        <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Login Required</CardTitle>
                    <CardDescription>Please log in to book your consultation.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                        <Link href="/login?redirect=/free-consultation">Login</Link>
                    </Button>
                </CardContent>
            </Card>
      </div>
    );
  }

  const upiId = '6204910508@mbk';
  const payeeName = 'Homelya';
  const upiLink = `upi://pay?pa=${upiId}&pn=${payeeName}&am=${price}&cu=INR&tn=Consultation Fee`;

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
        <Image
            src="https://i.ibb.co/NdC2Y28/file-000000006428622f809342d6b5097c8e.png"
            alt="Free Consultation Banner"
            width={800}
            height={400}
            className="rounded-lg object-cover w-full"
            data-ai-hint="consultation discussion"
        />
        <PageHeader 
            title="Book Your Consultation"
            description="Let's discuss your project. Select a preferred date and tell us what you're looking for."
        />
        <Card>
          <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                  <CardHeader>
                       {consultationsLeft > 0 ? (
                          <CardTitle>You have <span className="text-primary">{consultationsLeft}</span> free consultation{consultationsLeft !== 1 ? 's' : ''} left.</CardTitle>
                       ) : (
                          <CardTitle>You have used all your free consultations.</CardTitle>
                       )}
                  </CardHeader>
                  <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField
                            control={form.control}
                            name="professionalNeeded"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Professional Needed</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a professional" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        <SelectItem value="designer">Designer / Architect</SelectItem>
                                        <SelectItem value="constructor">Constructor / Builder</SelectItem>
                                        <SelectItem value="supplier">Material Supplier</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        <FormField
                          control={form.control}
                          name="date"
                          render={({ field }) => (
                            <FormItem className="flex flex-col">
                              <FormLabel>Preferred Date</FormLabel>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant={"outline"}
                                      className={cn(
                                        "w-full pl-3 text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                      )}
                                    >
                                      {field.value ? (
                                        format(field.value, "PPP")
                                      ) : (
                                        <span>Pick a date</span>
                                      )}
                                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={field.value}
                                    onSelect={field.onChange}
                                    disabled={(date) =>
                                      date < new Date(new Date().setDate(new Date().getDate() -1))
                                    }
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <FormField
                      control={form.control}
                      name="details"
                      render={({ field }) => (
                          <FormItem>
                          <FormLabel>Project Details</FormLabel>
                          <FormControl>
                              <Textarea
                              placeholder="Tell us about your project, your requirements, budget, or any questions you have..."
                              rows={5}
                              {...field}
                              />
                          </FormControl>
                          <FormDescription>The more details you provide, the better we can assist you.</FormDescription>
                          <FormMessage />
                          </FormItem>
                      )}
                      />
                      {isPaidConsultation && (
                          <div className="space-y-6 pt-4 border-t">
                              <CardTitle className="font-headline">Book Your Next Consultation</CardTitle>
                              <Card className="bg-muted/50">
                                  <CardHeader>
                                      <CardTitle className="text-base">1. Pay ₹{price} via UPI</CardTitle>
                                      <CardDescription>Scan the QR code with any UPI app.</CardDescription>
                                  </CardHeader>
                                  <CardContent className="flex flex-col items-center gap-4">
                                       <Image 
                                        src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(upiLink)}`}
                                        alt="UPI QR Code for consultation fee"
                                        width={180}
                                        height={180}
                                        className="rounded-md border p-2"
                                      />
                                      <p className="font-mono font-semibold text-base">{upiId}</p>
                                  </CardContent>
                              </Card>
                              
                              <Card className="bg-muted/50">
                                  <CardHeader>
                                      <CardTitle className="text-base">2. Submit Transaction ID</CardTitle>
                                      <CardDescription>After paying, enter the transaction ID from your UPI app.</CardDescription>
                                  </CardHeader>
                                  <CardContent>
                                      <FormItem>
                                          <FormLabel>UPI Transaction ID</FormLabel>
                                          <FormControl>
                                              <Input 
                                                  name="transactionId"
                                                  placeholder="e.g., 217382193812" 
                                              />
                                          </FormControl>
                                          <FormMessage />
                                      </FormItem>
                                  </CardContent>
                              </Card>
                          </div>
                      )}
                </CardContent>
                <CardFooter>
                    {isPaidConsultation ? (
                      <Button className="w-full" size="lg" type="submit" id="paid-submit-button" disabled={loading}>
                          {loading ? <Loader2 className="mr-2 animate-spin"/> : <ShieldCheck className="mr-2" />}
                          {loading ? 'Submitting...' : `Submit Paid Consultation`}
                      </Button>
                    ) : (
                      <Button type="submit" size="lg" disabled={loading}>
                        {loading ? (
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        ) : (
                          <Send className="mr-2 h-5 w-5" />
                        )}
                        Book My Free Consultation
                      </Button>
                    )}
                </CardFooter>
            </form>
          </Form>
        </Card>
    </div>
  );
}


export default function FreeConsultationPage() {
    return (
        <Suspense fallback={<div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
            <FreeConsultationContent />
        </Suspense>
    )
}

    
