
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Share2, Copy, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

type ShareButtonProps = {
  title: string;
  text: string;
};

export default function ShareButton({ title, text }: ShareButtonProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [url, setUrl] = useState('');
  const [isShareSupported, setIsShareSupported] = useState(false);

  useEffect(() => {
    setUrl(window.location.href);
    if (navigator.share) {
      setIsShareSupported(true);
    }
  }, []);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: text,
          url: url,
        });
      } catch (error) {
        // Silently fail if user cancels share dialog
        if ((error as DOMException).name !== 'AbortError') {
            console.error('Error sharing:', error);
        }
      }
    } else {
      // Fallback to copying the link
      navigator.clipboard.writeText(url).then(() => {
        setCopied(true);
        toast({
          title: 'Link Copied!',
          description: 'The page URL has been copied to your clipboard.',
        });
        setTimeout(() => setCopied(false), 2000);
      }).catch(err => {
        console.error('Failed to copy: ', err);
        toast({
            variant: 'destructive',
            title: 'Failed to Copy',
            description: 'Could not copy the link to your clipboard.',
        });
      });
    }
  };

  return (
    <Button size="icon" variant="outline" onClick={handleShare}>
      {isShareSupported ? (
        <>
          <Share2 className="h-4 w-4" />
        </>
      ) : copied ? (
        <>
          <Check className="h-4 w-4" />
        </>
      ) : (
        <>
          <Copy className="h-4 w-4" />
        </>
      )}
       <span className="sr-only">Share</span>
    </Button>
  );
}
