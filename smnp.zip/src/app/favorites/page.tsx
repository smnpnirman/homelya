'use client';

import PageHeader from "@/components/page-header";
import { useFavorites } from "@/hooks/use-favorites";
import { allItems } from "@/lib/placeholder-data";
import ItemCard from "@/components/item-card";
import { Heart } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function FavoritesPage() {
  const { favorites } = useFavorites();

  const favoriteItems = allItems.filter(item => favorites.some(fav => fav.id === item.id));

  const favoriteDesigns = favoriteItems.filter(item => favorites.find(f => f.id === item.id)?.type === 'design');
  const favoriteDesigners = favoriteItems.filter(item => favorites.find(f => f.id === item.id)?.type === 'designer');
  const favoriteConstructors = favoriteItems.filter(item => favorites.find(f => f.id === item.id)?.type === 'constructor');
  const favoriteSuppliers = favoriteItems.filter(item => favorites.find(f => f.id === item.id)?.type === 'supplier');

  return (
    <div className="space-y-8">
      <PageHeader
        title="My Favorites"
        description="Your saved designs and providers for easy access."
      />

      {favoriteItems.length === 0 ? (
        <div className="text-center col-span-full py-16 border bg-card rounded-lg flex flex-col items-center">
            <Heart className="w-16 h-16 text-muted-foreground/50 mb-4" />
            <h3 className="font-headline text-2xl font-semibold">Your Favorites List is Empty</h3>
            <p className="text-muted-foreground max-w-md mx-auto mt-2">
              Click the heart icon on any design or provider to save it here for later.
            </p>
            <Button asChild className="mt-6">
                <Link href="/designs">Start Exploring</Link>
            </Button>
        </div>
      ) : (
        <div className="space-y-12">
          {favoriteDesigns.length > 0 && (
            <section>
              <h2 className="font-headline text-2xl font-bold mb-4">Favorite Designs</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {favoriteDesigns.map(item => <ItemCard key={item.id} item={item} itemType="design" />)}
              </div>
            </section>
          )}

          {favoriteDesigners.length > 0 && (
            <section>
              <h2 className="font-headline text-2xl font-bold mb-4">Favorite Designers</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {favoriteDesigners.map(item => <ItemCard key={item.id} item={item} itemType="designer" />)}
              </div>
            </section>
          )}

          {favoriteConstructors.length > 0 && (
            <section>
              <h2 className="font-headline text-2xl font-bold mb-4">Favorite Constructors</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {favoriteConstructors.map(item => <ItemCard key={item.id} item={item} itemType="constructor" />)}
              </div>
            </section>
          )}

          {favoriteSuppliers.length > 0 && (
            <section>
              <h2 className="font-headline text-2xl font-bold mb-4">Favorite Suppliers</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {favoriteSuppliers.map(item => <ItemCard key={item.id} item={item} itemType="supplier" />)}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
