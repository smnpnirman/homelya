
import PageHeader from "@/components/page-header";
import { Card, CardContent } from "@/components/ui/card";

export default function TermsPage() {
  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <PageHeader
        title="Terms and Conditions"
        description="Last updated: October 26, 2024"
      />
      <Card>
        <CardContent className="pt-6 space-y-4">
          <p>
            Welcome to Homelya! These terms and conditions outline the rules and
            regulations for the use of Homelya's Website, located at homelya.com.
          </p>

          <p>
            By accessing this website we assume you accept these terms and
            conditions. Do not continue to use Homelya if you do not agree to take
            all of the terms and conditions stated on this page.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Cookies</h2>
          <p>
            We employ the use of cookies. By accessing Homelya, you agreed to
            use cookies in agreement with the Homelya's Privacy Policy.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">License</h2>
          <p>
            Unless otherwise stated, Homelya and/or its licensors own the
            intellectual property rights for all material on Homelya. All
            intellectual property rights are reserved. You may access this from
            Homelya for your own personal use subjected to restrictions set in
            these terms and conditions.
          </p>
          <p>You must not:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Republish material from Homelya</li>
            <li>Sell, rent or sub-license material from Homelya</li>
            <li>Reproduce, duplicate or copy material from Homelya</li>
            <li>Redistribute content from Homelya</li>
          </ul>

          <h2 className="font-headline text-xl font-bold pt-4">User Content</h2>
          <p>
            Parts of this website offer an opportunity for users to post and
            exchange opinions and information. Homelya does not filter, edit,
            publish or review Comments prior to their presence on the website.
            Comments do not reflect the views and opinions of Homelya,its agents
            and/or affiliates. Comments reflect the views and opinions of the
            person who post their views and opinions.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Hyperlinking to our Content</h2>
          <p>
            The following organizations may link to our Website without prior
            written approval: Government agencies; Search engines; News
            organizations.
          </p>

          <h2 className="font-headline text-xl font-bold pt-4">Disclaimer</h2>
          <p>
            To the maximum extent permitted by applicable law, we exclude all
            representations, warranties and conditions relating to our website
            and the use of this website. Nothing in this disclaimer will:
          </p>
          <ul className="list-disc pl-6 space-y-1">
            <li>
              limit or exclude our or your liability for death or personal
              injury;
            </li>
            <li>
              limit or exclude our or your liability for fraud or fraudulent
              misrepresentation;
            </li>
            <li>
              limit any of our or your liabilities in any way that is not
              permitted under applicable law; or
            </li>
            <li>
              exclude any of our or your liabilities that may not be excluded
              under applicable law.
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
