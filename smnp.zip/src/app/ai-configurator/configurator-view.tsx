
'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { type AIHomeConfiguratorOutput } from '@/ai/flows/ai-home-configurator';
import { generateLayout, type GenerateLayoutOutput } from '@/ai/flows/generate-layout-flow';
import ConfiguratorForm from './configurator-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Bot, Loader2, Paintbrush, Warehouse, Wrench, Image as ImageIcon, RotateCw, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

export default function ConfiguratorView() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AIHomeConfiguratorOutput | null>(null);
  const [layoutResult, setLayoutResult] = useState<GenerateLayoutOutput | null>(null);
  const [generatingLayout, setGeneratingLayout] = useState(false);

  const handleSuccess = (output: AIHomeConfiguratorOutput) => {
    setResult(output);
    setLoading(false);
  };

  const handleGenerateLayout = async () => {
    if (!result?.designRecommendation) return;
    setGeneratingLayout(true);
    setLayoutResult(null);
    try {
      const designDescription = `${result.designRecommendation.style}: ${result.designRecommendation.summary}`;
      const generatedLayout = await generateLayout({ designDescription });
      setLayoutResult(generatedLayout);
      toast({
        title: "Layout Generated!",
        description: "Your visual floor plan is ready.",
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "An error occurred",
        description: "Failed to generate layout. Please try again.",
      });
    } finally {
      setGeneratingLayout(false);
    }
  };


  const handleReset = () => {
    setResult(null);
    setLayoutResult(null);
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center text-center p-8 rounded-lg border bg-card text-card-foreground shadow-sm min-h-[400px]">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <h2 className="font-headline text-2xl font-bold">Building your dream home...</h2>
        <p className="text-muted-foreground">Our AI is crafting the perfect recommendations for you. This might take a moment.</p>
      </div>
    );
  }

  if (result) {
    return (
      <div>
        <Card className="mb-6 bg-primary/5 border-primary/20">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <div>
                        <CardTitle className="font-headline text-2xl flex items-center gap-2">
                            <Bot className="text-primary"/> Your AI-Powered Home Plan
                        </CardTitle>
                        <CardDescription>
                            Based on your preferences, here is our tailored recommendation package.
                        </CardDescription>
                    </div>
                    <Button variant="outline" onClick={handleReset}>
                        <RotateCw className="mr-2 h-4 w-4" />
                        Generate New Plan
                    </Button>
                </div>
            </CardHeader>
        </Card>
        <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className='font-headline flex items-center gap-2'><Paintbrush className="text-primary"/> Design Recommendation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="font-semibold text-lg">{result.designRecommendation.style}</p>
              <p className="text-muted-foreground text-sm">{result.designRecommendation.summary}</p>
              <ul className="space-y-2">
                  {result.designRecommendation.keyFeatures.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-1 shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className='font-headline flex items-center gap-2'><Wrench className="text-primary"/> Constructor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
               <p className="font-semibold text-lg">{result.constructorRecommendation.name}</p>
              <p className="text-muted-foreground text-sm">{result.constructorRecommendation.justification}</p>
               <ul className="space-y-2">
                  {result.constructorRecommendation.suggestedQualities.map((quality, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-1 shrink-0" />
                      <span className="text-sm">{quality}</span>
                    </li>
                  ))}
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className='font-headline flex items-center gap-2'><Warehouse className="text-primary"/> Material Supplier</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="font-semibold text-lg">{result.materialSupplierRecommendation.name}</p>
              <p className="text-muted-foreground text-sm">{result.materialSupplierRecommendation.justification}</p>
               <ul className="space-y-2">
                  {result.materialSupplierRecommendation.suggestedMaterials.map((material, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-1 shrink-0" />
                      <span className="text-sm">{material}</span>
                    </li>
                  ))}
              </ul>
            </CardContent>
          </Card>
        </div>
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="font-headline flex items-center gap-2">
              <ImageIcon className="text-primary" /> Visual Layout
            </CardTitle>
            <CardDescription>
              Generate a 2D floor plan for the recommended design.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {generatingLayout ? (
              <div className="space-y-4">
                <Skeleton className="w-full h-64" />
                <div className="flex items-center justify-center text-muted-foreground">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating your floor plan... This may take a moment.
                </div>
              </div>
            ) : layoutResult ? (
              <figure>
                <Image
                    src={layoutResult.imageUrl}
                    alt={layoutResult.caption}
                    width={1200}
                    height={800}
                    className="rounded-lg object-cover w-full aspect-video"
                    data-ai-hint="floor plan"
                />
                <figcaption className="text-sm text-center text-muted-foreground mt-2">{layoutResult.caption}</figcaption>
              </figure>
            ) : (
              <div className="text-center p-8 border-dashed border-2 rounded-lg">
                <p className="text-muted-foreground">Click the button below to generate a visual layout.</p>
              </div>
            )}
          </CardContent>
          <CardContent>
             <Button onClick={handleGenerateLayout} disabled={generatingLayout}>
                {generatingLayout ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <ImageIcon className="mr-2 h-4 w-4" />
                )}
                {generatingLayout ? 'Generating...' : layoutResult ? 'Re-generate Layout' : 'Generate Layout'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <ConfiguratorForm onLoading={() => setLoading(true)} onSuccess={handleSuccess} />;
}
