import PageHeader from "@/components/page-header";
import ConfiguratorView from "./configurator-view";

export default function AiConfiguratorPage() {
  return (
    <div className="space-y-8">
      <PageHeader 
        title="AI Home Configurator"
        description="Describe your dream home, and our AI will create a personalized recommendation package for you."
      />
      <ConfiguratorView />
    </div>
  );
}
