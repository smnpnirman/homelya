'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/hooks/use-toast';
import { aiHomeConfigurator, type AIHomeConfiguratorOutput } from '@/ai/flows/ai-home-configurator';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Bot } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

const FormSchema = z.object({
  preferences: z.string().min(30, {
    message: 'Please describe your preferences in at least 30 characters.',
  }),
  existingDesignElements: z.string().optional(),
  language: z.enum(['english', 'hindi']).optional(),
});

type ConfiguratorFormProps = {
  onLoading: () => void;
  onSuccess: (output: AIHomeConfiguratorOutput) => void;
};

export default function ConfiguratorForm({ onLoading, onSuccess }: ConfiguratorFormProps) {
  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      preferences: '',
      existingDesignElements: '',
      language: 'english',
    },
  });

  async function onSubmit(data: z.infer<typeof FormSchema>) {
    onLoading();
    try {
      const result = await aiHomeConfigurator(data);
      onSuccess(result);
      toast({
        title: "Recommendation ready!",
        description: "Your personalized home plan has been generated.",
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "An error occurred",
        description: "Failed to generate AI recommendation. Please try again.",
      });
    }
  }

  return (
    <Card>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
             <div className="flex justify-between items-center">
                <CardTitle className="font-headline text-xl">Describe Your Vision</CardTitle>
                <FormField
                  control={form.control}
                  name="language"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 space-y-0">
                      <FormLabel>English</FormLabel>
                      <FormControl>
                        <Switch
                          checked={field.value === 'hindi'}
                          onCheckedChange={(checked) => field.onChange(checked ? 'hindi' : 'english')}
                        />
                      </FormControl>
                      <FormLabel>Hindi</FormLabel>
                    </FormItem>
                  )}
                />
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="preferences"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Preferences & Requirements</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="e.g., I want a 4-bedroom modern house in Ranchi with a budget of 80 lakhs. It should have a large kitchen, a home office, and be suitable for a family of four. I prefer natural light and open spaces."
                      rows={6}
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Describe your desired style, size, budget, location, and any key features. The more detail, the better!
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="existingDesignElements"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Existing Design Elements (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="e.g., We have a corner plot facing north. We want to incorporate some antique furniture we already own."
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Mention any constraints or existing elements to consider.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg">
              <Bot className="mr-2 h-5 w-5" />
              Generate My Home Plan
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
