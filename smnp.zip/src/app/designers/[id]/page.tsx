
'use client';

import { useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, MapPin, Send, MessageCircle, ShieldCheck, ShieldAlert, Link as LinkIcon, FileText, Linkedin, Twitter, Instagram, Facebook, UserPlus, Briefcase, Award, Phone, Mail, Gem, Building, Camera, Info, Video } from 'lucide-react';
import PageHeader from '@/components/page-header';
import ItemCard from '@/components/item-card';
import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, get, query, orderByChild, equalTo, onValue } from 'firebase/database';
import type { Provider, Design, VerificationStatus } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import SendInquiryDialog from '@/components/send-inquiry-dialog';
import ShareButton from '@/components/share-button';
import { useFollow } from '@/hooks/use-follow';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getYouTubeEmbedUrl, getInstagramEmbedUrl } from '@/lib/utils';


function getEmbedUrl(url: string | undefined): string | null {
    if (!url) return null;
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname.includes('google.com') && urlObj.pathname.includes('/maps/place/')) {
            const place = urlObj.pathname.split('/place/')[1];
            return `https://maps.google.com/maps?q=${decodeURIComponent(place)}&t=&z=13&ie=UTF8&iwloc=&output=embed`;
        }
    } catch (e) {
        // invalid url
    }
    return url;
}

const VideoEmbed = ({ url }: { url: string }) => {
    const youtubeUrl = getYouTubeEmbedUrl(url);
    if (youtubeUrl) {
        return (
            <iframe
                src={youtubeUrl}
                width="100%"
                className="aspect-video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
            ></iframe>
        );
    }
    
    const instagramUrl = getInstagramEmbedUrl(url);
    if (instagramUrl) {
         return (
             <iframe 
                src={instagramUrl}
                width="100%"
                className="aspect-[9/16] sm:aspect-video"
                frameBorder="0"
                allowFullScreen
            ></iframe>
         );
    }

    return <p>Invalid video URL.</p>;
}

function VerificationBadge({ status }: { status?: VerificationStatus }) {
    if (!status || status === 'rejected') return null;

    if (status === 'verified') {
        return (
            <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700">
                <ShieldCheck className="h-4 w-4 mr-1" />
                Verified
            </Badge>
        );
    }
    
    if (status === 'master') {
        return (
            <Badge variant="secondary" className="border-purple-500/50 bg-purple-500/10 text-purple-700">
                <Gem className="h-4 w-4 mr-1" />
                Master Professional
            </Badge>
        );
    }

    if (status === 'in-progress' || status === 'payment-pending' || status === 'master-payment-pending') {
        return (
            <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700">
                <ShieldAlert className="h-4 w-4 mr-1" />
                In Process
            </Badge>
        );
    }

    return null;
}

const DefaultLayout = ({ designer, designs, embedUrl, whatsappLink, socials, skillsList, galleryImages, user, isFollowed, handleFollow, followerCount }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", designer.theme === 'dark' && 'theme-dark')}>
        <section className="bg-gradient-to-b from-muted/30 to-background">
            <div className="container py-8 md:py-12">
                <div className="flex flex-col md:flex-row items-start gap-6 md:gap-8">
                    <Image
                        src={designer.image}
                        alt={designer.name}
                        width={150}
                        height={150}
                        className="rounded-lg object-contain aspect-square border-4 border-background bg-background shadow-lg"
                        data-ai-hint={designer.dataAiHint}
                    />
                    <div className="space-y-2 flex-1 pt-2">
                        <div className="flex items-center gap-4 flex-wrap">
                            <PageHeader title={designer.name} className="p-0" />
                            <VerificationBadge status={designer.status}/>
                        </div>
                        <div className="flex items-center gap-4 flex-wrap text-sm text-muted-foreground">
                            <div className="flex items-center gap-1.5">
                                <Star className="w-4 h-4 text-yellow-500 fill-yellow-400" />
                                <span className="font-bold">{designer.rating}</span>
                                <span>(24 reviews)</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                                <UserPlus className="w-4 h-4 text-primary" />
                                <span className="font-bold">{followerCount}</span>
                                <span>Followers</span>
                            </div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {designer.gstNumber && <Badge variant="outline">GST: {designer.gstNumber}</Badge>}
                            {designer.architectureRegistrationNumber && <Badge variant="outline">Arch. Reg: {designer.architectureRegistrationNumber}</Badge>}
                            {designer.localAuthorityRegistrationNumber && <Badge variant="outline">Local Reg: {designer.localAuthorityRegistrationNumber}</Badge>}
                        </div>
                        <div className="flex items-center gap-2 pt-2">
                            {socials && Object.values(socials).some(s => s) && (
                                <div className="flex items-center gap-1">
                                    {socials.linkedin && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#0077B5]"><Link href={socials.linkedin} target="_blank"><Linkedin className="h-5 w-5"/></Link></Button>}
                                    {socials.twitter && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1DA1F2]"><Link href={socials.twitter} target="_blank"><Twitter className="h-5 w-5"/></Link></Button>}
                                    {socials.instagram && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#E4405F]"><Link href={socials.instagram} target="_blank"><Instagram className="h-5 w-5"/></Link></Button>}
                                    {socials.facebook && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1877F2]"><Link href={socials.facebook} target="_blank"><Facebook className="h-5 w-5"/></Link></Button>}
                                    <Separator orientation="vertical" className="h-6 mx-2" />
                                </div>
                            )}
                            <ShareButton title={designer.name} text={`Check out ${designer.name} on Homelya.`} />
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div className="container space-y-8 md:space-y-12">
            <div className="grid lg:grid-cols-3 gap-8 md:gap-12 items-start">
            <div className="lg:col-span-2 space-y-8 md:space-y-12">
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline">About {designer.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground whitespace-pre-wrap">{designer.description}</p>
                    </CardContent>
                </Card>

                {designer.profileVideoUrl && (
                  <section>
                    <h2 className="font-headline text-2xl font-bold mb-4">Profile Video</h2>
                    <Card>
                      <CardContent className="p-0 aspect-video rounded-lg overflow-hidden">
                        <VideoEmbed url={designer.profileVideoUrl}/>
                      </CardContent>
                    </Card>
                  </section>
                )}

                {galleryImages.length > 0 && (
                    <section>
                        <h2 className="font-headline text-2xl font-bold mb-4">Gallery</h2>
                        <Carousel className="w-full">
                            <CarouselContent>
                            {galleryImages.map((imgUrl: string, index: number) => (
                                <CarouselItem key={index} className="md:basis-1/2">
                                    <div className="p-1">
                                        <Card className="overflow-hidden">
                                            <CardContent className="p-0 aspect-video">
                                                <Image src={imgUrl} alt={`Gallery image ${index + 1}`} width={600} height={400} className="object-cover w-full h-full" />
                                            </CardContent>
                                        </Card>
                                    </div>
                                </CarouselItem>
                            ))}
                            </CarouselContent>
                            <CarouselPrevious />
                            <CarouselNext />
                        </Carousel>
                    </section>
                )}

                {designs.length > 0 && (
                    <section>
                    <h2 className="font-headline text-2xl font-bold mb-4">Designs by {designer.name}</h2>
                    <div className="grid sm:grid-cols-2 gap-6">
                        {designs.map((design: Design) => (
                        <ItemCard key={design.id} item={design} itemType="design" />
                        ))}
                    </div>
                    </section>
                )}
            </div>
            <div className="lg:sticky top-6 space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline">Contact & Connect</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                         {designer.status === 'master' && (
                            <>
                                <SendInquiryDialog professionalName={designer.name} professionalId={designer.id}>
                                    <Button size="lg" className="w-full">
                                        <Send className="mr-2" /> Send Inquiry
                                    </Button>
                                </SendInquiryDialog>
                                {whatsappLink && (
                                    <Button size="lg" variant="outline" asChild className="w-full">
                                        <Link href={whatsappLink} target="_blank">
                                            <MessageCircle className="mr-2" /> Chat on WhatsApp
                                        </Link>
                                    </Button>
                                )}
                            </>
                        )}
                        {user && user.uid !== designer.id && (
                            <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow} className="w-full">
                                <UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}
                            </Button>
                        )}
                        {designer.catalogPdfUrl && (
                            <Button size="lg" variant="outline" asChild className="w-full">
                                <Link href={designer.catalogPdfUrl} target="_blank">
                                    <FileText className="mr-2" /> View Catalog (PDF)
                                </Link>
                            </Button>
                        )}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline text-lg">Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 text-sm">
                        <div className="flex items-center gap-3">
                            <Badge variant="secondary">{designer.specialty}</Badge>
                            {designer.experienceLevel && <Badge variant="outline">{designer.experienceLevel}</Badge>}
                        </div>
                        <Separator />
                        <div className="flex items-start gap-3">
                            <MapPin className="h-4 w-4 text-primary mt-1" />
                            <div className="flex-1">
                                <h4 className="font-semibold">Location</h4>
                                <p className="text-muted-foreground">{designer.locationUrl ? (
                                    <Link href={designer.locationUrl} target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-primary transition-colors">
                                        {designer.location}
                                    </Link>
                                    ) : (
                                    <span>{designer.location}</span>
                                )}</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Phone className="h-4 w-4 text-primary mt-1" />
                            <div className="flex-1">
                                <h4 className="font-semibold">Phone</h4>
                                <p className="text-muted-foreground">{designer.phone ? (
                                    <a href={`tel:${designer.phone}`} className="hover:underline">{designer.phone}</a>
                                ) : 'Not Available'}</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Mail className="h-4 w-4 text-primary mt-1" />
                            <div className="flex-1">
                                <h4 className="font-semibold">Email</h4>
                                <p className="text-muted-foreground">{designer.email ? (
                                    <a href={`mailto:${designer.email}`} className="hover:underline">{designer.email}</a>
                                ) : 'Not Available'}</p>
                            </div>
                        </div>
                        {designer.website && (
                            <div className="flex items-start gap-3">
                                <LinkIcon className="h-4 w-4 text-primary mt-1" />
                                <div className="flex-1">
                                    <h4 className="font-semibold">Website</h4>
                                    <p className="text-muted-foreground">
                                        <Link href={designer.website} target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-primary transition-colors truncate">
                                            {designer.website.replace(/^(https?:\/\/)?(www\.)?/, '')}
                                        </Link>
                                    </p>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {designer.workHistory && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline flex items-center gap-2 text-xl"><Briefcase /> Work History</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground whitespace-pre-wrap">{designer.workHistory}</p>
                        </CardContent>
                    </Card>
                )}

                {skillsList && skillsList.length > 0 && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline flex items-center gap-2 text-xl"><Award /> Skills & Expertise</CardTitle>
                        </CardHeader>
                        <CardContent className="flex flex-wrap gap-2">
                            {skillsList.map((skill: string) => <Badge key={skill} variant="secondary">{skill}</Badge>)}
                        </CardContent>
                    </Card>
                )}

                {embedUrl && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="font-headline text-lg">Location on Map</CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="aspect-square w-full rounded-b-lg overflow-hidden">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    loading="lazy"
                                    allowFullScreen
                                    src={embedUrl}>
                                </iframe>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
            </div>
        </div>
    </div>
);

const ModernLayout = ({ designer, designs, whatsappLink, socials, galleryImages, user, isFollowed, handleFollow, followerCount }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", "theme-modern")}>
        <section className="relative h-64 md:h-80 w-full">
            <Image
                src={designer.coverImage || designer.image}
                alt={designer.name}
                fill
                className="object-cover"
                data-ai-hint={designer.dataAiHint}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        </section>

        <div className="container -mt-32 relative z-10">
            <div className="max-w-4xl mx-auto">
                <Card className="p-6 md:p-8">
                     <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
                        <Avatar className="h-24 w-24 border-4 border-background shadow-md">
                            <AvatarImage src={designer.image} alt={designer.name} />
                            <AvatarFallback>{designer.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="space-y-1 flex-1">
                            <PageHeader title={designer.name} className="p-0 justify-center sm:justify-start" />
                            <p className="text-muted-foreground">{designer.specialty}</p>
                            <div className="pt-1"><VerificationBadge status={designer.status}/></div>
                        </div>
                    </div>

                    <Separator className="my-6" />

                    <div className="flex justify-center items-center gap-6 md:gap-12 text-sm text-muted-foreground">
                        <div className="text-center">
                            <span className="font-bold text-2xl text-foreground">{designer.rating}</span>
                            <div className="flex items-center gap-1"><Star className="w-4 h-4 text-yellow-500 fill-yellow-400" /><span>(24 reviews)</span></div>
                        </div>
                        <div className="text-center">
                            <span className="font-bold text-2xl text-foreground">{followerCount}</span>
                            <div className="flex items-center gap-1"><UserPlus className="w-4 h-4 text-primary" /><span>Followers</span></div>
                        </div>
                    </div>
                     <div className="flex items-center justify-center gap-2 pt-6">
                        {socials && Object.values(socials).some(s => s) && (
                            <div className="flex items-center gap-1">
                                {socials.linkedin && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#0077B5]"><Link href={socials.linkedin} target="_blank"><Linkedin className="h-5 w-5"/></Link></Button>}
                                {socials.twitter && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1DA1F2]"><Link href={socials.twitter} target="_blank"><Twitter className="h-5 w-5"/></Link></Button>}
                                {socials.instagram && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#E4405F]"><Link href={socials.instagram} target="_blank"><Instagram className="h-5 w-5"/></Link></Button>}
                                {socials.facebook && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1877F2]"><Link href={socials.facebook} target="_blank"><Facebook className="h-5 w-5"/></Link></Button>}
                                <Separator orientation="vertical" className="h-6 mx-2" />
                            </div>
                        )}
                        <ShareButton title={designer.name} text={`Check out ${designer.name} on Homelya.`} />
                    </div>
                </Card>

                <div className="mt-8 grid gap-8">
                    <Card>
                        <CardHeader><CardTitle className="font-headline">About</CardTitle></CardHeader>
                        <CardContent><p className="text-muted-foreground whitespace-pre-wrap">{designer.description}</p></CardContent>
                    </Card>

                    <Card>
                        <CardHeader><CardTitle className="font-headline">Contact</CardTitle></CardHeader>
                        <CardContent className="grid md:grid-cols-2 gap-4">
                            {designer.status === 'master' && (
                                <>
                                    <SendInquiryDialog professionalName={designer.name} professionalId={designer.id}>
                                        <Button size="lg" className="w-full"><Send className="mr-2" /> Send Inquiry</Button>
                                    </SendInquiryDialog>
                                    {whatsappLink && <Button size="lg" variant="outline" asChild className="w-full"><Link href={whatsappLink} target="_blank"><MessageCircle className="mr-2" /> Chat on WhatsApp</Link></Button>}
                                </>
                            )}
                             {user && user.uid !== designer.id && <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow} className="w-full"><UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}</Button>}
                             {designer.catalogPdfUrl && <Button size="lg" variant="outline" asChild className="w-full"><Link href={designer.catalogPdfUrl} target="_blank"><FileText className="mr-2" /> View Catalog (PDF)</Link></Button>}
                        </CardContent>
                    </Card>

                    {galleryImages.length > 0 && (
                        <section>
                            <h2 className="font-headline text-2xl font-bold mb-4 text-center">Gallery</h2>
                            <Carousel className="w-full">
                                <CarouselContent>
                                {galleryImages.map((imgUrl: string, index: number) => (
                                    <CarouselItem key={index} className="md:basis-1/2">
                                        <div className="p-1">
                                            <Card className="overflow-hidden">
                                                <CardContent className="p-0 aspect-video">
                                                    <Image src={imgUrl} alt={`Gallery image ${index + 1}`} width={600} height={400} className="object-cover w-full h-full" />
                                                </CardContent>
                                            </Card>
                                        </div>
                                    </CarouselItem>
                                ))}
                                </CarouselContent>
                                <CarouselPrevious />
                                <CarouselNext />
                            </Carousel>
                        </section>
                    )}
                    
                    {designs.length > 0 && (
                        <section>
                            <h2 className="font-headline text-2xl font-bold mb-4 text-center">Portfolio</h2>
                            <div className="grid sm:grid-cols-2 gap-6">
                                {designs.map((design: Design) => <ItemCard key={design.id} item={design} itemType="design" />)}
                            </div>
                        </section>
                    )}
                </div>
            </div>
        </div>
    </div>
);

const CreativeLayout = ({ designer, designs, embedUrl, user, isFollowed, handleFollow, followerCount, whatsappLink }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", "theme-creative")}>
        <section className="bg-muted">
            <div className="container py-12 md:py-20">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                    <div className="relative">
                         <div className="absolute -left-4 -top-4 w-48 h-48 bg-primary/20 rounded-full blur-2xl"></div>
                         <Image
                            src={designer.image}
                            alt={designer.name}
                            width={400}
                            height={400}
                            className="rounded-lg object-cover aspect-square shadow-lg mx-auto relative z-10"
                            data-ai-hint={designer.dataAiHint}
                        />
                    </div>
                    <div className="space-y-4">
                        <PageHeader title={designer.name} className="p-0" />
                        <p className="text-xl text-primary font-semibold">{designer.specialty}</p>
                         <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1.5">
                                <Star className="w-4 h-4 text-yellow-500 fill-yellow-400" />
                                <span className="font-bold">{designer.rating}</span>
                                <span>(24 reviews)</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                                <UserPlus className="w-4 h-4 text-primary" />
                                <span className="font-bold">{followerCount}</span>
                                <span>Followers</span>
                            </div>
                        </div>
                        <p className="text-muted-foreground">{designer.description}</p>
                        <div className="flex items-center gap-4 pt-2">
                             {designer.status === 'master' && (
                                <>
                                    <SendInquiryDialog professionalName={designer.name} professionalId={designer.id}>
                                        <Button size="lg"><Send className="mr-2" /> Send Inquiry</Button>
                                    </SendInquiryDialog>
                                    {whatsappLink && <Button size="lg" variant="outline" asChild><Link href={whatsappLink} target="_blank"><MessageCircle className="mr-2" /> Chat on WhatsApp</Link></Button>}
                                </>
                             )}
                            <ShareButton title={designer.name} text={`Check out ${designer.name} on Homelya.`} />
                        </div>
                         {user && user.uid !== designer.id && <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow}><UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}</Button>}
                    </div>
                </div>
            </div>
        </section>
        <div className="container grid gap-12">
            {designs.length > 0 && (
                <section>
                <h2 className="font-headline text-3xl font-bold mb-6 text-center">Portfolio</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {designs.map((design: Design) => (
                    <ItemCard key={design.id} item={design} itemType="design" />
                    ))}
                </div>
                </section>
            )}
             {embedUrl && (
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline text-lg">Find Us</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="aspect-video w-full rounded-b-lg overflow-hidden">
                            <iframe width="100%" height="100%" loading="lazy" allowFullScreen src={embedUrl}></iframe>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    </div>
);

const PremiumLayout = ({ designer, designs, whatsappLink, socials, galleryImages, user, isFollowed, handleFollow, followerCount }: any) => (
    <div className={cn("space-y-8 -m-4 md:-m-6", "theme-premium")}>
        <section className="relative h-64 md:h-80 w-full">
            <Image
                src={designer.coverImage || 'https://images.unsplash.com/photo-1484154218962-a197022b5858?q=80&w=2074&auto=format&fit=crop'}
                alt={designer.name}
                fill
                className="object-cover"
                data-ai-hint={designer.dataAiHint || 'modern interior'}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
        </section>

        <div className="container -mt-24 md:-mt-32 relative z-10">
            <div className="max-w-5xl mx-auto">
                 <div className="flex flex-col sm:flex-row items-end gap-6">
                    <Avatar className="h-32 w-32 md:h-40 md:w-40 border-4 border-background shadow-lg bg-background">
                        <AvatarImage src={designer.image} alt={designer.name} />
                        <AvatarFallback>{designer.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="space-y-1 flex-1 pb-4 text-center sm:text-left">
                        <h1 className="font-headline text-3xl md:text-4xl font-bold">{designer.name}</h1>
                        <p className="text-primary text-lg font-medium">{designer.specialty}</p>
                        <div className="pt-2"><VerificationBadge status={designer.status}/></div>
                    </div>
                </div>
                
                 <div className="mt-6 flex justify-center items-center gap-6 md:gap-12 text-sm text-muted-foreground border-y py-4">
                    <div className="text-center">
                        <span className="font-bold text-2xl text-foreground">{designer.rating}</span>
                        <div className="flex items-center gap-1"><Star className="w-4 h-4 text-yellow-500 fill-yellow-400" /><span>(24 reviews)</span></div>
                    </div>
                    <div className="text-center">
                        <span className="font-bold text-2xl text-foreground">{followerCount}</span>
                        <div className="flex items-center gap-1"><UserPlus className="w-4 h-4 text-primary" /><span>Followers</span></div>
                    </div>
                </div>

                <div className="mt-6 grid md:grid-cols-3 gap-6">
                    <div className="md:col-span-2">
                        <Tabs defaultValue="portfolio" className="w-full">
                            <TabsList className="bg-card">
                                <TabsTrigger value="about"><Info className="mr-2"/> About</TabsTrigger>
                                <TabsTrigger value="portfolio"><Building className="mr-2"/> Portfolio</TabsTrigger>
                                {designer.profileVideoUrl && <TabsTrigger value="video"><Video className="mr-2"/> Video</TabsTrigger>}
                                {galleryImages.length > 0 && <TabsTrigger value="gallery"><Camera className="mr-2"/> Gallery</TabsTrigger>}
                            </TabsList>
                            <TabsContent value="about" className="mt-4">
                                <Card>
                                    <CardHeader><CardTitle className="font-headline">About</CardTitle></CardHeader>
                                    <CardContent><p className="text-muted-foreground whitespace-pre-wrap">{designer.description}</p></CardContent>
                                </Card>
                            </TabsContent>
                            <TabsContent value="portfolio" className="mt-4">
                               {designs.length > 0 ? (
                                    <div className="grid sm:grid-cols-2 gap-6">
                                        {designs.map((design: Design) => <ItemCard key={design.id} item={design} itemType="design" />)}
                                    </div>
                                ) : (
                                    <Card className="text-center py-12">
                                        <CardContent>
                                            <p className="text-muted-foreground">No portfolio items have been added yet.</p>
                                        </CardContent>
                                    </Card>
                                )}
                            </TabsContent>
                            {designer.profileVideoUrl && (
                              <TabsContent value="video" className="mt-4">
                                <Card>
                                  <CardContent className="p-0 aspect-video rounded-lg overflow-hidden">
                                    <VideoEmbed url={designer.profileVideoUrl}/>
                                  </CardContent>
                                </Card>
                              </TabsContent>
                            )}
                            {galleryImages.length > 0 && (
                                <TabsContent value="gallery" className="mt-4">
                                     <div className="columns-2 md:columns-3 gap-4">
                                        {galleryImages.map((imgUrl: string, index: number) => (
                                             <div key={index} className="mb-4 break-inside-avoid">
                                                <Image src={imgUrl} alt={`Gallery image ${index + 1}`} width={400} height={400} className="object-cover w-full h-auto rounded-lg" />
                                            </div>
                                        ))}
                                    </div>
                                </TabsContent>
                            )}
                        </Tabs>
                    </div>

                     <div className="space-y-6">
                        <Card>
                            <CardHeader><CardTitle className="font-headline">Contact & Connect</CardTitle></CardHeader>
                            <CardContent className="space-y-3">
                                {designer.status === 'master' && (
                                    <>
                                        <SendInquiryDialog professionalName={designer.name} professionalId={designer.id}>
                                            <Button size="lg" className="w-full"><Send className="mr-2" /> Send Inquiry</Button>
                                        </SendInquiryDialog>
                                        {whatsappLink && <Button size="lg" variant="outline" asChild className="w-full"><Link href={whatsappLink} target="_blank"><MessageCircle className="mr-2" /> Chat</Link></Button>}
                                    </>
                                )}
                                {user && user.uid !== designer.id && <Button size="lg" variant={isFollowed ? 'default' : 'outline'} onClick={handleFollow} className="w-full"><UserPlus className="mr-2" /> {isFollowed ? 'Following' : 'Follow'}</Button>}
                            </CardContent>
                        </Card>
                         {socials && Object.values(socials).some(s => s) && (
                            <Card>
                                <CardHeader><CardTitle className="font-headline text-lg">Socials</CardTitle></CardHeader>
                                <CardContent className="flex items-center gap-2">
                                    {socials.linkedin && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#0077B5]"><Link href={socials.linkedin} target="_blank"><Linkedin/></Link></Button>}
                                    {socials.twitter && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1DA1F2]"><Link href={socials.twitter} target="_blank"><Twitter/></Link></Button>}
                                    {socials.instagram && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#E4405F]"><Link href={socials.instagram} target="_blank"><Instagram/></Link></Button>}
                                    {socials.facebook && <Button asChild variant="ghost" size="icon" className="text-muted-foreground hover:text-[#1877F2]"><Link href={socials.facebook} target="_blank"><Facebook/></Link></Button>}
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
);


export default function DesignerProfilePage() {
  const params = useParams();
  const designerId = params.id as string;
  const [designer, setDesigner] = useState<Provider | null>(null);
  const [designs, setDesigns] = useState<Design[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { follow, unfollow, isFollowing } = useFollow();
  const [followerCount, setFollowerCount] = useState(0);

  const isFollowed = isFollowing(designerId);

  const handleFollow = () => {
      if (isFollowed) {
          unfollow(designerId);
      } else {
          follow(designerId);
      }
  }

  useEffect(() => {
    if (!designerId) return;

    const followersRef = ref(db, `professional-followers/${designerId}`);
    const unsubscribeFollowers = onValue(followersRef, (snapshot) => {
        setFollowerCount(snapshot.size);
    });

    const fetchDesigner = async () => {
      setLoading(true);
      const userRef = ref(db, `users/${designerId}`);
      try {
        const snapshot = await get(userRef);
        if (snapshot.exists()) {
           const data = snapshot.val();
            const designerData: Provider = {
              id: designerId,
              name: data.companyName,
              specialty: data.specialty || 'Not specified',
              experienceLevel: data.experienceLevel,
              location: data.location || 'Not specified',
              locationUrl: data.locationUrl,
              description: data.description || 'No description available.',
              image: data.image || 'https://i.pravatar.cc/300',
              dataAiHint: 'architect portrait',
              rating: 4.8, 
              phone: data.phone,
              email: data.email,
              website: data.website,
              status: data.status || 'in-progress',
              gstNumber: data.gstNumber,
              architectureRegistrationNumber: data.architectureRegistrationNumber,
              localAuthorityRegistrationNumber: data.localAuthorityRegistrationNumber,
              socials: data.socials,
              workHistory: data.workHistory,
              skills: data.skills,
              catalogPdfUrl: data.catalogPdfUrl,
              role: 'designer',
              theme: data.theme || 'default',
              coverImage: data.coverImage,
              galleryImages: data.galleryImages,
              profileVideoUrl: data.profileVideoUrl,
            };
            setDesigner(designerData);

            const designsQuery = query(ref(db, 'designs'), orderByChild('designerId'), equalTo(designerId));
            onValue(designsQuery, (designSnapshot) => {
              const designsData = designSnapshot.val();
              if (designsData) {
                const designsList: Design[] = Object.keys(designsData).map(key => ({
                  id: key,
                  ...designsData[key],
                  image: designsData[key].image || 'https://picsum.photos/600/400',
                }));
                setDesigns(designsList);
              }
            });
        }
      } catch (error) {
        console.error("Error fetching designer data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDesigner();
    return () => unsubscribeFollowers();
  }, [designerId]);

  const embedUrl = getEmbedUrl(designer?.locationUrl);
  const whatsappMessage = `Hello ${designer?.name}, I found you on Homelya SMNP Nirman and I'm interested in your services.`;
  const whatsappLink = designer?.phone ? `https://wa.me/${designer.phone.replace(/\D/g, '')}?text=${encodeURIComponent(whatsappMessage)}` : null;
  const socials = designer?.socials;
  const skillsList = designer?.skills?.split(',').map(skill => skill.trim()).filter(skill => skill);
  const galleryImages = Array.isArray(designer?.galleryImages) ? designer.galleryImages.filter(Boolean) : [];

  if (loading) {
    return (
       <div className="space-y-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
             <Skeleton className="h-48 w-full" />
             <Skeleton className="h-64 w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-96 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!designer) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Designer not found</h2>
        <p className="text-muted-foreground">The designer you are looking for does not exist.</p>
      </div>
    );
  }
  
  const layoutProps = {
      designer, designs, embedUrl, whatsappLink, socials, skillsList, galleryImages, user, isFollowed, handleFollow, followerCount
  };

  switch (designer.theme) {
      case 'modern':
          return <ModernLayout {...layoutProps} />;
      case 'creative':
          return <CreativeLayout {...layoutProps} />;
      case 'premium':
          return <PremiumLayout {...layoutProps} />;
      default:
          return <DefaultLayout {...layoutProps} />;
  }
}
