

'use client';

import { useState, useMemo, useEffect, useCallback } from 'react';
import PageHeader from '@/components/page-header';
import ProfessionalListItem from '@/components/professional-list-item';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Loader2 } from 'lucide-react';
import { db } from '@/lib/firebase';
import { ref, onValue, set, push, serverTimestamp } from 'firebase/database';
import type { Provider } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import AdBanner from '@/components/ad-banner';

export default function DesignersPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const [designers, setDesigners] = useState<Provider[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  const [specialtyFilter, setSpecialtyFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');

  useEffect(() => {
    setLoading(true);
    const usersRef = ref(db, 'users');
    const unsubscribe = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const allUsers: any[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        
        const designersList: Provider[] = allUsers
          .filter(user => user.role === 'designer')
          .map(user => ({
            id: user.id,
            name: user.companyName,
            specialty: user.specialty || 'Not specified',
            location: user.location || 'Not specified',
            description: user.description || 'No description available.',
            image: user.image || 'https://picsum.photos/300/300',
            dataAiHint: 'architect portrait',
            rating: 4.5 + Math.random() * 0.5, // Placeholder rating
            status: user.status || 'in-progress',
            phone: user.phone,
        }));

        setDesigners(designersList);
      } else {
        setDesigners([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const designerSpecialties = useMemo(() => [...new Set(designers.map((d) => d.specialty))], [designers]);
  const designerLocations = useMemo(() => [...new Set(designers.map((d) => d.location))], [designers]);

  const generateLeadsForMasters = useCallback((location: string, masterProfessionals: Provider[]) => {
    if (!user || !location || masterProfessionals.length === 0) return;
    
    // Prevents professionals from getting leads from their own searches
    const currentUserIsProfessional = masterProfessionals.some(p => p.id === user.uid);
    if(currentUserIsProfessional) return;

    masterProfessionals.forEach(prof => {
        const leadRef = ref(db, `leads/${prof.id}`);
        const newLeadRef = push(leadRef);
        set(newLeadRef, {
            userName: user.displayName,
            userEmail: user.email,
            userPhone: user.phoneNumber || '',
            searchedLocation: location,
            timestamp: serverTimestamp(),
        }).catch(err => console.error("Failed to generate lead for", prof.id, err));
    });

    toast({
        title: "Master Professionals Notified",
        description: `Top professionals in ${location} have been notified of your interest.`,
    });

  }, [user, toast]);

  const filteredDesigners = useMemo(() => {
    const filtered = designers.filter((designer) => {
      const searchMatch = designer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          designer.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          designer.specialty?.toLowerCase().includes(searchTerm.toLowerCase());
      const specialtyMatch = specialtyFilter === 'all' || designer.specialty === specialtyFilter;
      const locationMatch = locationFilter === 'all' || designer.location === locationFilter;
      return searchMatch && specialtyMatch && locationMatch;
    });

    if (locationFilter !== 'all') {
        const masterProfessionalsInLocation = filtered.filter(d => d.status === 'master');
        if (masterProfessionalsInLocation.length > 0) {
            generateLeadsForMasters(locationFilter, masterProfessionalsInLocation);
        }
    }
    
    return filtered;

  }, [searchTerm, specialtyFilter, locationFilter, designers, generateLeadsForMasters]);

  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
       <Skeleton key={i} className="h-48 w-full" />
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader
        title="Find a Designer"
        description="Connect with talented architects and designers to bring your vision to life."
      />
      
      <AdBanner targetLocation={locationFilter !== 'all' ? locationFilter : undefined} />

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search designers by name, specialty..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={specialtyFilter} onValueChange={setSpecialtyFilter} disabled={loading}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by specialty" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Specialties</SelectItem>
            {designerSpecialties.map(specialty => (
              <SelectItem key={specialty} value={specialty}>{specialty}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={locationFilter} onValueChange={setLocationFilter} disabled={loading}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by location" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Locations</SelectItem>
            {designerLocations.map(location => (
              <SelectItem key={location} value={location}>{location}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-6">
        {loading ? renderSkeletons() : filteredDesigners.map((designer) => (
          <ProfessionalListItem key={designer.id} professional={designer} itemType="designer" />
        ))}
      </div>
      {!loading && filteredDesigners.length === 0 && (
        <div className="text-center col-span-full py-12">
            <h3 className="font-headline text-xl font-semibold">No Designers Found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters, or check back later.</p>
        </div>
       )}
    </div>
  );
}
