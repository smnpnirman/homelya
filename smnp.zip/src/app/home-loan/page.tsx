
import PageHeader from "@/components/page-header";
import HomeLoanForm from "./home-loan-form";
import Image from "next/image";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Banknote, FileCheck, Landmark, UserCheck } from "lucide-react";

export default function HomeLoanPage() {
  const partners = [
    { name: "HDFC Bank", logo: "https://i.ibb.co/P927s1T/hdfc-logo.png" },
    { name: "ICICI Bank", logo: "https://i.ibb.co/bXW7v2w/icici-logo.png" },
    { name: "State Bank of India", logo: "https://i.ibb.co/P927s1T/sbi-logo.png" },
    { name: "Axis Bank", logo: "https://i.ibb.co/P927s1T/axis-logo.png" },
    { name: "Kotak Mahindra Bank", logo: "https://i.ibb.co/P927s1T/kotak-logo.png" },
    { name: "Bank of Baroda", logo: "https://i.ibb.co/P927s1T/bob-logo.png" },
  ];
  return (
    <div className="space-y-8">
       <div className="relative w-full h-48 md:h-64 rounded-lg overflow-hidden">
         <Image 
            src="https://picsum.photos/seed/loan/1200/400"
            alt="Home loan banner"
            fill
            className="object-cover"
            data-ai-hint="house keys money"
         />
         <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <div className="text-center text-white p-4">
                 <h1 className="text-4xl md:text-5xl font-bold tracking-tighter">Home Loan Assistance</h1>
                 <p className="mt-2 text-lg md:text-xl text-white/80">
                    Secure the best financing for your dream home with our expert help.
                </p>
            </div>
         </div>
       </div>

        <Card>
            <CardHeader>
                <CardTitle className="font-headline text-xl">Our Banking Partners</CardTitle>
                <CardDescription>We've partnered with leading banks to offer you the best loan options.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center">
                {partners.map((partner) => (
                    <div key={partner.name} className="flex justify-center">
                        <Image
                            src={partner.logo}
                            alt={`${partner.name} Logo`}
                            width={120}
                            height={40}
                            className="object-contain"
                        />
                    </div>
                ))}
            </CardContent>
        </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-xl">RBI Guidelines for Home Loans in India</CardTitle>
        </CardHeader>
        <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="font-semibold">
                  <div className="flex items-center gap-2">
                    <UserCheck /> Eligibility Criteria
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground space-y-2 pl-8">
                  <p><b>Age:</b> Applicants are typically required to be between 21 and 65 years of age.</p>
                  <p><b>Income:</b> A stable source of income is mandatory, whether from salary or self-employment, to ensure repayment capability.</p>
                  <p><b>Credit Score:</b> A credit score of 750 or above is generally preferred by lenders for favorable loan terms.</p>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger className="font-semibold">
                  <div className="flex items-center gap-2">
                    <FileCheck /> Required Documents
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground space-y-2 pl-8">
                    <p><b>Proof of Identity:</b> PAN Card, Aadhaar Card, Passport, or Voter ID.</p>
                    <p><b>Proof of Address:</b> Recent utility bills, Aadhaar Card, or rental agreement.</p>
                    <p><b>Income Proof:</b> Latest salary slips, Form 16, and bank statements for salaried individuals; ITRs and business financials for self-employed.</p>
                    <p><b>Property Documents:</b> Sale agreement, title deeds, and approved building plans.</p>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger className="font-semibold">
                  <div className="flex items-center gap-2">
                    <Landmark /> Loan-to-Value (LTV) Ratio
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pl-8">
                  <p>The RBI mandates specific LTV ratios, meaning lenders can only finance a certain percentage of the property's value. The borrower must contribute the rest as a down payment. Typically, up to 90% for loans up to ₹30 lakh, 80% for loans between ₹30 lakh and ₹75 lakh, and 75% for loans above ₹75 lakh.</p>
                </AccordionContent>
              </AccordionItem>
               <AccordionItem value="item-4">
                <AccordionTrigger className="font-semibold">
                  <div className="flex items-center gap-2">
                    <Banknote /> Processing Fees & Charges
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pl-8">
                  <p>Lenders charge a non-refundable processing fee, which typically ranges from 0.5% to 1% of the loan amount. Our platform charges a fixed application fee of ₹1999 for initial processing and consultation. Ensure you understand all associated charges, including prepayment penalties (if any) and legal fees.</p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
        </CardContent>
      </Card>

      <HomeLoanForm />
    </div>
  );
}
