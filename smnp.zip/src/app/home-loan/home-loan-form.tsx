'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Send, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { ref, push, set, serverTimestamp } from 'firebase/database';
import { db } from '@/lib/firebase';
import Image from 'next/image';
import { Checkbox } from '@/components/ui/checkbox';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/use-auth';

const loanFormSchema = z.object({
  fullName: z.string().min(2, 'Full name must be at least 2 characters.'),
  email: z.string().email('Please enter a valid email address.'),
  phone: z.string().regex(/^[6-9]\d{9}$/, 'Please enter a valid 10-digit Indian mobile number.'),
  state: z.string({ required_error: 'Please select a state.' }),
  district: z.string().min(2, 'District must be at least 2 characters.'),
  pincode: z.string().regex(/^\d{6}$/, 'Please enter a valid 6-digit pincode.'),
  loanAmount: z.coerce.number().min(100000, 'Loan amount must be at least ₹1,00,000.'),
  annualIncome: z.coerce.number().min(200000, 'Annual income must be at least ₹2,00,000.'),
  employmentType: z.enum(['salaried', 'self-employed'], {
    required_error: 'Please select your employment type.',
  }),
  transactionId: z.string().min(10, 'Please enter a valid transaction ID.'),
  guidelinesRead: z.boolean().refine((val) => val === true, {
    message: 'You must read and agree to the guidelines before applying.',
  }),
});

type LoanFormValues = z.infer<typeof loanFormSchema>;

const indianStatesAndUTs = [
  "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", 
  "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", 
  "Jharkhand", "Karnataka", "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", 
  "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", 
  "Uttar Pradesh", "Uttarakhand", "West Bengal"
];


export default function HomeLoanForm() {
  const { toast } = useToast();
  const router = useRouter();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const upiId = '6204910508@mbk';
  const payeeName = 'Homelya';
  const price = 1999;
  const upiLink = `upi://pay?pa=${upiId}&pn=${payeeName}&am=${price}&cu=INR&tn=Home Loan Application Fee`;


  const form = useForm<LoanFormValues>({
    resolver: zodResolver(loanFormSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      district: '',
      pincode: '',
      loanAmount: 1000000,
      annualIncome: 500000,
      transactionId: '',
      guidelinesRead: false,
    },
  });

  const onSubmit = async (data: LoanFormValues) => {
    if (!user) {
        toast({ variant: 'destructive', title: 'Not Logged In', description: 'You must be logged in to apply.' });
        return;
    }
    setLoading(true);
    try {
      const inquiriesRef = ref(db, 'home-loan-inquiries');
      const newInquiryRef = push(inquiriesRef);
      await set(newInquiryRef, {
        ...data,
        userId: user.uid,
        status: 'verifying',
        applicationFee: price,
        timestamp: serverTimestamp(),
      });
      
      // Log transaction
      const userTransactionsRef = ref(db, `transactions/${user.uid}`);
      const newTransactionRef = push(userTransactionsRef);
      await set(newTransactionRef, {
        amount: price,
        description: `Home Loan Application Fee`,
        timestamp: serverTimestamp(),
        type: 'payment',
        status: 'pending'
      });

      toast({
        title: 'Application Submitted!',
        description: 'Thank you for your inquiry. You will now be redirected to your application token.',
      });
      router.push(`/home-loan-token/${newInquiryRef.key}`);
    } catch (error) {
      console.error('Failed to submit loan inquiry:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'An error occurred while submitting your application.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
            <CardTitle className="font-headline text-xl">Home Loan Application Form</CardTitle>
            <CardDescription>Fill out the form below to start your home loan process. A non-refundable fee of ₹{price} is required.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
             <Card className="bg-muted/50">
                <CardHeader>
                    <CardTitle className="text-base">Step 1: Pay Application Fee via UPI</CardTitle>
                    <CardDescription>Scan the QR code with any UPI app.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col items-center gap-4">
                    <Image 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(upiLink)}`}
                        alt="UPI QR Code for application fee"
                        width={180}
                        height={180}
                        className="rounded-md border p-2"
                    />
                    <p className="font-mono font-semibold text-base">{upiId}</p>
                </CardContent>
            </Card>

            <Card className="bg-muted/50">
                <CardHeader>
                    <CardTitle className="text-base">Step 2: Enter Applicant & Payment Details</CardTitle>
                    <CardDescription>After paying, enter your details and the UPI transaction ID.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6 pt-4">
                    <FormField
                        control={form.control}
                        name="transactionId"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>UPI Transaction ID</FormLabel>
                            <FormControl>
                                <Input 
                                    placeholder="e.g., 217382193812" 
                                    {...field}
                                />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <div className="grid sm:grid-cols-2 gap-6">
                    <FormField
                        control={form.control}
                        name="fullName"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                            <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Mobile Number</FormLabel>
                            <div className="flex items-center">
                                <span className="inline-flex items-center px-3 h-10 rounded-l-md border border-r-0 border-input bg-background text-sm">+91</span>
                                <FormControl>
                                <Input placeholder="9876543210" {...field} className="rounded-l-none" />
                                </FormControl>
                            </div>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    </div>
                    <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                            <Input type="email" placeholder="you@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <div className="grid sm:grid-cols-3 gap-6">
                        <FormField
                            control={form.control}
                            name="state"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>State</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select State" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    {indianStatesAndUTs.map(state => <SelectItem key={state} value={state}>{state}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="district"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>District</FormLabel>
                                <FormControl>
                                <Input placeholder="e.g., Ranchi" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="pincode"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>Pincode</FormLabel>
                                <FormControl>
                                <Input placeholder="e.g., 834001" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                    </div>
                    <div className="grid sm:grid-cols-2 gap-6">
                    <FormField
                        control={form.control}
                        name="loanAmount"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Desired Loan Amount (₹)</FormLabel>
                            <FormControl>
                            <Input type="number" placeholder="e.g., 2500000" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="annualIncome"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Gross Annual Income (₹)</FormLabel>
                            <FormControl>
                            <Input type="number" placeholder="e.g., 800000" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    </div>
                    <FormField
                    control={form.control}
                    name="employmentType"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Employment Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                            <SelectTrigger>
                                <SelectValue placeholder="Select your employment type" />
                            </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                            <SelectItem value="salaried">Salaried</SelectItem>
                            <SelectItem value="self-employed">Self-Employed</SelectItem>
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                </CardContent>
            </Card>

            <FormField
                control={form.control}
                name="guidelinesRead"
                render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 shadow">
                    <FormControl>
                        <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                        <FormLabel>
                        I have read and agree to all the guidelines.
                        </FormLabel>
                        <FormMessage />
                    </div>
                    </FormItem>
                )}
                />
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <ShieldCheck className="mr-2 h-5 w-5" />}
              {loading ? 'Submitting...' : 'Apply & Verify Payment'}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
