
'use client';

import PageHeader from "@/components/page-header";
import ProfessionalListItem from "@/components/professional-list-item";
import { useAuth } from "@/hooks/use-auth";
import { useFollow } from "@/hooks/use-follow";
import { db } from "@/lib/firebase";
import type { Provider, Supplier } from "@/lib/types";
import { get, ref } from "firebase/database";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import Link from "next/link";
import { Users } from "lucide-react";

type Professional = (Provider | Supplier) & { role: string };

export default function FollowingPage() {
  const { user } = useAuth();
  const { following } = useFollow();
  const [followedProfessionals, setFollowedProfessionals] = useState<Professional[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFollowedProfessionals = async () => {
      if (following.length === 0) {
        setLoading(false);
        setFollowedProfessionals([]);
        return;
      }

      setLoading(true);
      const promises = following.map(id => get(ref(db, `users/${id}`)));
      const snapshots = await Promise.all(promises);
      const professionalsData = snapshots.map((snapshot, index) => {
        if (snapshot.exists()) {
          const data = snapshot.val();
          return {
            id: following[index],
            name: data.companyName,
            specialty: data.specialty || (data.role === 'supplier' ? data.category : 'Not specified'),
            category: data.category,
            location: data.location || 'Not specified',
            description: data.description || 'No description available.',
            image: data.image || 'https://placehold.co/400x400.png',
            dataAiHint: 'professional portrait',
            rating: 4.5 + Math.random() * 0.5,
            role: data.role,
            status: data.status,
            phone: data.phone,
          } as Professional;
        }
        return null;
      }).filter((p): p is Professional => p !== null);

      setFollowedProfessionals(professionalsData);
      setLoading(false);
    };

    fetchFollowedProfessionals();
  }, [following]);

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to view this page.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
       <Skeleton key={i} className="h-48 w-full" />
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader
        title="Following"
        description="A list of all the professionals you follow."
      />
      {loading ? (
        <div className="space-y-6">
            {renderSkeletons()}
        </div>
      ) : followedProfessionals.length === 0 ? (
        <div className="text-center col-span-full py-16 border bg-card rounded-lg flex flex-col items-center">
            <Users className="w-16 h-16 text-muted-foreground/50 mb-4" />
            <h3 className="font-headline text-2xl font-semibold">You aren't following anyone yet.</h3>
            <p className="text-muted-foreground max-w-md mx-auto mt-2">
              Click the "Follow" button on a professional's page to add them here.
            </p>
            <Button asChild className="mt-6">
                <Link href="/designers">Find Professionals</Link>
            </Button>
        </div>
      ) : (
        <div className="space-y-6">
          {followedProfessionals.map((professional) => (
            <ProfessionalListItem key={professional.id} professional={professional} itemType={professional.role as any} />
          ))}
        </div>
      )}
    </div>
  );
}
