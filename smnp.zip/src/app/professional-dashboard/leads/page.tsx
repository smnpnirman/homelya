
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, query, orderByChild, get } from "firebase/database";
import { Skeleton } from "@/components/ui/skeleton";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { formatDistanceToNow } from 'date-fns';
import { Mail, Phone, User, Sparkles, MapPin, Gem } from "lucide-react";
import type { VerificationStatus } from "@/lib/types";

interface Lead {
    id: string;
    userName: string;
    userEmail: string;
    userPhone: string;
    searchedLocation: string;
    timestamp: number;
}

export default function LeadsPage() {
  const { user } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState<VerificationStatus | 'loading'>('loading');

  useEffect(() => {
    if (user) {
        const userRef = ref(db, `users/${user.uid}`);
        get(userRef).then(snapshot => {
            if (snapshot.exists()) {
                setStatus(snapshot.val().status || 'in-progress');
            }
        });

        const leadsRef = query(ref(db, `leads/${user.uid}`), orderByChild('timestamp'));
        const unsubscribe = onValue(leadsRef, (snapshot) => {
            const data = snapshot.val();
            const leadsList: Lead[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key]
            })).sort((a, b) => b.timestamp - a.timestamp) : [];
            setLeads(leadsList);
            setLoading(false);
        });

        return () => unsubscribe();
    } else {
        setLoading(false);
    }
  }, [user]);

  if (loading) {
      return (
        <div className="space-y-8">
            <PageHeader title="My Leads" />
            <div className="space-y-4">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
            </div>
        </div>
      )
  }
  
  if (!user || status !== 'master') {
    return (
        <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
                <CardHeader>
                    <div className="mx-auto bg-purple-100 text-purple-600 rounded-full h-16 w-16 flex items-center justify-center">
                        <Gem className="h-8 w-8" />
                    </div>
                </CardHeader>
                <CardContent>
                    <CardTitle className="font-headline text-xl">Upgrade to Master Professional</CardTitle>
                    <CardDescription className="mt-2">
                        This feature is exclusive to Master Professionals. Upgrade your account to receive location-based leads automatically.
                    </CardDescription>
                </CardContent>
                <CardFooter>
                     <Button asChild className="mx-auto">
                        <Link href="/professional-dashboard/verify">Upgrade Now</Link>
                    </Button>
                </CardFooter>
            </Card>
        </div>
    )
  }


  return (
    <div className="space-y-8">
       <PageHeader
        title="My Leads"
        description="Potential clients who have searched for professionals in your service area."
      />

      {leads.length === 0 ? (
        <Card>
            <CardContent className="p-8 text-center">
                <Sparkles className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-headline text-xl">No Leads Yet</h3>
                <p className="text-muted-foreground">When users search for professionals in your location, leads will appear here.</p>
            </CardContent>
        </Card>
      ) : (
        <Card>
            <CardContent className="p-0">
                <Accordion type="single" collapsible className="w-full">
                    {leads.map((lead) => (
                        <AccordionItem value={lead.id} key={lead.id}>
                            <AccordionTrigger className="px-6 py-4 hover:bg-muted/50">
                                <div className="flex justify-between items-center w-full">
                                    <div className="flex items-center gap-4">
                                        <User className="text-primary"/>
                                        <div className="text-left">
                                            <p className="font-semibold">{lead.userName}</p>
                                            <p className="text-sm text-muted-foreground">
                                                Received {formatDistanceToNow(new Date(lead.timestamp), { addSuffix: true })}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground pr-4">
                                      <MapPin className="h-4 w-4" />
                                      <span>Searched in: {lead.searchedLocation}</span>
                                    </div>
                                </div>
                            </AccordionTrigger>
                            <AccordionContent className="px-6 pb-6 bg-muted/20">
                                <div className="space-y-4 pt-4">
                                    <h4 className="font-semibold text-base">Contact Details</h4>
                                    <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                                        <a href={`mailto:${lead.userEmail}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Mail className="h-4 w-4"/> {lead.userEmail}</a>
                                        {lead.userPhone && <a href={`tel:${lead.userPhone}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Phone className="h-4 w-4"/> {lead.userPhone}</a>}
                                    </div>
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
            </CardContent>
        </Card>
      )}
    </div>
  );
}
