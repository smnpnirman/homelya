

'use client';

import { useRouter } from 'next/navigation';
import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LogIn, CheckCircle, Loader2, Clock } from 'lucide-react';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';
import { db } from '@/lib/firebase';
import { ref, onValue } from 'firebase/database';
import { useState, useEffect } from 'react';

interface VROrder {
    status: 'payment-pending' | 'verified' | 'rejected';
    vrId?: string;
}

function RazorpayButton() {
    useEffect(() => {
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/payment-button.js';
        script.async = true;
        script.dataset.payment_button_id = 'pl_RJn9hoWLKpBBax';

        const form = document.getElementById('razorpay-form');
        if (form) {
            form.appendChild(script);
        }

        return () => {
            const existingScript = document.querySelector('script[src="https://checkout.razorpay.com/v1/payment-button.js"]');
            if (existingScript && existingScript.parentElement === form) {
                form?.removeChild(existingScript);
            }
        };
    }, []);

    return <form id="razorpay-form"></form>;
}

export default function VROrderPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [orderStatus, setOrderStatus] = useState<VROrder | null>(null);
  const [checkingStatus, setCheckingStatus] = useState(true);

  useEffect(() => {
    if (user) {
        const orderRef = ref(db, `vr-orders`);
        const unsubscribe = onValue(orderRef, (snapshot) => {
            let foundOrder: VROrder | null = null;
            if(snapshot.exists()) {
                const orders = snapshot.val();
                for (const orderId in orders) {
                    if (orders[orderId].professionalId === user.uid) {
                        foundOrder = orders[orderId];
                        break;
                    }
                }
            }
            setOrderStatus(foundOrder);
            setCheckingStatus(false);
        });
        return () => unsubscribe();
    } else {
      setCheckingStatus(false);
    }
  }, [user]);

  if (checkingStatus) {
      return (
          <div className="flex items-center justify-center h-64">
              <Loader2 className="h-8 w-8 animate-spin" />
          </div>
      )
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Authentication Required</CardTitle>
            <CardDescription>You need to be logged in to order a VR kit.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href={`/login?redirect=/professional-dashboard/vr-order`}> <LogIn className="mr-2"/> Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (orderStatus?.status === 'payment-pending') {
      return (
           <div className="space-y-8 max-w-2xl mx-auto">
              <PageHeader
                title="Order in Progress"
                description="Your payment is currently being reviewed by our team."
              />
              <Card className="bg-blue-50 border-blue-200 text-center">
                <CardHeader>
                    <div className="mx-auto bg-blue-100 text-blue-600 rounded-full h-16 w-16 flex items-center justify-center">
                        <Clock className="h-8 w-8" />
                    </div>
                </CardHeader>
                <CardContent>
                    <CardTitle className="font-headline text-xl text-blue-900">
                        We've Received Your Order
                    </CardTitle>
                    <CardDescription className="text-blue-800 mt-2">
                        Thank you for submitting your payment. Verification can take up to 48 hours. We'll notify you once your order is approved.
                    </CardDescription>
                </CardContent>
                <CardFooter>
                    <Button asChild className="mx-auto" variant="outline">
                        <Link href="/professional-dashboard">Back to Dashboard</Link>
                    </Button>
                </CardFooter>
              </Card>
           </div>
      )
  }

    if (orderStatus?.status === 'verified') {
      return (
           <div className="space-y-8 max-w-2xl mx-auto">
              <PageHeader
                title="VR Kit Assigned"
                description="Your VR Kit has been approved and assigned."
              />
              <Card className="bg-green-50 border-green-200 text-center">
                <CardHeader>
                    <div className="mx-auto bg-green-100 text-green-600 rounded-full h-16 w-16 flex items-center justify-center">
                        <CheckCircle className="h-8 w-8" />
                    </div>
                </CardHeader>
                <CardContent>
                    <CardTitle className="font-headline text-xl text-green-900">
                        Your VR Kit is Ready!
                    </CardTitle>
                    <CardDescription className="text-green-800 mt-2">
                        Your assigned VR Kit ID is below. Our team will contact you regarding delivery.
                    </CardDescription>
                    <div className="mt-4 bg-background p-4 rounded-lg">
                        <p className="text-sm text-muted-foreground">Your VR Kit ID</p>
                        <p className="text-2xl font-bold font-mono text-primary">{orderStatus.vrId || "Pending Assignment"}</p>
                    </div>
                </CardContent>
                <CardFooter>
                    <Button asChild className="mx-auto" variant="outline">
                        <Link href="/professional-dashboard">Back to Dashboard</Link>
                    </Button>
                </CardFooter>
              </Card>
           </div>
      )
  }

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <PageHeader
        title="Order Your VR Kit"
        description="Pay a one-time refundable security deposit to get your VR kit."
      />
      <div className="grid gap-8 items-start">
        <Card>
          <CardHeader>
            <CardTitle className="font-headline">Pay Security Deposit via Razorpay</CardTitle>
            <CardDescription>Click the button below to pay the refundable security deposit of ₹6,000. After payment, our team will verify it and process your order.</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center items-center py-8">
            <RazorpayButton />
          </CardContent>
          <CardFooter>
            <p className="text-xs text-muted-foreground">The security deposit is fully refundable upon return of the kit in good condition. By clicking the payment button, you agree to our terms and conditions.</p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
