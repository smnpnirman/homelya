
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ExternalLink, Loader2, PlusCircle } from 'lucide-react';
import { useState } from 'react';
import { ref, push, set } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';

const projectFormSchema = z.object({
  name: z.string().min(5, 'Project name must be at least 5 characters.'),
  description: z.string().min(20, 'Description must be at least 20 characters.'),
  // In a real app, this would be an image upload field
  image: z.string().url('Please enter a valid image URL.').optional().or(z.literal('')),
});

type ProjectFormValues = z.infer<typeof projectFormSchema>;

export default function AddProjectForm({ constructorId }: { constructorId: string }) {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      name: '',
      description: '',
      image: '',
    },
  });

  const watchImage = form.watch('image');

  const onSubmit = async (data: ProjectFormValues) => {
    setLoading(true);
    try {
      const projectsRef = ref(db, `projects/${constructorId}`);
      const newProjectRef = push(projectsRef);
      
      const projectData = {
          ...data,
          image: data.image || `https://picsum.photos/seed/${newProjectRef.key}/600/400`,
      }

      await set(newProjectRef, projectData);

      toast({
        title: 'Project Added!',
        description: 'Your new project has been added to your portfolio.',
      });
      router.push(`/constructors/${constructorId}`); 
    } catch (error) {
      console.error('Failed to add project:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'An error occurred while adding your project.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
            <CardTitle className="font-headline text-xl">Project Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Name / Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Luxury Residential Villa in Ashok Nagar" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Briefly describe the project, its scope, and any key highlights..."
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="image"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Image URL</FormLabel>
                  <div className="flex gap-2">
                    <FormControl>
                      <Input placeholder="https://example.com/image.png" {...field} />
                    </FormControl>
                    {watchImage && (
                      <Button asChild variant="ghost" size="icon">
                        <Link href={watchImage} target="_blank">
                          <ExternalLink className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}
                  </div>
                  {watchImage && (
                    <div className="mt-2">
                        <Image src={watchImage} alt="Image preview" width={200} height={150} className="rounded-md object-cover" />
                    </div>
                  )}
                  <FormDescription>Leave blank to use a dynamic placeholder image.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg" disabled={loading}>
              {loading ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <PlusCircle className="mr-2 h-5 w-5" />
              )}
              Add Project
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
