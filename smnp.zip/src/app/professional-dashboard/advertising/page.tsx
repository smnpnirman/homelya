
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, query, orderByChild, equalTo } from "firebase/database";
import type { Advertisement, AdvertisementStatus } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, CheckCircle, Clock, XCircle, Megaphone } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

function adStatusToJsx(status: AdvertisementStatus) {
    switch(status) {
        case 'pending':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><Clock className="mr-1.5" />Pending Approval</Badge>;
        case 'active':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="mr-1.5" />Active</Badge>;
        case 'rejected':
            return <Badge variant="destructive"><XCircle className="mr-1.5" />Rejected</Badge>;
        case 'paused':
            return <Badge variant="outline">Paused</Badge>;
        case 'completed':
            return <Badge variant="secondary">Completed</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function AdvertisingPage() {
  const { user } = useAuth();
  const [ads, setAds] = useState<Advertisement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      setLoading(true);
      const adsQuery = query(ref(db, 'advertisements'), orderByChild('professionalId'), equalTo(user.uid));
      const unsubscribe = onValue(adsQuery, (snapshot) => {
        const data = snapshot.val();
        const adsList: Advertisement[] = data ? Object.keys(data).map(key => ({
            id: key,
            ...data[key],
        })).sort((a, b) => b.createdAt - a.createdAt) : [];
        setAds(adsList);
        setLoading(false);
      });
      return () => unsubscribe();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to manage advertisements.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="My Ad Campaigns"
        description="Manage your advertisements to reach more clients."
      >
        <Button asChild>
            <Link href="/professional-dashboard/advertising/new">
                <PlusCircle className="mr-2 h-4 w-4" /> Create New Ad
            </Link>
        </Button>
      </PageHeader>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Campaign Name</TableHead>
                <TableHead>Budget</TableHead>
                <TableHead>Target</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                  </TableRow>
                ))
              ) : ads.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-48 text-center">
                    <div className="flex flex-col items-center gap-4">
                        <Megaphone className="h-12 w-12 text-muted-foreground" />
                        <h3 className="font-semibold text-lg">No ads created yet.</h3>
                        <p className="text-muted-foreground">Click the button below to launch your first ad campaign!</p>
                        <Button asChild>
                           <Link href="/professional-dashboard/advertising/new">
                                <PlusCircle className="mr-2 h-4 w-4" /> Create New Ad
                            </Link>
                        </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                ads.map(ad => (
                  <TableRow key={ad.id}>
                    <TableCell className="font-medium">{ad.campaignName}</TableCell>
                    <TableCell>₹{ad.budget.toLocaleString('en-IN')}</TableCell>
                    <TableCell>{ad.targetLocation}</TableCell>
                    <TableCell>{adStatusToJsx(ad.status)}</TableCell>
                    <TableCell>{format(new Date(ad.createdAt), 'PPP')}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
