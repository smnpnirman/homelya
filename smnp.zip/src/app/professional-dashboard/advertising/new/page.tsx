'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import AddAdForm from "./add-ad-form";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, get } from "firebase/database";

export default function CreateAdPage() {
  const { user } = useAuth();
  const [userRole, setUserRole] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      const userRef = ref(db, `users/${user.uid}/role`);
      get(userRef).then((snapshot) => {
        if (snapshot.exists()) {
          setUserRole(snapshot.val());
        }
      });
    }
  }, [user]);

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to create an advertisement.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Create a New Ad Campaign"
        description="Fill out the details below to launch your ad."
      />
      {userRole && <AddAdForm userId={user.uid} professionalName={user.displayName || ''} userRole={userRole} />}
    </div>
  );
}
