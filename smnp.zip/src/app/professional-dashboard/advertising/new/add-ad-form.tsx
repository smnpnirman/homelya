'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ExternalLink, Loader2, Megaphone } from 'lucide-react';
import { useState } from 'react';
import { ref, push, set, serverTimestamp } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';

const adFormSchema = z.object({
  campaignName: z.string().min(5, 'Campaign name must be at least 5 characters.'),
  targetLocation: z.string().min(3, 'Target location is required.'),
  budget: z.coerce.number().min(500, 'Budget must be at least ₹500.'),
  adCopy: z.string().min(20, 'Ad copy must be at least 20 characters.').max(150, 'Ad copy cannot exceed 150 characters.'),
  adImage: z.string().url('Please enter a valid image URL.'),
});

type AdFormValues = z.infer<typeof adFormSchema>;

interface AddAdFormProps {
    userId: string;
    professionalName: string;
    userRole: string;
}

export default function AddAdForm({ userId, professionalName, userRole }: AddAdFormProps) {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const form = useForm<AdFormValues>({
    resolver: zodResolver(adFormSchema),
    defaultValues: {
      campaignName: '',
      targetLocation: 'Ranchi',
      budget: 1000,
      adCopy: '',
      adImage: '',
    },
  });

  const watchAdImage = form.watch('adImage');
  const watchTargetLocation = form.watch('targetLocation');
  const watchAdCopy = form.watch('adCopy');

  const onSubmit = async (data: AdFormValues) => {
    setLoading(true);
    let ctaLink = '';
    if (userRole === 'designer' || userRole === 'constructor' || userRole === 'supplier' || userRole === 'seller') {
        ctaLink = `/${userRole}s/${userId}`;
    }

    try {
      const adsRef = ref(db, 'advertisements');
      const newAdRef = push(adsRef);
      
      const adData = {
          ...data,
          id: newAdRef.key,
          professionalId: userId,
          professionalName: professionalName,
          ctaLink: ctaLink,
          status: 'pending',
          createdAt: serverTimestamp(),
      }

      await set(newAdRef, adData);

      toast({
        title: 'Ad Submitted for Approval!',
        description: 'Your new ad campaign has been submitted and is pending review.',
      });
      router.push('/professional-dashboard/advertising'); 
    } catch (error) {
      console.error('Failed to create ad:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'An error occurred while submitting your ad.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                  <Card>
                      <CardHeader>
                          <CardTitle className="font-headline text-xl">Campaign Details</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                          <FormField
                          control={form.control}
                          name="campaignName"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Campaign Name</FormLabel>
                              <FormControl>
                                  <Input placeholder="e.g., Diwali Special Ranchi" {...field} />
                              </FormControl>
                              <FormMessage />
                              </FormItem>
                          )}
                          />
                          <div className="grid md:grid-cols-2 gap-6">
                              <FormField
                              control={form.control}
                              name="targetLocation"
                              render={({ field }) => (
                                  <FormItem>
                                  <FormLabel>Target Location</FormLabel>
                                  <FormControl>
                                      <Input placeholder="e.g., Ranchi" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                  </FormItem>
                              )}
                              />
                              <FormField
                              control={form.control}
                              name="budget"
                              render={({ field }) => (
                                  <FormItem>
                                  <FormLabel>Budget (INR)</FormLabel>
                                  <FormControl>
                                      <Input type="number" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                  </FormItem>
                              )}
                              />
                          </div>
                           <FormField
                          control={form.control}
                          name="adCopy"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Ad Copy</FormLabel>
                              <FormControl>
                                  <Textarea
                                  placeholder="Write a short, catchy message for your ad..."
                                  rows={3}
                                  {...field}
                                  />
                              </FormControl>
                              <FormDescription>Max 150 characters.</FormDescription>
                              <FormMessage />
                              </FormItem>
                          )}
                          />
                          <FormField
                          control={form.control}
                          name="adImage"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Ad Image URL</FormLabel>
                              <div className="flex gap-2">
                                  <FormControl>
                                  <Input placeholder="https://example.com/ad-image.png" {...field} />
                                  </FormControl>
                                  {watchAdImage && (
                                  <Button asChild variant="ghost" size="icon">
                                      <Link href={watchAdImage} target="_blank">
                                      <ExternalLink className="h-4 w-4" />
                                      </Link>
                                  </Button>
                                  )}
                              </div>
                              <FormMessage />
                              </FormItem>
                          )}
                          />
                      </CardContent>
                  </Card>
                  <div className="flex justify-end mt-6">
                      <Button type="submit" size="lg" disabled={loading}>
                      {loading ? (
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      ) : (
                          <Megaphone className="mr-2 h-5 w-5" />
                      )}
                      Submit for Approval
                      </Button>
                  </div>
              </div>

              <div className="lg:col-span-1">
                  <Card>
                      <CardHeader>
                          <CardTitle>Ad Preview</CardTitle>
                          <CardDescription>This is how your ad might appear.</CardDescription>
                      </CardHeader>
                      <CardContent>
                           <div className="border rounded-lg overflow-hidden">
                              {watchAdImage ? (
                                  <Image
                                      src={watchAdImage}
                                      alt="Ad preview"
                                      width={400}
                                      height={250}
                                      className="object-cover w-full aspect-video"
                                  />
                              ) : (
                                  <div className="bg-muted aspect-video w-full flex items-center justify-center">
                                      <p className="text-muted-foreground text-sm">Image will appear here</p>
                                  </div>
                              )}
                              <div className="p-4">
                                  <p className="text-xs font-semibold text-primary">Sponsored in {watchTargetLocation || 'your area'}</p>
                                  <h4 className="font-semibold leading-tight mt-1">{professionalName}</h4>
                                  <p className="text-sm text-muted-foreground mt-2 line-clamp-3">
                                      {watchAdCopy || "Your ad copy will appear here. Make it short and engaging to attract customers."}
                                  </p>
                                  <Button variant="outline" size="sm" className="w-full mt-4" disabled>Learn More</Button>
                              </div>
                          </div>
                      </CardContent>
                  </Card>
              </div>
          </div>
      </form>
    </Form>
  );
}
