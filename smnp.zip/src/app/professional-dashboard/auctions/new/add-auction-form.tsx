
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ExternalLink, Loader2, PlusCircle, Gavel, Calendar as CalendarIcon } from 'lucide-react';
import { useState } from 'react';
import { ref, push, set } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Link from 'next/link';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';

const auctionFormSchema = z.object({
  name: z.string().min(10, 'Title must be at least 10 characters.'),
  description: z.string().min(50, 'Description must be at least 50 characters.'),
  startingBid: z.coerce.number().min(100000, 'Starting bid must be at least 1,00,000.'),
  bidIncrement: z.coerce.number().min(1000, 'Bid increment must be at least 1,000.'),
  endTime: z.date({ required_error: "An end date for the auction is required."}),
  location: z.string().min(3, 'Location is required.'),
  area: z.coerce.number().min(100, 'Area must be at least 100 sqft.'),
  bedrooms: z.coerce.number().min(0, 'Bedrooms cannot be negative.'),
  bathrooms: z.coerce.number().min(0, 'Bathrooms cannot be negative.'),
  propertyType: z.enum(['Apartment', 'Villa', 'Plot', 'House']),
  image: z.string().url('Please enter a valid primary image URL.'),
  images: z.string().optional().describe('A comma-separated list of additional image URLs.'),
});

type AuctionFormValues = z.infer<typeof auctionFormSchema>;

export default function AddAuctionForm({ sellerId }: { sellerId: string }) {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const form = useForm<AuctionFormValues>({
    resolver: zodResolver(auctionFormSchema),
    defaultValues: {
      name: '',
      description: '',
      startingBid: 1000000,
      bidIncrement: 10000,
      location: '',
      area: 1200,
      bedrooms: 2,
      bathrooms: 2,
      image: '',
      images: '',
    },
  });

  const watchImage = form.watch('image');

  const onSubmit = async (data: AuctionFormValues) => {
    setLoading(true);
    try {
      const auctionsRef = ref(db, 'auctions');
      const newAuctionRef = push(auctionsRef);
      
      const additionalImages = data.images?.split(',').map(url => url.trim()).filter(url => url) || [];

      const auctionData = {
          ...data,
          endTime: data.endTime.getTime(),
          images: [data.image, ...additionalImages],
          currentBid: data.startingBid,
          sellerId,
          status: 'active',
          bids: {},
      }
      delete (auctionData as any).image;

      await set(newAuctionRef, auctionData);

      toast({
        title: 'Auction Created!',
        description: 'Your new property auction has been successfully listed.',
      });
      router.push(`/auctions/${newAuctionRef.key}`); 
    } catch (error) {
      console.error('Failed to create auction:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'An error occurred while creating your auction.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
            <CardTitle className="font-headline text-xl">Auction Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Property Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Prime Plot for Auction in Morabadi" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the key features, amenities, and location advantages..."
                      rows={5}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <div className="grid md:grid-cols-3 gap-6">
                 <FormField
                    control={form.control}
                    name="startingBid"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Starting Bid (INR)</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="e.g., 5000000" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                <FormField
                    control={form.control}
                    name="bidIncrement"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Min. Bid Increment (INR)</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="e.g., 10000" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                 <FormField
                    control={form.control}
                    name="endTime"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                        <FormLabel>Auction End Date</FormLabel>
                        <Popover>
                            <PopoverTrigger asChild>
                            <FormControl>
                                <Button
                                variant={"outline"}
                                className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                )}
                                >
                                {field.value ? (
                                    format(field.value, "PPP")
                                ) : (
                                    <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                            </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) =>
                                date < new Date()
                                }
                                initialFocus
                            />
                            </PopoverContent>
                        </Popover>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
            </div>
            <div className="grid md:grid-cols-2 gap-6">
                 <FormField
                    control={form.control}
                    name="propertyType"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Property Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                            <SelectTrigger>
                                <SelectValue placeholder="Select property type" />
                            </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                                <SelectItem value="Apartment">Apartment</SelectItem>
                                <SelectItem value="Villa">Villa</SelectItem>
                                <SelectItem value="Plot">Plot</SelectItem>
                                <SelectItem value="House">House</SelectItem>
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                            <Input placeholder="e.g., Kanke, Ranchi" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
             <div className="grid md:grid-cols-3 gap-6">
                 <FormField
                    control={form.control}
                    name="area"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Area (sqft)</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="e.g., 1200" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                control={form.control}
                name="bedrooms"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Bedrooms</FormLabel>
                    <FormControl>
                        <Input type="number" placeholder="2" {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
                <FormField
                control={form.control}
                name="bathrooms"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Bathrooms</FormLabel>
                    <FormControl>
                        <Input type="number" placeholder="2" {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>
            <FormField
              control={form.control}
              name="image"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Image URL</FormLabel>
                  <div className="flex gap-2">
                    <FormControl>
                      <Input placeholder="https://example.com/main-image.png" {...field} />
                    </FormControl>
                    {watchImage && (
                      <Button asChild variant="ghost" size="icon">
                        <Link href={watchImage} target="_blank">
                          <ExternalLink className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}
                  </div>
                   <FormDescription>This will be the main cover image for your auction.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="images"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Image URLs (Optional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="https://example.com/image1.png, https://example.com/image2.png" {...field} />
                  </FormControl>
                  <FormDescription>Add more image URLs, separated by commas.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg" disabled={loading}>
              {loading ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <Gavel className="mr-2 h-5 w-5" />
              )}
              Create Auction
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
