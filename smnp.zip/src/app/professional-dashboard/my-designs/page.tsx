
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, remove, query, orderByChild, equalTo } from "firebase/database";
import type { Design } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { MoreVertical, Trash2, Edit, PlusCircle, IndianRupee } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Badge } from "@/components/ui/badge";

export default function MyDesignsPage() {
  const { user, userData } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [designs, setDesigns] = useState<Design[]>([]);
  const [loading, setLoading] = useState(true);
  const [designToDelete, setDesignToDelete] = useState<Design | null>(null);
  const isDubai = userData?.country === 'dubai';

  useEffect(() => {
    if (user) {
      setLoading(true);
      const designsQuery = query(ref(db, 'designs'), orderByChild('designerId'), equalTo(user.uid));
      const unsubscribe = onValue(designsQuery, (snapshot) => {
          const data = snapshot.val();
          const designsList: Design[] = data ? Object.keys(data).map(key => ({
              id: key,
              ...data[key],
          })) : [];
          setDesigns(designsList);
          setLoading(false);
      });

      return () => unsubscribe();
    }
  }, [user]); 

  const handleUpdateDesign = (designId: string) => {
      router.push(`/professional-dashboard/designs/edit/${designId}`);
  }

  const handleDeleteDesign = async () => {
    if (!designToDelete) return;
    const designRef = ref(db, `designs/${designToDelete.id}`);
    try {
        await remove(designRef);
        toast({
            title: "Design Deleted",
            description: `The design "${designToDelete.name}" has been removed.`,
        });
    } catch (error) {
        console.error("Error deleting design:", error);
        toast({
            variant: "destructive",
            title: "Deletion Failed",
            description: "Could not delete the design.",
        });
    } finally {
        setDesignToDelete(null);
    }
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to view your designs.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-8">
        <PageHeader
          title="My Designs"
          description="Manage your design products listed on the platform."
        >
            <Button asChild>
                <Link href="/professional-dashboard/designs/new">
                    <PlusCircle className="mr-2 h-4 w-4" /> Add New Design
                </Link>
            </Button>
        </PageHeader>
        <Card>
            <CardContent className="p-0">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Image</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {loading ? (
                            Array.from({length: 3}).map((_, i) => (
                                <TableRow key={i}>
                                    <TableCell><Skeleton className="h-16 w-24 rounded-md" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                    <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                                </TableRow>
                            ))
                        ) : designs.length === 0 ? (
                           <TableRow>
                                <TableCell colSpan={5} className="h-48 text-center">
                                    <div className="flex flex-col items-center gap-4">
                                        <h3 className="font-semibold text-lg">No designs found.</h3>
                                        <p className="text-muted-foreground">Click the button to add your first design.</p>
                                        <Button asChild>
                                           <Link href="/professional-dashboard/designs/new">
                                                <PlusCircle className="mr-2 h-4 w-4" /> Add New Design
                                            </Link>
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ) : (
                            designs.map(design => (
                                <TableRow key={design.id}>
                                    <TableCell>
                                        <Image src={design.image || 'https://picsum.photos/120/80'} alt={design.name} width={96} height={64} className="rounded-md object-cover" />
                                    </TableCell>
                                    <TableCell className="font-medium">{design.name}</TableCell>
                                    <TableCell><Badge variant="secondary">{design.category}</Badge></TableCell>
                                    <TableCell>
                                        {isDubai ? `AED ${design.price?.toLocaleString()}` : <><IndianRupee className="inline h-3.5 w-3.5 -mt-1"/> {design.price?.toLocaleString('en-IN')}</>}
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon">
                                                    <MoreVertical className="h-4 w-4" />
                                                    <span className="sr-only">More Actions</span>
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuItem onClick={() => handleUpdateDesign(design.id)}>
                                                    <Edit className="mr-2 h-4 w-4" />
                                                    Edit Design
                                                </DropdownMenuItem>
                                                <DropdownMenuSeparator />
                                                <DropdownMenuItem 
                                                    className="text-red-600 focus:text-red-600 focus:bg-red-50"
                                                    onClick={() => setDesignToDelete(design)}
                                                >
                                                    <Trash2 className="mr-2 h-4 w-4" />
                                                    Delete Design
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
      </div>
      <AlertDialog open={!!designToDelete} onOpenChange={(open) => !open && setDesignToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the design
              "<span className="font-bold">{designToDelete?.name}</span>" from the database.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteDesign} className="bg-destructive hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
