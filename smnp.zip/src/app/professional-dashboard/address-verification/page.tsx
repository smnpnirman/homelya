
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Send, ShieldCheck, Home, Mail, CheckCircle, Clock } from 'lucide-react';
import { useState, useEffect } from 'react';
import { ref, push, set, serverTimestamp, get, query, orderByChild, equalTo, update, onValue } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import PageHeader from '@/components/page-header';
import { useAuth } from '@/hooks/use-auth';
import Link from 'next/link';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';

interface VerificationRequest {
    id: string;
    address: string;
    status: 'pending' | 'approved' | 'code_sent' | 'verified' | 'rejected' | 'agent_assigned';
    verificationMethod: 'postal_code' | 'agent';
    timestamp: number;
    verificationCode?: string;
}

const verificationFormSchema = z.object({
  address: z.string().min(20, { message: 'Full address must be at least 20 characters.' }),
  verificationMethod: z.enum(['postal_code', 'agent'], {
    required_error: "You need to select a verification method.",
  }),
});

type VerificationFormValues = z.infer<typeof verificationFormSchema>;

const codeVerificationSchema = z.object({
  code: z.string().min(4, "The code must be valid."),
});

type CodeVerificationValues = z.infer<typeof codeVerificationSchema>;

export default function AddressVerificationPage() {
    const { user } = useAuth();
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);
    const [verifyingCode, setVerifyingCode] = useState(false);
    const [request, setRequest] = useState<VerificationRequest | null>(null);
    const [checkingStatus, setCheckingStatus] = useState(true);

    const form = useForm<VerificationFormValues>({
        resolver: zodResolver(verificationFormSchema),
    });

    const codeForm = useForm<CodeVerificationValues>({
        resolver: zodResolver(codeVerificationSchema),
        defaultValues: {
            code: '',
        },
    });

    useEffect(() => {
        if (user?.uid) {
            setCheckingStatus(true);
            const q = query(ref(db, 'address-verifications'), orderByChild('userId'), equalTo(user.uid));
            const unsubscribe = onValue(q, (snapshot) => {
                if (snapshot.exists()) {
                    const data = snapshot.val();
                    const id = Object.keys(data)[0];
                    setRequest({ id, ...data[id] });
                } else {
                    setRequest(null);
                }
                setCheckingStatus(false);
            }, (error) => {
                console.error(error);
                setCheckingStatus(false);
            });
            return () => unsubscribe();
        } else {
            setCheckingStatus(false);
        }
    }, [user?.uid]);

    const onSubmit = async (data: VerificationFormValues) => {
        if (!user) return;
        setLoading(true);
        try {
            const verificationRef = ref(db, 'address-verifications');
            const newRequestRef = push(verificationRef);
            const newRequest = {
                ...data,
                userId: user.uid,
                userName: user.displayName,
                status: 'pending',
                timestamp: serverTimestamp(),
            };
            await set(newRequestRef, newRequest);
            setRequest({ id: newRequestRef.key!, ...newRequest, timestamp: Date.now() });
            toast({ title: 'Request Submitted!', description: 'Your address verification request has been sent for approval.' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Submission Failed' });
        } finally {
            setLoading(false);
        }
    }
    
    const onCodeSubmit = async (data: CodeVerificationValues) => {
        if (!user || !request) return;
        setVerifyingCode(true);
        try {
            const reqRef = ref(db, `address-verifications/${request.id}`);
            const snapshot = await get(reqRef);
            if (snapshot.exists() && snapshot.val().verificationCode === data.code) {
                await update(reqRef, { status: 'verified' });
                await update(ref(db, `users/${user.uid}`), { addressVerified: true });
                setRequest(prev => prev ? { ...prev, status: 'verified' } : null);
                toast({ title: 'Address Verified!', description: 'Your address has been successfully verified.' });
            } else {
                throw new Error("The entered code is incorrect. Please try again.");
            }
        } catch(error: any) {
             toast({ variant: 'destructive', title: 'Verification Failed', description: error.message });
        } finally {
            setVerifyingCode(false);
        }
    }

    if (checkingStatus) {
        return <div className="flex items-center justify-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
    }

    if (!user) {
        return (
            <div className="text-center py-12">
                <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                    <CardDescription>You must be logged in to verify your address.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                    <Link href="/login">Login</Link>
                    </Button>
                </CardContent>
                </Card>
            </div>
        );
    }
    
    if (request) {
        return (
            <div className="space-y-8 max-w-2xl mx-auto">
                <PageHeader title="Address Verification Status" />
                <Card>
                    <CardHeader>
                        <CardTitle>Your request is <span className="capitalize">{request.status.replace('_', ' ')}</span></CardTitle>
                        <CardDescription>Requested on {new Date(request.timestamp).toLocaleDateString()}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {request.status === 'pending' && <Alert><Clock className="h-4 w-4" /><AlertTitle>Pending Approval</AlertTitle><AlertDescription>Your request is awaiting approval from our admin team. This can take up to 48 hours.</AlertDescription></Alert>}
                        
                        {request.status === 'code_sent' && (
                            <Alert variant="default" className="bg-blue-50 border-blue-200 text-blue-800">
                                <Mail className="h-4 w-4 text-blue-600"/>
                                <AlertTitle className="text-blue-900">Verification Code Sent</AlertTitle>
                                <AlertDescription>
                                    We have sent a verification code to your address via post. Please enter it below once you receive it.
                                </AlertDescription>
                            </Alert>
                        )}

                        {request.status === 'agent_assigned' && <Alert variant="default" className="bg-blue-50 border-blue-200 text-blue-800"><Home className="h-4 w-4 text-blue-600"/><AlertTitle className="text-blue-900">Agent Assigned</AlertTitle><AlertDescription>An agent has been assigned to verify your address. They will contact you shortly to schedule a visit.</AlertDescription></Alert>}
                        {request.status === 'verified' && <Alert variant="default" className="bg-green-50 border-green-200 text-green-800"><CheckCircle className="h-4 w-4 text-green-600" /><AlertTitle className="text-green-900">Address Verified!</AlertTitle><AlertDescription>Your address has been successfully verified. Thank you.</AlertDescription></Alert>}
                        {request.status === 'rejected' && <Alert variant="destructive"><AlertTitle>Request Rejected</AlertTitle><AlertDescription>Your verification request was rejected. Please contact support for more information.</AlertDescription></Alert>}
                    </CardContent>
                </Card>

                {request.status === 'code_sent' && (
                     <Card>
                        <Form {...codeForm}>
                            <form onSubmit={codeForm.handleSubmit(onCodeSubmit)}>
                                <CardHeader>
                                    <CardTitle>Enter Verification Code</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <FormField
                                        control={codeForm.control}
                                        name="code"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Verification Code</FormLabel>
                                                <FormControl>
                                                    <Input placeholder="e.g., SMNP123456" {...field} />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </CardContent>
                                <CardFooter>
                                    <Button type="submit" disabled={verifyingCode}>
                                        {verifyingCode ? <Loader2 className="mr-2 animate-spin"/> : <ShieldCheck className="mr-2"/>}
                                        Verify Code
                                    </Button>
                                </CardFooter>
                            </form>
                        </Form>
                    </Card>
                )}
            </div>
        )
    }

    return (
        <div className="space-y-8 max-w-2xl mx-auto">
        <PageHeader 
            title="Address Verification"
            description="Verify your address to increase trust and unlock features like VR Kit orders."
        />
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
                <Card>
                    <CardHeader>
                        <CardTitle>Submit Your Address for Verification</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <FormField
                            control={form.control}
                            name="address"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Full Postal Address</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            placeholder="Enter your complete address including house number, street, city, state, and pincode..."
                                            rows={4}
                                            {...field}
                                        />
                                    </FormControl>
                                    <FormDescription>This address will be used to send your verification code.</FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="verificationMethod"
                            render={({ field }) => (
                                <FormItem className="space-y-3">
                                <FormLabel>Choose Verification Method</FormLabel>
                                <FormControl>
                                    <RadioGroup
                                        onValueChange={field.onChange}
                                        defaultValue={field.value}
                                        className="flex flex-col space-y-1"
                                    >
                                        <FormItem className="flex items-center space-x-3 space-y-0">
                                            <FormControl>
                                            <RadioGroupItem value="postal_code" />
                                            </FormControl>
                                            <FormLabel className="font-normal flex items-center gap-2">
                                                <Mail className="h-4 w-4 text-muted-foreground"/> Postal Code (Recommended)
                                            </FormLabel>
                                        </FormItem>
                                        <FormItem className="flex items-center space-x-3 space-y-0">
                                            <FormControl>
                                            <RadioGroupItem value="agent" />
                                            </FormControl>
                                            <FormLabel className="font-normal flex items-center gap-2">
                                                <Home className="h-4 w-4 text-muted-foreground" /> Agent Verification
                                            </FormLabel>
                                        </FormItem>
                                    </RadioGroup>
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </CardContent>
                    <CardFooter>
                        <Button type="submit" size="lg" disabled={loading}>
                            {loading ? <Loader2 className="mr-2 animate-spin" /> : <Send className="mr-2" />}
                            Submit for Verification
                        </Button>
                    </CardFooter>
                </Card>
            </form>
        </Form>
        </div>
    );
}
