
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CalendarIcon, ExternalLink, Loader2, PlusCircle, Save } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ref, push, set, get, update, serverTimestamp } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';
import Link from 'next/link';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';

const eventFormSchema = z.object({
  name: z.string().min(5, 'Event title must be at least 5 characters.'),
  description: z.string().min(20, 'Description must be at least 20 characters.'),
  eventType: z.enum(['offline', 'online'], { required_error: "You must select an event type."}),
  eventDate: z.date({ required_error: "Please select a date for the event."}),
  locationOrUrl: z.string().min(5, 'Location or URL is required.'),
  ticketPrice: z.coerce.number().min(0, 'Price cannot be negative.'),
  totalTickets: z.coerce.number().min(1, 'Total tickets must be at least 1.'),
  image: z.string().url('Please enter a valid image URL.').optional().or(z.literal('')),
});

type EventFormValues = z.infer<typeof eventFormSchema>;

type AddEventFormProps = {
  professionalId: string;
  professionalName: string;
  eventId?: string; // For editing
}

export default function AddEventForm({ professionalId, professionalName, eventId }: AddEventFormProps) {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(!!eventId);

  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      name: '',
      description: '',
      eventType: 'offline',
      locationOrUrl: '',
      ticketPrice: 0,
      totalTickets: 50,
      image: '',
    },
  });

  const watchImage = form.watch('image');
  const watchEventType = form.watch('eventType');

  useEffect(() => {
    if (eventId) {
      const fetchEventData = async () => {
        setDataLoading(true);
        try {
          const eventRef = ref(db, `events/${eventId}`);
          const snapshot = await get(eventRef);
          if (snapshot.exists()) {
            const data = snapshot.val();
            form.reset({ ...data, eventDate: new Date(data.eventDate) });
          } else {
             toast({ variant: 'destructive', title: 'Error', description: 'Event not found.' });
          }
        } catch (error) {
          console.error('Failed to fetch event data:', error);
          toast({ variant: 'destructive', title: 'Error', description: 'Failed to load event data.' });
        } finally {
          setDataLoading(false);
        }
      };
      fetchEventData();
    }
  }, [eventId, form, toast]);


  const onSubmit = async (data: EventFormValues) => {
    setLoading(true);
    const appEventData = {
        ...data,
        eventDate: format(data.eventDate, 'yyyy-MM-dd'),
        professionalId,
        professionalName,
        ticketsBooked: 0,
        status: 'pending',
        createdAt: serverTimestamp(),
        image: data.image || `https://picsum.photos/seed/${eventId || 'event'}/600/400`,
    };

    try {
      if (eventId) { // Editing existing event
        const eventRef = ref(db, `events/${eventId}`);
        await update(eventRef, appEventData);
        toast({
          title: 'Event Updated!',
          description: 'The event has been updated successfully and is pending review.',
        });
      } else { // Adding new event
        const eventsRef = ref(db, 'events');
        const newEventRef = push(eventsRef);
        await set(newEventRef, appEventData);

        toast({
          title: 'Event Submitted!',
          description: 'Your new event has been submitted for approval.',
        });
      }
      router.push('/professional-dashboard/events');
    } catch (error) {
      console.error('Failed to save event:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'An error occurred while saving the event.',
      });
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
      return (
        <Card>
            <CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader>
            <CardContent className="space-y-6">
                <Skeleton className="h-32 w-full" />
                <div className="grid md:grid-cols-2 gap-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                </div>
                 <div className="grid md:grid-cols-2 gap-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                </div>
            </CardContent>
            <CardFooter><Skeleton className="h-11 w-36" /></CardFooter>
        </Card>
      );
  }

  return (
    <Card>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
            <CardTitle className="font-headline text-xl">Event Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Event Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Vastu Shastra for Modern Homes" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe your event, what attendees will learn, and who should attend..."
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
                control={form.control}
                name="eventType"
                render={({ field }) => (
                    <FormItem className="space-y-3">
                    <FormLabel>Event Type</FormLabel>
                    <FormControl>
                        <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex items-center space-x-4"
                        >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl><RadioGroupItem value="offline" /></FormControl>
                                <FormLabel className="font-normal">Offline</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl><RadioGroupItem value="online" /></FormControl>
                                <FormLabel className="font-normal">Online</FormLabel>
                            </FormItem>
                        </RadioGroup>
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
            />
            <div className="grid md:grid-cols-2 gap-6">
                 <FormField
                    control={form.control}
                    name="eventDate"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                        <FormLabel>Event Date</FormLabel>
                        <Popover>
                            <PopoverTrigger asChild>
                            <FormControl>
                                <Button
                                variant={"outline"}
                                className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}
                                >
                                {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                            </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) => date < new Date(new Date().setDate(new Date().getDate() -1))}
                                initialFocus
                            />
                            </PopoverContent>
                        </Popover>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="locationOrUrl"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>{watchEventType === 'offline' ? 'Venue Location' : 'Event URL'}</FormLabel>
                        <FormControl>
                            <Input placeholder={watchEventType === 'offline' ? "e.g., Town Hall, Ranchi" : "e.g., https://zoom.us/..."} {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
             <div className="grid md:grid-cols-2 gap-6">
                 <FormField
                    control={form.control}
                    name="ticketPrice"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Ticket Price (INR)</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="0 for free events" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="totalTickets"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Total Tickets Available</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="e.g., 100" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
            <FormField
              control={form.control}
              name="image"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Event Image URL</FormLabel>
                  <div className="flex gap-2">
                    <FormControl>
                      <Input placeholder="https://example.com/image.png" {...field} />
                    </FormControl>
                    {watchImage && (
                      <Button asChild variant="ghost" size="icon">
                        <Link href={watchImage} target="_blank">
                          <ExternalLink className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}
                  </div>
                  {watchImage && (
                    <div className="mt-2">
                        <Image src={watchImage} alt="Image preview" width={200} height={150} className="rounded-md object-cover" />
                    </div>
                  )}
                  <FormDescription>Leave blank for a placeholder. Use a link from a site like unsplash.com or postimg.cc.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : eventId ? <Save className="mr-2 h-5 w-5" /> : <PlusCircle className="mr-2 h-5 w-5" />}
              {eventId ? 'Save Changes' : 'Submit for Approval'}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
