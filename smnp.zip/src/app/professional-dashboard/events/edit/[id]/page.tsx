'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import AddEventForm from "@/app/professional-dashboard/events/new/add-event-form";
import { useParams } from "next/navigation";

export default function EditEventPage() {
  const { user } = useAuth();
  const params = useParams();
  const eventId = params.id as string;

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to edit an event.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/professional-auth/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Edit Event"
        description="Update the details for your event below."
      />
      <AddEventForm 
        professionalId={user.uid} 
        professionalName={user.displayName || 'N/A'}
        eventId={eventId}
      />
    </div>
  );
}
