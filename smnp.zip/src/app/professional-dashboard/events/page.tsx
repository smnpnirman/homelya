
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, query, orderByChild, equalTo } from "firebase/database";
import type { AppEvent, EventStatus } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, CheckCircle, Clock, XCircle, CalendarDays, Edit, Users, IndianRupee } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useRouter } from "next/navigation";

function eventStatusToJsx(status: EventStatus) {
    switch(status) {
        case 'pending':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><Clock className="mr-1.5" />Pending Approval</Badge>;
        case 'approved':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="mr-1.5" />Approved</Badge>;
        case 'rejected':
            return <Badge variant="destructive"><XCircle className="mr-1.5" />Rejected</Badge>;
        case 'completed':
            return <Badge variant="secondary">Completed</Badge>;
        case 'cancelled':
            return <Badge variant="destructive">Cancelled</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function MyEventsPage() {
  const { user, userData } = useAuth();
  const router = useRouter();
  const [events, setEvents] = useState<AppEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const isDubai = userData?.country === 'dubai';

  useEffect(() => {
    if (user) {
      setLoading(true);
      const eventsQuery = query(ref(db, 'events'), orderByChild('professionalId'), equalTo(user.uid));
      const unsubscribe = onValue(eventsQuery, (snapshot) => {
        const data = snapshot.val();
        const eventsList: AppEvent[] = data ? Object.keys(data).map(key => ({
            id: key,
            ...data[key],
        })).sort((a, b) => b.createdAt - a.createdAt) : [];
        setEvents(eventsList);
        setLoading(false);
      });
      return () => unsubscribe();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to manage your events.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const handleEditEvent = (eventId: string) => {
      router.push(`/professional-dashboard/events/edit/${eventId}`);
  }

  const handleViewBookings = (eventId: string) => {
    router.push(`/professional-dashboard/events/${eventId}/bookings`);
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="My Events"
        description="Manage your workshops, webinars, and other events."
      >
        <Button asChild>
            <Link href="/professional-dashboard/events/new">
                <PlusCircle className="mr-2 h-4 w-4" /> Create New Event
            </Link>
        </Button>
      </PageHeader>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Event Title</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Bookings</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                    <TableCell className="text-right"><Skeleton className="h-8 w-40 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : events.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-48 text-center">
                    <div className="flex flex-col items-center gap-4">
                        <CalendarDays className="h-12 w-12 text-muted-foreground" />
                        <h3 className="font-semibold text-lg">No events created yet.</h3>
                        <p className="text-muted-foreground">Click the button below to create your first event!</p>
                        <Button asChild>
                           <Link href="/professional-dashboard/events/new">
                                <PlusCircle className="mr-2 h-4 w-4" /> Create New Event
                            </Link>
                        </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                events.map(appEvent => (
                  <TableRow key={appEvent.id}>
                    <TableCell className="font-medium">{appEvent.name}</TableCell>
                    <TableCell>{format(new Date(appEvent.eventDate), 'PPP')}</TableCell>
                    <TableCell><Users className="inline h-4 w-4 mr-1 -mt-1"/>{appEvent.ticketsBooked || 0} / {appEvent.totalTickets}</TableCell>
                    <TableCell className="flex items-center">
                        {appEvent.ticketPrice > 0 ? (
                            isDubai ? `AED ${appEvent.ticketPrice.toLocaleString()}` : <><IndianRupee className="inline h-3.5 w-3.5 mr-0.5 -mt-1"/>{appEvent.ticketPrice.toLocaleString('en-IN')}</>
                        ) : 'Free'}
                    </TableCell>
                    <TableCell>{eventStatusToJsx(appEvent.status)}</TableCell>
                    <TableCell className="text-right space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleViewBookings(appEvent.id)}>
                            <Users className="mr-2 h-3.5 w-3.5" /> Bookings
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleEditEvent(appEvent.id)}>
                            <Edit className="mr-2 h-3.5 w-3.5" />
                        </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
