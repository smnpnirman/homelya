'use client';

import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue, query, orderByChild, equalTo } from 'firebase/database';
import type { AppEvent, EventBooking } from '@/lib/types';
import PageHeader from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { Users, Mail, Phone, MessageSquare } from 'lucide-react';

export default function EventBookingsPage() {
    const { user } = useAuth();
    const params = useParams();
    const router = useRouter();
    const eventId = params.id as string;

    const [appEvent, setAppEvent] = useState<AppEvent | null>(null);
    const [bookings, setBookings] = useState<EventBooking[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!user || !eventId) {
            setLoading(false);
            return;
        };

        const eventRef = ref(db, `events/${eventId}`);
        onValue(eventRef, (snapshot) => {
            if (snapshot.exists() && snapshot.val().professionalId === user.uid) {
                setAppEvent({ id: eventId, ...snapshot.val() });

                const bookingsQuery = query(ref(db, 'bookings'), orderByChild('eventId'), equalTo(eventId));
                onValue(bookingsQuery, (bookingSnapshot) => {
                    if (bookingSnapshot.exists()) {
                        const data = bookingSnapshot.val();
                        const bookingsList: EventBooking[] = Object.keys(data).map(key => ({
                            id: key,
                            ...data[key]
                        })).sort((a,b) => b.timestamp - a.timestamp);
                        setBookings(bookingsList);
                    } else {
                        setBookings([]);
                    }
                    setLoading(false);
                });

            } else {
                // Event not found or user is not the owner
                setLoading(false);
                setAppEvent(null);
            }
        });

    }, [user, eventId]);

    const handleSendReminder = (booking: EventBooking) => {
        if (!appEvent) return;

        const subject = `Reminder: Your ticket for ${appEvent.name}`;
        const body = `
Hello ${booking.userName},

This is a friendly reminder about the upcoming event you registered for:

Event: ${appEvent.name}
Date: ${format(new Date(appEvent.eventDate), 'PPP')}
Location/URL: ${appEvent.locationOrUrl}

We look forward to seeing you there!

Regards,
${appEvent.professionalName}
        `.trim();

        const mailtoLink = `mailto:${booking.userEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.location.href = mailtoLink;
    }

    const handleWhatsAppReminder = (booking: EventBooking) => {
        if (!appEvent || !booking.userPhone) return;

        const message = `Hello ${booking.userName},\n\nThis is a friendly reminder about the upcoming event you registered for:\n\n*Event:* ${appEvent.name}\n*Date:* ${format(new Date(appEvent.eventDate), 'PPP')}\n*Location/URL:* ${appEvent.locationOrUrl}\n\nWe look forward to seeing you there!\n\nRegards,\n${appEvent.professionalName}`.trim();

        const phoneNumber = booking.userPhone.replace(/\D/g, ''); // Remove non-digit characters
        const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
    }

    if (loading) {
        return (
            <div className="space-y-8">
                <PageHeader title="Loading Bookings..." />
                <Card>
                    <CardContent className="p-4">
                        <Skeleton className="h-64 w-full" />
                    </CardContent>
                </Card>
            </div>
        )
    }

    if (!user || !appEvent) {
         return (
            <div className="text-center py-12">
                <Card className="max-w-md mx-auto">
                    <CardHeader>
                        <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                        <CardDescription>You do not have permission to view this page or the event does not exist.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button asChild>
                            <Link href="/professional-dashboard/events">Back to My Events</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }
    
    return (
        <div className="space-y-8">
            <PageHeader
                title={`Bookings for "${appEvent.name}"`}
                description={`A list of all users who have registered for your event.`}
            />
            <Card>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Attendee Name</TableHead>
                                <TableHead>Email</TableHead>
                                <TableHead>Phone</TableHead>
                                <TableHead>Booked On</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {bookings.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={5} className="h-48 text-center">
                                        <div className="flex flex-col items-center gap-4">
                                            <Users className="h-12 w-12 text-muted-foreground" />
                                            <h3 className="font-semibold text-lg">No bookings yet.</h3>
                                            <p className="text-muted-foreground">When users book a ticket, their details will appear here.</p>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ) : (
                                bookings.map(booking => (
                                    <TableRow key={booking.id}>
                                        <TableCell className="font-medium">{booking.userName}</TableCell>
                                        <TableCell>
                                            <a href={`mailto:${booking.userEmail}`} className="flex items-center gap-2 hover:text-primary transition-colors">
                                                <Mail className="h-4 w-4"/> {booking.userEmail}
                                            </a>
                                        </TableCell>
                                        <TableCell>
                                             {booking.userPhone ? (
                                                <a href={`tel:${booking.userPhone}`} className="flex items-center gap-2 hover:text-primary transition-colors">
                                                    <Phone className="h-4 w-4"/> {booking.userPhone}
                                                </a>
                                             ) : (
                                                <span className="text-muted-foreground">N/A</span>
                                             )}
                                        </TableCell>
                                        <TableCell>{format(new Date(booking.timestamp), 'PPP p')}</TableCell>
                                        <TableCell className="text-right space-x-2">
                                            <Button variant="outline" size="sm" onClick={() => handleSendReminder(booking)}>
                                                <Mail className="mr-2 h-3.5 w-3.5"/>
                                                Email
                                            </Button>
                                            <Button variant="outline" size="sm" onClick={() => handleWhatsAppReminder(booking)} disabled={!booking.userPhone}>
                                                <MessageSquare className="mr-2 h-3.5 w-3.5"/>
                                                WhatsApp
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    )

}
