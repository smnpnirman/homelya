
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, query, orderByChild } from "firebase/database";
import { Skeleton } from "@/components/ui/skeleton";
import { Bell, BellOff } from "lucide-react";
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";

interface Notification {
    id: string;
    title: string;
    message: string;
    timestamp: number;
    read: boolean;
}

export default function NotificationsPage() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      setLoading(true);
      const notificationsRef = query(ref(db, `notifications/${user.uid}`), orderByChild('timestamp'));
      const unsubscribe = onValue(notificationsRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const notificationsList: Notification[] = Object.keys(data).map(key => ({
            id: key,
            ...data[key]
          })).sort((a, b) => b.timestamp - a.timestamp); // Sort descending
          setNotifications(notificationsList);
        } else {
            setNotifications([]);
        }
        setLoading(false);
      });
      return () => unsubscribe();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to view your notifications.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/professional-auth/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
      return (
        <div className="space-y-8">
            <PageHeader
                title="Notifications"
                description="Important updates and messages from the Homelya admin team."
            />
            <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
            </div>
        </div>
      )
  }

  return (
    <div className="space-y-8">
       <PageHeader
        title="Notifications"
        description="Important updates and messages from the Homelya admin team."
      />

      {notifications.length === 0 ? (
        <Card>
            <CardContent className="p-8 text-center">
                <BellOff className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-headline text-xl">No Notifications Yet</h3>
                <p className="text-muted-foreground">You have no new messages.</p>
            </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
            {notifications.map((notification) => (
            <Card key={notification.id} className="flex items-start gap-4 p-4">
                <div className="bg-primary/10 text-primary p-3 rounded-full mt-1">
                    <Bell />
                </div>
                <div className="flex-1">
                    <div className="flex justify-between items-center">
                        <h3 className="font-semibold">{notification.title}</h3>
                        <p className="text-xs text-muted-foreground">{format(new Date(notification.timestamp), 'PPP p')}</p>
                    </div>
                    <p className="text-sm text-muted-foreground">{notification.message}</p>
                </div>
            </Card>
            ))}
        </div>
      )}
    </div>
  );
}
