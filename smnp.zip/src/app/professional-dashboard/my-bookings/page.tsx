

'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, query, orderByChild, equalTo, get, update, serverTimestamp, push } from "firebase/database";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { CalendarSearch, CheckCircle, Loader2, Mail, Phone, User as UserIcon, ShieldAlert, FileText, Ticket as TicketIcon, Send } from "lucide-react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import type { VerificationStatus, EventBooking } from "@/lib/types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SendNotificationDialog from "@/components/send-notification-dialog";

interface Consultation {
    id: string;
    userId: string;
    userName: string;
    userEmail: string;
    userPhone?: string;
    date: string;
    details: string;
    status: 'Pending' | 'Payment Pending' | 'Scheduled' | 'Completed' | 'Cancelled';
    timestamp: number;
    transactionId?: string;
    professionalNeeded: 'designer' | 'constructor' | 'supplier';
}

function consultationStatusToJsx(status: Consultation['status']) {
    switch(status) {
        case 'Pending':
            return <Badge variant="outline">Pending</Badge>;
        case 'Payment Pending':
            return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700">Payment Pending</Badge>;
        case 'Scheduled':
            return <Badge variant="default">Scheduled</Badge>;
        case 'Completed':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700">Completed</Badge>;
        case 'Cancelled':
            return <Badge variant="destructive">Cancelled</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

function UserConsultationHistory() {
    const { user } = useAuth();
    const router = useRouter();
    const [consultations, setConsultations] = useState<Consultation[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user) {
            setLoading(true);
            const consultationsQuery = query(ref(db, 'consultations'), orderByChild('userId'), equalTo(user.uid));
            const unsubscribe = onValue(consultationsQuery, (snapshot) => {
                const data = snapshot.val();
                if (data) {
                    const list: Consultation[] = Object.keys(data).map(key => ({
                        id: key,
                        ...data[key]
                    })).sort((a, b) => b.timestamp - a.timestamp);
                    setConsultations(list);
                } else {
                    setConsultations([]);
                }
                setLoading(false);
            });
            return () => unsubscribe();
        }
    }, [user]);

    const handleViewToken = (id: string) => {
        router.push(`/consultation-token/${id}`);
    }

     if (loading) {
        return (
            <Card>
                <CardContent className="p-4">
                    <Skeleton className="h-64 w-full" />
                </CardContent>
            </Card>
        )
    }

    if (consultations.length === 0) {
         return (
            <Card>
                <CardContent className="p-8 text-center">
                    <CalendarSearch className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="font-headline text-xl">No Consultations Found</h3>
                    <p className="text-muted-foreground">You haven't booked any consultations yet.</p>
                    <Button asChild className="mt-4">
                        <Link href="/free-consultation">Book a Free Consultation</Link>
                    </Button>
                </CardContent>
            </Card>
         )
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>My Booked Consultations</CardTitle>
                <CardDescription>A history of all the consultations you have booked.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Requested Date</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Booked On</TableHead>
                            <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {consultations.map(c => (
                            <TableRow key={c.id}>
                                <TableCell className="font-medium">{format(new Date(c.date), 'PPP')}</TableCell>
                                <TableCell>{consultationStatusToJsx(c.status)}</TableCell>
                                <TableCell>{format(new Date(c.timestamp), 'PPP p')}</TableCell>
                                <TableCell className="text-right">
                                    <Button variant="outline" size="sm" onClick={() => handleViewToken(c.id)}>
                                        View Token
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}

function UserEventBookingsHistory() {
    const { user } = useAuth();
    const router = useRouter();
    const [bookings, setBookings] = useState<EventBooking[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user) {
            setLoading(true);
            const bookingsQuery = query(ref(db, 'bookings'), orderByChild('userId'), equalTo(user.uid));
            const unsubscribe = onValue(bookingsQuery, (snapshot) => {
                const data = snapshot.val();
                if (data) {
                    const list: EventBooking[] = Object.keys(data).map(key => ({
                        id: key,
                        ...data[key]
                    })).sort((a, b) => b.timestamp - a.timestamp);
                    setBookings(list);
                } else {
                    setBookings([]);
                }
                setLoading(false);
            });
            return () => unsubscribe();
        }
    }, [user]);

    if (loading) {
        return <Skeleton className="h-64 w-full" />
    }

    if (bookings.length === 0) {
        return (
            <Card>
                <CardContent className="p-8 text-center">
                    <CalendarSearch className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="font-headline text-xl">No Event Bookings Found</h3>
                    <p className="text-muted-foreground">You haven't booked any events yet.</p>
                    <Button asChild className="mt-4">
                        <Link href="/events">Browse Events</Link>
                    </Button>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>My Event Bookings</CardTitle>
                <CardDescription>A history of all the events you have booked.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Event</TableHead>
                            <TableHead>Booked On</TableHead>
                            <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {bookings.map(booking => (
                            <TableRow key={booking.id}>
                                <TableCell className="font-medium">{booking.eventTitle}</TableCell>
                                <TableCell>{format(new Date(booking.timestamp), 'PPP p')}</TableCell>
                                <TableCell className="text-right">
                                    <Button variant="outline" size="sm" onClick={() => router.push(`/event-ticket/${booking.id}`)}>
                                        <TicketIcon className="mr-2 h-3.5 w-3.5"/> View Ticket
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}

function UserBookings() {
  return (
    <Tabs defaultValue="events" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="events">Event Bookings</TabsTrigger>
        <TabsTrigger value="consultations">Consultations</TabsTrigger>
      </TabsList>
      <TabsContent value="events" className="mt-4">
        <UserEventBookingsHistory />
      </TabsContent>
      <TabsContent value="consultations" className="mt-4">
        <UserConsultationHistory />
      </TabsContent>
    </Tabs>
  );
}


function ProfessionalConsultationView({ professionalRole, professionalId, professionalName, verificationStatus }: { professionalRole: 'designer' | 'constructor' | 'supplier', professionalId: string, professionalName: string, verificationStatus: VerificationStatus }) {
    const [consultations, setConsultations] = useState<Consultation[]>([]);
    const [loading, setLoading] = useState(true);
    const [token, setToken] = useState('');
    const [verifying, setVerifying] = useState(false);
    const { toast } = useToast();
    const [consultationToNotify, setConsultationToNotify] = useState<Consultation | null>(null);

    useEffect(() => {
        if (verificationStatus !== 'verified') {
            setLoading(false);
            return;
        }
        setLoading(true);
        const consultationsQuery = query(ref(db, 'consultations'), orderByChild('professionalNeeded'), equalTo(professionalRole));
        const unsubscribe = onValue(consultationsQuery, (snapshot) => {
            const data = snapshot.val();
            const list: Consultation[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key]
            })).filter(c => c.status === 'Pending') // Only show actionable consultations
              .sort((a, b) => b.timestamp - a.timestamp) : [];
            setConsultations(list);
            setLoading(false);
        });
        return () => unsubscribe();
    }, [professionalRole, verificationStatus]);

    const handleVerifyToken = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!token.trim()) {
            toast({ variant: 'destructive', title: 'Token ID required.' });
            return;
        }
        setVerifying(true);
        
        const shortId = token.startsWith('SMNP-') ? token.substring(5).toLowerCase() : token.toLowerCase();
        
        try {
            const allConsultationsSnapshot = await get(ref(db, 'consultations'));
            if (!allConsultationsSnapshot.exists()) throw new Error("No consultations found.");

            const allData = allConsultationsSnapshot.val();
            const fullId = Object.keys(allData).find(key => key.slice(-6).toLowerCase() === shortId);

            if (!fullId) {
                throw new Error("Invalid or non-existent token ID.");
            }

            const consultationRef = ref(db, `consultations/${fullId}`);
            await update(consultationRef, { 
                status: 'Completed',
                completedByUid: professionalId,
                completedByName: professionalName,
                completionTimestamp: serverTimestamp(),
            });

            toast({
                title: 'Consultation Completed!',
                description: `Token ${token} has been successfully verified and marked as complete.`,
            });
            setToken('');
        } catch (error: any) {
            toast({
                variant: 'destructive',
                title: 'Verification Failed',
                description: error.message || "An unknown error occurred.",
            });
        } finally {
            setVerifying(false);
        }
    };
    
    const handleSendReminder = async (title: string, message: string) => {
        if (!consultationToNotify) return false;

        const notificationData = {
            title,
            message,
            timestamp: serverTimestamp(),
            read: false,
        };

        try {
            const notificationsRef = ref(db, `notifications/${consultationToNotify.userId}`);
            await push(notificationsRef, notificationData);
            toast({
                title: "Reminder Sent!",
                description: `A reminder has been sent to ${consultationToNotify.userName}.`
            });
            return true;
        } catch(error) {
            console.error("Error sending reminder:", error);
            toast({
                variant: "destructive",
                title: "Failed to Send",
                description: "Could not send the reminder.",
            });
            return false;
        }
    };

    if (loading) {
        return <Skeleton className="h-96 w-full" />
    }
    
    if (verificationStatus !== 'verified') {
        return (
            <Card className="text-center">
                <CardHeader>
                    <div className="mx-auto bg-amber-100 text-amber-600 rounded-full h-16 w-16 flex items-center justify-center">
                        <ShieldAlert className="h-8 w-8" />
                    </div>
                </CardHeader>
                <CardContent>
                    <CardTitle className="font-headline text-xl text-amber-900">
                        Profile Verification Required
                    </CardTitle>
                    <CardDescription className="text-amber-800 mt-2">
                        Once your profile is verified, you will be able to see and manage consultation inquiries here.
                    </CardDescription>
                </CardContent>
                <CardFooter>
                    <Button asChild className="mx-auto" variant="outline">
                        <Link href="/professional-dashboard">Go to Dashboard</Link>
                    </Button>
                </CardFooter>
            </Card>
        )
    }

    return (
        <>
        <div className="grid lg:grid-cols-3 gap-8 items-start">
            <div className="lg:col-span-2">
                 <Card>
                    <CardHeader>
                        <CardTitle>New Consultation Requests</CardTitle>
                        <CardDescription>Review and manage new requests assigned to your professional category.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-0">
                         {consultations.length === 0 ? (
                            <div className="p-8 text-center">
                                <CalendarSearch className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                                <h3 className="font-headline text-xl">No Pending Consultations</h3>
                                <p className="text-muted-foreground">There are currently no new consultation requests for your category.</p>
                            </div>
                        ) : (
                        <Accordion type="single" collapsible className="w-full">
                            {consultations.map(c => (
                                <AccordionItem value={c.id} key={c.id}>
                                    <AccordionTrigger className="px-4 py-3 hover:bg-muted/50">
                                        <div className="flex justify-between items-center w-full">
                                            <div className="flex items-center gap-4 text-left">
                                                <UserIcon className="text-primary h-5 w-5"/>
                                                <div>
                                                    <p className="font-semibold">{c.userName}</p>
                                                    <p className="text-sm text-muted-foreground">Requested for {format(new Date(c.date), 'PPP')}</p>
                                                </div>
                                            </div>
                                            <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground pr-4">
                                                {consultationStatusToJsx(c.status)}
                                            </div>
                                        </div>
                                    </AccordionTrigger>
                                    <AccordionContent className="px-6 pb-4 bg-muted/20">
                                        <div className="space-y-4 pt-4">
                                            <div className="flex justify-between items-start">
                                                <h4 className="font-semibold text-base">Contact Details</h4>
                                                <Button variant="outline" size="sm" onClick={() => setConsultationToNotify(c)}>
                                                    <Send className="mr-2 h-4 w-4"/> Send Reminder
                                                </Button>
                                            </div>
                                            <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                                                <a href={`mailto:${c.userEmail}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Mail className="h-4 w-4"/> {c.userEmail}</a>
                                                {c.userPhone && <a href={`tel:${c.userPhone}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Phone className="h-4 w-4"/> {c.userPhone}</a>}
                                            </div>
                                            <h4 className="font-semibold text-base pt-2">User's Message</h4>
                                            <p className="text-muted-foreground text-sm whitespace-pre-wrap">{c.details}</p>
                                            {c.transactionId && 
                                                <div className="font-mono text-xs bg-background p-2 rounded">
                                                    <strong>Transaction ID:</strong> {c.transactionId}
                                                </div>
                                            }
                                        </div>
                                    </AccordionContent>
                                </AccordionItem>
                            ))}
                        </Accordion>
                        )}
                    </CardContent>
                </Card>
            </div>
            <div>
                <Card>
                    <form onSubmit={handleVerifyToken}>
                        <CardHeader>
                            <CardTitle>Complete a Consultation</CardTitle>
                            <CardDescription>Enter the user's consultation token ID to mark it as complete.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Label htmlFor="token-id">Consultation Token ID</Label>
                            <Input 
                                id="token-id" 
                                placeholder="SMNP-XXXXXX" 
                                value={token}
                                onChange={(e) => setToken(e.target.value.toUpperCase())}
                            />
                        </CardContent>
                        <CardFooter>
                            <Button type="submit" className="w-full" disabled={verifying}>
                                {verifying ? <Loader2 className="mr-2 animate-spin"/> : <CheckCircle className="mr-2" />}
                                Verify & Complete
                            </Button>
                        </CardFooter>
                    </form>
                </Card>
            </div>
        </div>
        <SendNotificationDialog
            isOpen={!!consultationToNotify}
            onClose={() => setConsultationToNotify(null)}
            onSend={handleSendReminder}
            professionalName={consultationToNotify?.userName || ''}
        />
        </>
    )
}

export default function MyBookingsPage() {
    const { user } = useAuth();
    const [userData, setUserData] = useState<{role: string, status: VerificationStatus} | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user) {
            const userRef = ref(db, 'users/' + user.uid);
            onValue(userRef, (snapshot) => {
                if (snapshot.exists()) {
                    setUserData(snapshot.val());
                } else {
                    setUserData({ role: 'user', status: 'in-progress'}); // Default for safety
                }
                setLoading(false);
            });
        } else {
            setLoading(false);
        }
    }, [user]);


    if (loading) {
        return (
            <div className="space-y-8">
                <PageHeader title="My Bookings" />
                <Skeleton className="h-96 w-full" />
            </div>
        )
    }
    
    if (!user) {
        return (
            <div className="text-center py-12">
                <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                    <CardDescription>You must be logged in to view your bookings.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                        <Link href="/login">Login</Link>
                    </Button>
                </CardContent>
                </Card>
            </div>
        );
    }
    
    const isProfessional = userData?.role === 'designer' || userData?.role === 'constructor' || userData?.role === 'supplier';

    return (
        <div className="space-y-8">
            <PageHeader
                title="My Bookings"
                description={isProfessional ? "Manage consultation requests from users." : "View your past and upcoming bookings."}
            />
            {isProfessional ? <ProfessionalConsultationView professionalRole={userData.role as any} professionalId={user.uid} professionalName={user.displayName || user.email || 'N/A'} verificationStatus={userData.status} /> : <UserBookings />}
        </div>
    )
}
