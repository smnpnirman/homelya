
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, onValue, query, orderByChild } from "firebase/database";
import { Skeleton } from "@/components/ui/skeleton";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { format } from 'date-fns';
import { Mail, MessageSquare, Phone, User, Info, Briefcase } from "lucide-react";
import type { Provider } from "@/lib/types";
import { Badge } from "@/components/ui/badge";

interface Inquiry {
    id: string;
    name: string;
    email: string;
    phone: string;
    message: string;
    timestamp: number;
    productName?: string;
    senderProfile?: Provider;
}

export default function InquiriesPage() {
  const { user } = useAuth();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      setLoading(true);
      const inquiriesRef = query(ref(db, `inquiries/${user.uid}`), orderByChild('timestamp'));
      
      const unsubscribe = onValue(inquiriesRef, (snapshot) => {
        if (!snapshot.exists()) {
            setInquiries([]);
            setLoading(false);
            return;
        }

        const inquiriesData = snapshot.val();
        const inquiriesList: Inquiry[] = Object.keys(inquiriesData).map(key => ({
            id: key,
            ...inquiriesData[key]
        })).sort((a, b) => b.timestamp - a.timestamp); // Sort descending
        
        // Fetch all users to cross-reference sender emails
        const usersRef = ref(db, 'users');
        onValue(usersRef, (usersSnapshot) => {
            const usersData = usersSnapshot.val();
            const usersByEmail: {[email: string]: Provider} = {};
            if (usersData) {
                for (const userId in usersData) {
                    const userData = usersData[userId];
                    if (userData.email) {
                        usersByEmail[userData.email] = { id: userId, ...userData };
                    }
                }
            }
            
            const enrichedInquiries = inquiriesList.map(inquiry => {
                if (inquiry.email && usersByEmail[inquiry.email]) {
                    return { ...inquiry, senderProfile: usersByEmail[inquiry.email] };
                }
                return inquiry;
            });
            
            setInquiries(enrichedInquiries);
            setLoading(false);
        }, { onlyOnce: true }); // We only need to fetch this once per inquiry load

      }, (error) => {
          console.error(error);
          setLoading(false);
      });
      
      return () => unsubscribe();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to view your inquiries.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/professional-auth/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
      return (
        <div className="space-y-8">
            <PageHeader
                title="My Inquiries"
                description="Here are the latest messages and leads from potential clients."
            />
            <div className="space-y-4">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
            </div>
        </div>
      )
  }

  return (
    <div className="space-y-8">
       <PageHeader
        title="My Inquiries"
        description="Here are the latest messages and leads from potential clients."
      />

      {inquiries.length === 0 ? (
        <Card>
            <CardContent className="p-8 text-center">
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-headline text-xl">No Inquiries Yet</h3>
                <p className="text-muted-foreground">When potential clients contact you, their messages will appear here.</p>
            </CardContent>
        </Card>
      ) : (
        <Card>
            <CardContent className="p-0">
                <Accordion type="single" collapsible className="w-full">
                    {inquiries.map((inquiry) => (
                        <AccordionItem value={inquiry.id} key={inquiry.id}>
                            <AccordionTrigger className="px-6 py-4 hover:bg-muted/50">
                                <div className="flex justify-between items-center w-full">
                                    <div className="flex items-center gap-4">
                                        <User className="text-primary"/>
                                        <div className="text-left">
                                            <p className="font-semibold">{inquiry.name}</p>
                                            <p className="text-sm text-muted-foreground">Received on {format(new Date(inquiry.timestamp), 'PPP')}</p>
                                             {inquiry.senderProfile && (
                                                <Badge variant="outline" className="mt-1">
                                                    <Briefcase className="mr-1.5 h-3 w-3"/>
                                                    <span className="capitalize">{inquiry.senderProfile.role}</span>
                                                </Badge>
                                            )}
                                        </div>
                                    </div>
                                    <div className="hidden md:block text-sm text-muted-foreground pr-4 truncate max-w-sm">
                                      {inquiry.productName ? `Inquired about: ${inquiry.productName}` : inquiry.message}
                                    </div>
                                </div>
                            </AccordionTrigger>
                            <AccordionContent className="px-6 pb-6 bg-muted/20">
                                <div className="space-y-4 pt-4">
                                    <h4 className="font-semibold text-base">Contact Details</h4>
                                    <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                                        <a href={`mailto:${inquiry.email}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Mail className="h-4 w-4"/> {inquiry.email}</a>
                                        <a href={`tel:${inquiry.phone}`} className="flex items-center gap-2 hover:text-primary transition-colors"><Phone className="h-4 w-4"/> {inquiry.phone}</a>
                                    </div>
                                     {inquiry.productName && (
                                        <div className="flex items-center gap-2 text-sm bg-primary/10 text-primary p-2 rounded-md">
                                            <Info className="h-4 w-4"/>
                                            <span>Inquired about the product: <strong>{inquiry.productName}</strong></span>
                                        </div>
                                    )}
                                    <h4 className="font-semibold text-base pt-2">Message</h4>
                                    <p className="text-muted-foreground text-sm whitespace-pre-wrap">{inquiry.message}</p>
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
            </CardContent>
        </Card>
      )}
    </div>
  );
}
