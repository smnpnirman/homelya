
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { useFollow } from "@/hooks/use-follow";
import { db } from "@/lib/firebase";
import { get, onValue, ref, query, orderByChild, limitToLast } from "firebase/database";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Rss, Users } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import type { Provider } from "@/lib/types";

interface Post {
  id: string;
  content: string;
  timestamp: number;
}

interface ProfessionalWithLatestPost extends Provider {
  latestPost?: Post;
}

export default function CommunityFeedPage() {
  const { user } = useAuth();
  const { following } = useFollow();
  const [followedProfessionals, setFollowedProfessionals] = useState<ProfessionalWithLatestPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (following.length === 0) {
      setLoading(false);
      setFollowedProfessionals([]);
      return;
    }

    setLoading(true);

    const fetchProfessionalsAndPosts = async () => {
      const professionalPromises = following.map(id => get(ref(db, `users/${id}`)));
      const snapshots = await Promise.all(professionalPromises);
      
      const professionalsData: ProfessionalWithLatestPost[] = snapshots.map((snapshot, index) => {
        if (snapshot.exists()) {
          const data = snapshot.val();
          return {
            id: following[index],
            name: data.companyName,
            specialty: data.specialty || data.category,
            image: data.image,
            role: data.role,
          } as ProfessionalWithLatestPost;
        }
        return null;
      }).filter((p): p is ProfessionalWithLatestPost => p !== null);

      const latestPostPromises = professionalsData.map(prof => 
        get(ref(db, `community-posts/${prof.id}`))
      );
      
      const postSnapshots = await Promise.all(latestPostPromises);

      postSnapshots.forEach((snapshot, index) => {
        if (snapshot.exists()) {
          const posts = snapshot.val();
          const postsList: Post[] = Object.keys(posts).map(key => ({ id: key, ...posts[key] }));
          if (postsList.length > 0) {
            // Sort on the client to find the latest post
            const latestPost = postsList.sort((a, b) => b.timestamp - a.timestamp)[0];
            professionalsData[index].latestPost = latestPost;
          }
        }
      });
      
      // Sort professionals by the timestamp of their latest post, descending
      professionalsData.sort((a, b) => (b.latestPost?.timestamp || 0) - (a.latestPost?.timestamp || 0));

      setFollowedProfessionals(professionalsData);
      setLoading(false);
    };

    fetchProfessionalsAndPosts();

  }, [following]);

  const getInitials = (name?: string) => {
    if (!name) return 'P';
    return name.substring(0, 2).toUpperCase();
  }

  if (loading) {
    return (
      <div className="space-y-8 max-w-3xl mx-auto">
        <PageHeader title="Community Feed" description="Updates from professionals you follow."/>
        <div className="space-y-6">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    )
  }
  
  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to view your community feed.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild><Link href="/login">Login</Link></Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (following.length === 0) {
     return (
        <div className="text-center col-span-full py-16 border bg-card rounded-lg flex flex-col items-center">
            <Users className="w-16 h-16 text-muted-foreground/50 mb-4" />
            <h3 className="font-headline text-2xl font-semibold">Your Community Feed is Empty</h3>
            <p className="text-muted-foreground max-w-md mx-auto mt-2">
              Follow professionals to see their updates and posts here.
            </p>
            <Button asChild className="mt-6">
                <Link href="/designers">Find Professionals to Follow</Link>
            </Button>
        </div>
      )
  }

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      <PageHeader
        title="Community Feed"
        description="A list of professionals you follow. Click to view their full feed."
      />
      {followedProfessionals.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed rounded-lg">
            <Rss className="mx-auto h-16 w-16 text-muted-foreground" />
            <h3 className="mt-4 text-xl font-semibold">No posts yet.</h3>
            <p className="mt-1 text-muted-foreground">The professionals you follow haven't posted any updates yet.</p>
          </div>
      ) : (
        <div className="space-y-6">
          {followedProfessionals.map(professional => {
            if (!professional) return null;
            return (
              <Card key={professional.id} className="hover:bg-muted/50 transition-colors">
                <Link href={`/community/${professional.id}`}>
                    <CardHeader className="flex flex-row items-start gap-4">
                        <Avatar className="h-12 w-12 border">
                            <AvatarImage src={professional.image} alt={professional.name} />
                            <AvatarFallback>{getInitials(professional.name)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                            <CardTitle className="font-headline text-lg">{professional.name}</CardTitle>
                            <CardDescription className="flex flex-wrap items-center gap-x-2 text-xs">
                                <span>{professional.specialty}</span>
                            </CardDescription>
                        </div>
                    </CardHeader>
                    {professional.latestPost && (
                        <CardContent className="border-t pt-4">
                            <p className="text-xs text-muted-foreground">
                                Latest Post • {formatDistanceToNow(new Date(professional.latestPost.timestamp), { addSuffix: true })}
                            </p>
                            <p className="text-muted-foreground whitespace-pre-wrap mt-1 line-clamp-2">{professional.latestPost.content}</p>
                        </CardContent>
                    )}
                </Link>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  );
}
