
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, useFieldArray } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ExternalLink, Loader2, PlusCircle, Save, Trash2, Video } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ref, push, set, get, update } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';
import Link from 'next/link';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DesignCategory } from '@/lib/types';

const designCategories: DesignCategory[] = ["Architectural Plan", "Interior Design", "Wall Art", "Furniture Design"];

const designFormSchema = z.object({
  name: z.string().min(5, 'Design name must be at least 5 characters.'),
  category: z.enum(designCategories, {
    required_error: 'Please select a category.',
  }),
  style: z.string().min(2, 'Style must be at least 2 characters.'),
  bedrooms: z.coerce.number().min(0).optional(),
  bathrooms: z.coerce.number().min(0).optional(),
  price: z.coerce.number().min(100, 'Price must be at least 100.'),
  description: z.string().min(20, 'Description must be at least 20 characters.'),
  image: z.string().url('Please enter a valid primary image URL.'),
  additionalImages: z.array(z.object({ value: z.string().url({message: "Please enter a valid URL."}) })),
  videoUrl: z.string().url("Please enter a valid YouTube or Instagram video URL.").optional().or(z.literal('')),
  designerId: z.string().optional(),
});

type DesignFormValues = z.infer<typeof designFormSchema>;

type AddDesignFormProps = {
  designerId: string;
  designId?: string; // For editing
  isAdmin?: boolean;
}

export default function AddDesignForm({ designerId, designId, isAdmin = false }: AddDesignFormProps) {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(!!designId);

  const form = useForm<DesignFormValues>({
    resolver: zodResolver(designFormSchema),
    defaultValues: {
      name: '',
      style: '',
      price: 50000,
      description: '',
      image: '',
      bedrooms: 0,
      bathrooms: 0,
      additionalImages: [],
      videoUrl: '',
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "additionalImages"
  });

  const watchImage = form.watch('image');
  const watchCategory = form.watch('category');

  useEffect(() => {
    if (designId) {
      const fetchDesignData = async () => {
        setDataLoading(true);
        try {
          const designRef = ref(db, `designs/${designId}`);
          const snapshot = await get(designRef);
          if (snapshot.exists()) {
            const data = snapshot.val();
            const imagesArray = Array.isArray(data.images) ? data.images : (data.images ? Object.values(data.images) : []);
            const primaryImage = data.image || imagesArray[0] || '';
            const additional = imagesArray.slice(1).map((url: string) => ({ value: url }));
            form.reset({ ...data, image: primaryImage, additionalImages: additional });
          } else {
             toast({ variant: 'destructive', title: 'Error', description: 'Design not found.' });
          }
        } catch (error) {
          console.error('Failed to fetch design data:', error);
          toast({ variant: 'destructive', title: 'Error', description: 'Failed to load design data.' });
        } finally {
          setDataLoading(false);
        }
      };
      fetchDesignData();
    }
  }, [designId, form, toast]);


  const onSubmit = async (data: DesignFormValues) => {
    setLoading(true);
    try {
      const allImages = [data.image, ...(data.additionalImages || []).map(img => img.value)].filter(Boolean);
            
      const designData = {
          ...data,
          images: allImages,
          image: data.image || allImages[0] || `https://picsum.photos/seed/${designId || new Date().getTime()}/600/400`,
      };
      delete (designData as any).additionalImages;

      if (designId) { // Editing existing design
        const designRef = ref(db, `designs/${designId}`);
        await update(designRef, designData);
        toast({
          title: 'Design Updated!',
          description: 'The design has been updated successfully.',
        });
        if (isAdmin) {
            router.push('/admin/manage-designs');
        } else {
            router.push('/professional-dashboard');
        }

      } else { // Adding new design
        const designsRef = ref(db, 'designs');
        const newDesignRef = push(designsRef);
        
        const finalData = {
          ...designData,
          designerId: data.designerId || designerId,
        };

        if (!finalData.image) {
            finalData.image = `https://picsum.photos/seed/${newDesignRef.key}/600/400`;
            if (!finalData.images || finalData.images.length === 0) {
                finalData.images = [finalData.image];
            }
        }
        
        await set(newDesignRef, finalData);

        toast({
          title: 'Design Added!',
          description: 'Your new design has been listed successfully.',
        });
        if (isAdmin) {
             router.push('/admin/manage-designs');
        } else {
            router.push('/professional-dashboard');
        }
      }
    } catch (error) {
      console.error('Failed to save design:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'An error occurred while saving the design.',
      });
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
      return (
        <Card>
            <CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader>
            <CardContent className="space-y-6">
                <div className="space-y-2"><Skeleton className="h-4 w-1/4" /><Skeleton className="h-10 w-full" /></div>
                <div className="space-y-2"><Skeleton className="h-4 w-1/4" /><Skeleton className="h-24 w-full" /></div>
                <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                    <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                </div>
                 <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                    <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                </div>
            </CardContent>
            <CardFooter><Skeleton className="h-11 w-36" /></CardFooter>
        </Card>
      );
  }

  return (
    <Card>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
            <CardTitle className="font-headline text-xl">Design Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Modern Courtyard Villa" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                        <SelectTrigger>
                            <SelectValue placeholder="Select a category for your design" />
                        </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            {designCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <FormMessage />
                    </FormItem>
                )}
            />
             <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the key features and appeal of this design product..."
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid md:grid-cols-2 gap-6">
                <FormField
                control={form.control}
                name="style"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Style</FormLabel>
                    <FormControl>
                        <Input placeholder="e.g., Contemporary, Abstract, Traditional" {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
                <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Price (INR)</FormLabel>
                    <FormControl>
                        <Input type="number" placeholder="50000" {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>
             {watchCategory === 'Architectural Plan' && (
                <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                    control={form.control}
                    name="bedrooms"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Bedrooms</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="4" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                    control={form.control}
                    name="bathrooms"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Bathrooms</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="3" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                </div>
             )}
             {isAdmin && (
                <FormField
                control={form.control}
                name="designerId"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Designer ID (Optional)</FormLabel>
                    <FormControl>
                        <Input placeholder="Enter the designer's user ID" {...field} />
                    </FormControl>
                    <FormDescription>Associate this design with a specific designer.</FormDescription>
                    <FormMessage />
                    </FormItem>
                )}
                />
            )}
            <FormField
              control={form.control}
              name="image"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Image URL</FormLabel>
                  <div className="flex gap-2">
                    <FormControl>
                      <Input placeholder="https://example.com/image.png" {...field} />
                    </FormControl>
                    {watchImage && (
                      <Button asChild variant="ghost" size="icon">
                        <Link href={watchImage} target="_blank">
                          <ExternalLink className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}
                  </div>
                  {watchImage && (
                    <div className="mt-2">
                        <Image src={watchImage} alt="Image preview" width={200} height={150} className="rounded-md object-cover" />
                    </div>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-4">
                <FormLabel>Additional Gallery Images</FormLabel>
                {fields.map((field, index) => (
                     <FormField
                        key={field.id}
                        control={form.control}
                        name={`additionalImages.${index}.value`}
                        render={({ field }) => (
                            <FormItem>
                                <div className="flex gap-2 items-center">
                                    <FormControl>
                                        <Input placeholder={`Additional Image URL ${index + 1}`} {...field} />
                                    </FormControl>
                                    <Button type="button" variant="ghost" size="icon" className="shrink-0 text-destructive" onClick={() => remove(index)}>
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </div>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                ))}
                <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => append({ value: "" })}
                >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Image URL
                </Button>
            </div>

            <FormField
              control={form.control}
              name="videoUrl"
              render={({ field }) => (
                  <FormItem>
                  <FormLabel>Video URL (Optional)</FormLabel>
                  <FormControl>
                      <Input placeholder="https://youtube.com/watch?v=..." {...field} />
                  </FormControl>
                  <FormDescription>Link to a YouTube or Instagram video showcase.</FormDescription>
                  <FormMessage />
                  </FormItem>
              )}
            />
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg" disabled={loading}>
              {loading ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : designId ? (
                <Save className="mr-2 h-5 w-5" />
              ) : (
                <PlusCircle className="mr-2 h-5 w-5" />
              )}
              {designId ? 'Save Changes' : 'Add Design Product'}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
