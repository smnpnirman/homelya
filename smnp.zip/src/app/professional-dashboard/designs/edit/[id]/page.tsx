
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import AddDesignForm from "@/app/professional-dashboard/designs/new/add-design-form";
import { useParams } from "next/navigation";

export default function EditDesignPage() {
  const { user } = useAuth();
  const params = useParams();
  const designId = params.id as string;

  if (!user) {
    return (
        <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                    <CardDescription>You must be logged in to access this page.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                        <Link href="/login">Login</Link>
                    </Button>
                </CardContent>
            </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Edit Design"
        description="Update the details for your design product."
      />
      <AddDesignForm designerId={user.uid} designId={designId} />
    </div>
  );
}
