
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useEffect, useRef, useState } from "react";
import { db } from "@/lib/firebase";
import { ref, get } from "firebase/database";
import type { Provider } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Download, Loader2, Mail, MapPin, Phone, ShieldCheck, Briefcase, Fingerprint, Link as LinkIcon, BadgePercent } from "lucide-react";
import Logo from "@/components/logo";
import Image from "next/image";
import { Separator } from "@/components/ui/separator";
import html2canvas from "html2canvas";
import { Badge } from "@/components/ui/badge";

export default function BannerPage() {
    const { user } = useAuth();
    const [professional, setProfessional] = useState<Provider | null>(null);
    const [loading, setLoading] = useState(true);
    const [downloading, setDownloading] = useState(false);
    const bannerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (user) {
            setLoading(true);
            const userRef = ref(db, `users/${user.uid}`);
            get(userRef).then(snapshot => {
                if (snapshot.exists()) {
                    setProfessional({ id: user.uid, ...snapshot.val() });
                }
                setLoading(false);
            }).catch(() => setLoading(false));
        } else {
            setLoading(false);
        }
    }, [user]);

    const handleDownload = async () => {
        if (!bannerRef.current) return;
        setDownloading(true);
        try {
            const canvas = await html2canvas(bannerRef.current, {
                scale: 3, // Increase resolution for better quality
                useCORS: true,
            });
            const link = document.createElement('a');
            const fileName = professional?.name?.replace(/\s+/g, '-') || 'professional-banner';
            link.download = `homelya-banner-${fileName}.png`;
            link.href = canvas.toDataURL('image/png');
            link.click();
        } catch (error) {
            console.error("Error downloading banner:", error);
        } finally {
            setDownloading(false);
        }
    };
    
    if (loading) {
        return (
            <div className="space-y-8 max-w-md mx-auto">
                <PageHeader title="Loading Your Banner..." />
                <Card>
                    <CardContent className="p-8">
                        <Skeleton className="h-[500px] w-full" />
                    </CardContent>
                </Card>
            </div>
        )
    }

    if (!user || !professional) {
        return (
          <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                <CardDescription>You must be logged in as a professional to view this page.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        );
    }

    const profileUrl = `${window.location.origin}/${professional.role}s/${professional.id}`;
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(profileUrl)}`;

    return (
        <div className="space-y-8 max-w-md mx-auto">
            <PageHeader
                title="Your Promotional Banner"
                description="Download this banner to share on social media or with clients."
            />

            <div 
                ref={bannerRef}
                className="bg-card border rounded-2xl shadow-lg overflow-hidden"
            >
                <div className="bg-muted/50 p-6">
                    <div className="flex justify-between items-center">
                        <Logo />
                        {professional.status === 'verified' && (
                             <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700 font-medium">
                                <ShieldCheck className="h-4 w-4 mr-1.5" />
                                Verified Partner
                            </Badge>
                        )}
                    </div>
                </div>

                <div className="p-6 space-y-4">
                    <div className="flex items-center gap-6">
                        <Image
                            src={professional.image || `https://i.pravatar.cc/150?u=${professional.id}`}
                            alt={`${professional.name} logo`}
                            width={120}
                            height={120}
                            className="rounded-full aspect-square object-cover border-4 border-card shadow-md -mt-20"
                            crossOrigin="anonymous"
                        />
                        <div className="space-y-1 mt-2">
                            <h2 className="text-2xl font-bold font-headline text-primary">{professional.name}</h2>
                            <p className="text-md text-muted-foreground font-semibold flex items-center gap-2">
                               <Briefcase className="h-5 w-5"/> {professional.specialty}
                            </p>
                        </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                        {professional.phone && <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-primary"/> {professional.phone}</p>}
                        {professional.email && <p className="flex items-center gap-2"><Mail className="h-4 w-4 text-primary"/> {professional.email}</p>}
                        {professional.location && <p className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary"/> {professional.location}</p>}
                        {professional.website && <p className="flex items-center gap-2 truncate"><LinkIcon className="h-4 w-4 text-primary"/> {professional.website.replace(/^(https?:\/\/)?(www\.)?/, '')}</p>}
                    </div>

                    {(professional.smnpId || professional.gstNumber) && (
                        <>
                            <Separator />
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                                {professional.smnpId && <p className="flex items-center gap-2 font-mono"><Fingerprint className="h-4 w-4 text-primary"/> {professional.smnpId}</p>}
                                {professional.gstNumber && <p className="flex items-center gap-2 font-mono"><BadgePercent className="h-4 w-4 text-primary"/> {professional.gstNumber}</p>}
                            </div>
                        </>
                    )}
                </div>

                <div className="bg-muted/50 p-4 flex justify-center items-center">
                    <div className="flex items-center gap-4">
                        <Image
                            src={qrCodeUrl}
                            alt="QR code to profile"
                            width={100}
                            height={100}
                            className="rounded-lg border p-1 bg-white"
                            crossOrigin="anonymous"
                        />
                        <div className="text-left">
                            <p className="font-semibold">Scan to View My Profile</p>
                            <p className="text-xs text-muted-foreground">Connect with me on Homelya!</p>
                        </div>
                    </div>
                </div>
            </div>

             <div className="text-center">
                <Button size="lg" onClick={handleDownload} disabled={downloading}>
                    {downloading ? <Loader2 className="mr-2 animate-spin" /> : <Download className="mr-2" />}
                    {downloading ? "Downloading..." : "Download Banner"}
                </Button>
            </div>
        </div>
    );
}
