
'use client';

import { useRef, useState, useEffect } from "react";
import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import bannerData from "@/lib/banners.json";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Download, Loader2, Briefcase, Fingerprint, ShieldCheck, Phone, Mail, MapPin } from "lucide-react";
import html2canvas from "html2canvas";
import { useAuth } from "@/hooks/use-auth";
import type { Provider } from "@/lib/types";
import { db } from "@/lib/firebase";
import { ref, get } from "firebase/database";
import Link from "next/link";
import Logo from "@/components/logo";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

interface Banner {
  id: string;
  eventName: string;
  image: string;
  title: string;
  description: string;
  cta: string;
}

const banners: Banner[] = bannerData.banners;

function PersonalizedBannerCard({ banner, professional }: { banner: Banner; professional: Provider | null }) {
    const cardRef = useRef<HTMLDivElement>(null);
    const [downloading, setDownloading] = useState(false);

    const handleDownload = async () => {
        if (!cardRef.current) return;
        setDownloading(true);
        try {
            const canvas = await html2canvas(cardRef.current, {
                scale: 2, // Higher resolution
                useCORS: true,
                allowTaint: true,
            });
            const link = document.createElement('a');
            const fileName = professional?.name?.replace(/\s+/g, '-') || 'professional';
            link.download = `homelya-${banner.id}-banner-${fileName}.png`;
            link.href = canvas.toDataURL("image/png");
            link.click();
        } catch (error) {
            console.error("Error downloading banner:", error);
        } finally {
            setDownloading(false);
        }
    };

    if (!professional) {
        return <Skeleton className="w-full aspect-video" />;
    }
    
    const profileUrl = `${window.location.origin}/${professional.role}s/${professional.id}`;
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(profileUrl)}`;

    return (
        <Card className="flex flex-col">
            <CardHeader>
                <CardTitle>{banner.eventName}</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0">
                <div ref={cardRef} className="relative aspect-[1/1.2] w-full bg-card p-4 flex flex-col justify-center items-center">
                    <Image
                        src={banner.image}
                        alt={banner.eventName}
                        fill
                        className="object-cover -z-10"
                        crossOrigin="anonymous"
                    />
                    <div className="absolute inset-0 bg-black/50 -z-10"></div>
                     <div className="bg-card/90 backdrop-blur-sm rounded-2xl p-4 space-y-3 shadow-lg w-[95%] h-[95%] flex flex-col">
                        <div className="flex justify-between items-center">
                            <Logo />
                            {professional.status === 'verified' && (
                                <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700 font-medium">
                                    <ShieldCheck className="h-4 w-4 mr-1.5" />
                                    Verified
                                </Badge>
                            )}
                        </div>
                        <div className="flex-1 flex flex-col justify-center items-center text-center">
                            <Image
                                src={professional.image || `https://i.pravatar.cc/150?u=${professional.id}`}
                                alt={`${professional.name} logo`}
                                width={100}
                                height={100}
                                className="rounded-full aspect-square object-cover border-4 border-white shadow-md"
                                crossOrigin="anonymous"
                            />
                            <h2 className="text-2xl font-bold font-headline text-primary mt-2">{professional.name}</h2>
                            <p className="text-md text-muted-foreground font-semibold flex items-center gap-2">
                                <Briefcase className="h-5 w-5"/> {professional.specialty}
                            </p>
                             {professional.smnpId && <p className="flex items-center gap-2 font-mono text-xs mt-1"><Fingerprint className="h-4 w-4 text-primary"/> {professional.smnpId}</p>}
                            <p className="text-white text-2xl font-bold mt-3 bg-gradient-to-r from-orange-400 to-red-500 px-4 py-2 rounded-lg shadow-inner">{banner.title}</p>
                        </div>
                        <Separator />
                        <div className="flex justify-between items-center">
                            <div className="text-[10px] space-y-1.5 text-muted-foreground">
                                {professional.phone && <p className="flex items-center gap-2"><Phone className="h-3 w-3 text-primary"/> {professional.phone}</p>}
                                {professional.email && <p className="flex items-center gap-2"><Mail className="h-3 w-3 text-primary"/> {professional.email}</p>}
                                {professional.location && <p className="flex items-center gap-2"><MapPin className="h-3 w-3 text-primary"/> {professional.location}</p>}
                            </div>
                            <div className="flex flex-col items-center">
                                <Image
                                    src={qrCodeUrl}
                                    alt="QR code to profile"
                                    width={80}
                                    height={80}
                                    className="rounded-lg border p-1"
                                    crossOrigin="anonymous"
                                />
                                <p className="text-[10px] text-muted-foreground mt-1">Scan for profile</p>
                            </div>
                        </div>
                    </div>
                </div>
            </CardContent>
            <CardContent className="p-4">
                 <Button className="w-full" onClick={handleDownload} disabled={downloading}>
                    {downloading ? <Loader2 className="mr-2 animate-spin" /> : <Download className="mr-2" />}
                    {downloading ? 'Downloading...' : 'Download Personalized Banner'}
                </Button>
            </CardContent>
        </Card>
    )
}

export default function MarketingBannersPage() {
    const { user } = useAuth();
    const [professional, setProfessional] = useState<Provider | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user) {
            setLoading(true);
            const userRef = ref(db, `users/${user.uid}`);
            get(userRef).then(snapshot => {
                if (snapshot.exists()) {
                    setProfessional({ id: user.uid, ...snapshot.val() });
                }
                setLoading(false);
            }).catch(() => setLoading(false));
        } else {
            setLoading(false);
        }
    }, [user]);

    if (!user && !loading) {
        return (
            <div className="text-center py-12">
                <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                    <CardDescription>You must be logged in as a professional to view this page.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                    <Link href="/login">Login</Link>
                    </Button>
                </CardContent>
                </Card>
            </div>
        );
    }
    
    return (
        <div className="space-y-8">
            <PageHeader
                title="Marketing Banners"
                description="Download and share these personalized festive banners to engage with your clients."
            />
             {loading ? (
                <div className="grid md:grid-cols-2 gap-6">
                    {Array.from({length: 4}).map((_, i) => <Skeleton key={i} className="w-full aspect-[1/1.2]" />)}
                </div>
             ) : (
                <div className="grid md:grid-cols-2 gap-6">
                    {banners.map((banner) => (
                        <PersonalizedBannerCard key={banner.id} banner={banner} professional={professional} />
                    ))}
                </div>
             )}
        </div>
    )
}
