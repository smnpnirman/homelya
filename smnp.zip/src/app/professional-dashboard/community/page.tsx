
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Send, Rss, Trash2, Gem, Video } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ref, push, set, serverTimestamp, onValue, query, orderByChild, remove, get } from 'firebase/database';
import { db } from '@/lib/firebase';
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import type { VerificationStatus } from "@/lib/types";
import { Input } from "@/components/ui/input";

const postFormSchema = z.object({
  content: z.string().min(1, 'Message cannot be empty.').max(1000, 'Message cannot exceed 1000 characters.'),
  videoUrl: z.string().url("Please enter a valid video URL.").optional().or(z.literal('')),
});

type PostFormValues = z.infer<typeof postFormSchema>;

interface Post {
    id: string;
    content: string;
    timestamp: number;
    videoUrl?: string;
}

export default function CommunityPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [postToDelete, setPostToDelete] = useState<Post | null>(null);
  const [status, setStatus] = useState<VerificationStatus | 'loading'>('loading');

  const form = useForm<PostFormValues>({
    resolver: zodResolver(postFormSchema),
    defaultValues: {
      content: '',
      videoUrl: '',
    },
  });

  useEffect(() => {
    if (user) {
        setLoadingPosts(true);
        const userRef = ref(db, `users/${user.uid}`);
        get(userRef).then(snapshot => {
            if (snapshot.exists()) {
                setStatus(snapshot.val().status || 'in-progress');
            }
        });
        
        const postsQuery = query(ref(db, `community-posts/${user.uid}`), orderByChild('timestamp'));
        const unsubscribe = onValue(postsQuery, (snapshot) => {
            const data = snapshot.val();
            const postsList: Post[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.timestamp - a.timestamp) : [];
            setPosts(postsList);
            setLoadingPosts(false);
        });
        return () => unsubscribe();
    } else {
        setLoadingPosts(false);
    }
  }, [user]);

  const onSubmit = async (data: PostFormValues) => {
    if (!user) return;
    setLoading(true);
    try {
      const postsRef = ref(db, `community-posts/${user.uid}`);
      const newPostRef = push(postsRef);
      await set(newPostRef, {
        content: data.content,
        videoUrl: data.videoUrl || null,
        timestamp: serverTimestamp(),
      });
      toast({ title: 'Message Sent!', description: 'Your new message is live in your community feed.' });
      form.reset();
    } catch (error) {
      console.error('Failed to create post:', error);
      toast({ variant: 'destructive', title: 'Failed to Send', description: 'Could not send your message.' });
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePost = async () => {
    if (!postToDelete || !user) return;
    const postRef = ref(db, `community-posts/${user.uid}/${postToDelete.id}`);
    try {
        await remove(postRef);
        toast({ title: "Message Deleted", description: "The message has been removed from your community feed." });
    } catch (error) {
        console.error("Error deleting post:", error);
        toast({ variant: "destructive", title: "Deletion Failed" });
    } finally {
        setPostToDelete(null);
    }
  }
  
  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to manage your community.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild><Link href="/login">Login</Link></Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
   if (status !== 'master') {
    return (
        <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
                <CardHeader>
                    <div className="mx-auto bg-purple-100 text-purple-600 rounded-full h-16 w-16 flex items-center justify-center">
                        <Gem className="h-8 w-8" />
                    </div>
                </CardHeader>
                <CardContent>
                    <CardTitle className="font-headline text-xl">Upgrade to Master Professional</CardTitle>
                    <CardDescription className="mt-2">
                        This feature is exclusive to Master Professionals. Upgrade your account to engage with your followers by posting updates to your community feed.
                    </CardDescription>
                </CardContent>
                <CardFooter>
                     <Button asChild className="mx-auto">
                        <Link href="/professional-dashboard/verify">Upgrade Now</Link>
                    </Button>
                </CardFooter>
            </Card>
        </div>
    )
  }

  return (
    <>
    <div className="space-y-8">
      <PageHeader
        title="My Community"
        description="Share updates, insights, and information with your followers."
      >
          <Button variant="outline" asChild>
              <Link href={`/community/${user.uid}`} target="_blank">View My Community Page</Link>
          </Button>
      </PageHeader>
      
      <div className="grid lg:grid-cols-3 gap-8 items-start">
        <div className="lg:col-span-1">
            <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline text-xl">Send a Message</CardTitle>
                        <CardDescription>Post an update to your community feed.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <FormField
                            control={form.control}
                            name="content"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Your Message</FormLabel>
                                <FormControl>
                                    <Textarea
                                    placeholder="Write your update here..."
                                    rows={8}
                                    {...field}
                                    />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        <FormField
                            control={form.control}
                            name="videoUrl"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>YouTube/Instagram Video URL (Optional)</FormLabel>
                                <FormControl>
                                    <Input
                                    placeholder="https://youtube.com/watch?v=..."
                                    {...field}
                                    />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                    </CardContent>
                    <CardContent>
                        <Button type="submit" className="w-full" disabled={loading}>
                            {loading ? <Loader2 className="mr-2 animate-spin"/> : <Send className="mr-2"/>}
                            Send Message
                        </Button>
                    </CardContent>
                </Card>
            </form>
            </Form>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="font-headline text-xl">My Messages</CardTitle>
              <CardDescription>A history of your sent messages.</CardDescription>
            </CardHeader>
            <CardContent>
                {loadingPosts ? (
                    <div className="space-y-4">
                        <Skeleton className="h-24 w-full" />
                        <Skeleton className="h-24 w-full" />
                    </div>
                ) : posts.length === 0 ? (
                    <div className="text-center py-12 border-dashed border-2 rounded-lg">
                        <Rss className="mx-auto h-12 w-12 text-muted-foreground" />
                        <h3 className="mt-4 text-lg font-semibold">No Messages Yet</h3>
                        <p className="mt-1 text-sm text-muted-foreground">Use the form to send your first message.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {posts.map(post => (
                            <Card key={post.id} className="flex items-start justify-between p-4">
                                <div className="flex-1 space-y-1">
                                    <p className="text-xs text-muted-foreground">
                                        Sent on {format(new Date(post.timestamp), 'PPP')}
                                    </p>
                                    <p className="text-sm text-muted-foreground line-clamp-3">{post.content}</p>
                                    {post.videoUrl && (
                                        <div className="flex items-center gap-2 text-blue-600 text-xs">
                                            <Video className="h-4 w-4"/>
                                            <a href={post.videoUrl} target="_blank" rel="noopener noreferrer" className="hover:underline truncate">
                                                {post.videoUrl}
                                            </a>
                                        </div>
                                    )}
                                </div>
                                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive shrink-0" onClick={() => setPostToDelete(post)}>
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </Card>
                        ))}
                    </div>
                )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
    <AlertDialog open={!!postToDelete} onOpenChange={(open) => !open && setPostToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this message from your community feed. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeletePost} className="bg-destructive hover:bg-destructive/90">
              Delete Message
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
