
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ExternalLink, Loader2, PlusCircle } from 'lucide-react';
import { useState } from 'react';
import { ref, push, set } from 'firebase/database';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Link from 'next/link';

const propertyFormSchema = z.object({
  name: z.string().min(10, 'Title must be at least 10 characters.'),
  description: z.string().min(50, 'Description must be at least 50 characters.'),
  price: z.coerce.number().min(100000, 'Price must be at least 1,00,000.'),
  location: z.string().min(3, 'Location is required.'),
  area: z.coerce.number().min(100, 'Area must be at least 100 sqft.'),
  bedrooms: z.coerce.number().min(0, 'Bedrooms cannot be negative.'),
  bathrooms: z.coerce.number().min(0, 'Bathrooms cannot be negative.'),
  propertyType: z.enum(['Apartment', 'Villa', 'Plot', 'House']),
  image: z.string().url('Please enter a valid primary image URL.'),
  images: z.string().optional().describe('A comma-separated list of additional image URLs.'),
});

type PropertyFormValues = z.infer<typeof propertyFormSchema>;

export default function AddPropertyForm({ sellerId }: { sellerId: string }) {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const form = useForm<PropertyFormValues>({
    resolver: zodResolver(propertyFormSchema),
    defaultValues: {
      name: '',
      description: '',
      price: 1000000,
      location: '',
      area: 1200,
      bedrooms: 2,
      bathrooms: 2,
      image: '',
      images: '',
    },
  });

  const watchImage = form.watch('image');

  const onSubmit = async (data: PropertyFormValues) => {
    setLoading(true);
    try {
      const propertiesRef = ref(db, 'properties');
      const newPropertyRef = push(propertiesRef);
      
      const additionalImages = data.images?.split(',').map(url => url.trim()).filter(url => url) || [];

      const propertyData = {
          ...data,
          images: [data.image, ...additionalImages],
          sellerId,
          status: 'available',
      }
      delete (propertyData as any).image;


      await set(newPropertyRef, propertyData);

      toast({
        title: 'Property Listed!',
        description: 'Your new property has been successfully listed for sale.',
      });
      router.push(`/properties/${newPropertyRef.key}`); 
    } catch (error) {
      console.error('Failed to add property:', error);
      toast({
        variant: 'destructive',
        title: 'Submission Failed',
        description: 'An error occurred while listing your property.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardHeader>
            <CardTitle className="font-headline text-xl">Property Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Property Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., 2BHK Apartment for Sale in Kanke, Ranchi" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the key features, amenities, and location advantages..."
                      rows={5}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <div className="grid md:grid-cols-2 gap-6">
                 <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Price (INR)</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="e.g., 5000000" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                            <Input placeholder="e.g., Kanke, Ranchi" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
            <div className="grid md:grid-cols-2 gap-6">
                 <FormField
                    control={form.control}
                    name="propertyType"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Property Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                            <SelectTrigger>
                                <SelectValue placeholder="Select property type" />
                            </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                                <SelectItem value="Apartment">Apartment</SelectItem>
                                <SelectItem value="Villa">Villa</SelectItem>
                                <SelectItem value="Plot">Plot</SelectItem>
                                <SelectItem value="House">House</SelectItem>
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                <FormField
                    control={form.control}
                    name="area"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Area (sqft)</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="e.g., 1200" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
             <div className="grid md:grid-cols-2 gap-6">
                <FormField
                control={form.control}
                name="bedrooms"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Bedrooms</FormLabel>
                    <FormControl>
                        <Input type="number" placeholder="2" {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
                <FormField
                control={form.control}
                name="bathrooms"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Bathrooms</FormLabel>
                    <FormControl>
                        <Input type="number" placeholder="2" {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>
            <FormField
              control={form.control}
              name="image"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Image URL</FormLabel>
                  <div className="flex gap-2">
                    <FormControl>
                      <Input placeholder="https://example.com/main-image.png" {...field} />
                    </FormControl>
                    {watchImage && (
                      <Button asChild variant="ghost" size="icon">
                        <Link href={watchImage} target="_blank">
                          <ExternalLink className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}
                  </div>
                   <FormDescription>This will be the main cover image for your property.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="images"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Image URLs (Optional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="https://example.com/image1.png, https://example.com/image2.png" {...field} />
                  </FormControl>
                  <FormDescription>Add more image URLs, separated by commas.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter>
            <Button type="submit" size="lg" disabled={loading}>
              {loading ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <PlusCircle className="mr-2 h-5 w-5" />
              )}
              List Property
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
