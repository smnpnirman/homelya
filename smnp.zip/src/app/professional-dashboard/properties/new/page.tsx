
'use client';

import PageHeader from "@/components/page-header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import AddPropertyForm from "./add-property-form";

export default function AddPropertyPage() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
            <CardDescription>You must be logged in to add a new property.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/professional-auth/login">Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Add a New Property"
        description="Fill out the details below to list a new property for sale."
      />
      <AddPropertyForm sellerId={user.uid} />
    </div>
  );
}
