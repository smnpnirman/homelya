

'use client';

import { useRouter } from 'next/navigation';
import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LogIn, ShieldCheck, CheckCircle, Loader2, Clock, Gem, IndianRupee } from 'lucide-react';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';
import { db } from '@/lib/firebase';
import { ref, update, serverTimestamp, get, push, set } from 'firebase/database';
import { useToast } from '@/hooks/use-toast';
import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { VerificationStatus } from '@/lib/types';
import Image from 'next/image';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function VerificationPaymentPage() {
  const router = useRouter();
  const { user, userData } = useAuth();
  const { toast } = useToast();
  const [transactionId, setTransactionId] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<VerificationStatus | 'loading'>('loading');
  const [subscriptionYears, setSubscriptionYears] = useState(1);
  const isDubai = userData?.country === 'dubai';

  const upiId = '6204910508@mbk';
  const payeeName = 'Homelya';
  
  const isMasterUpgrade = status === 'verified';
  const basePrice = isMasterUpgrade ? 2999 : 2999;
  const price = isMasterUpgrade ? basePrice * subscriptionYears : basePrice;

  const upiLink = `upi://pay?pa=${upiId}&pn=${payeeName}&am=${price}&cu=INR&tn=${isMasterUpgrade ? `Master Upgrade (${subscriptionYears} Year/s)` : 'Basic Verification Fee'}`;

  useEffect(() => {
    if (user) {
        const userRef = ref(db, `users/${user.uid}`);
        get(userRef).then(snapshot => {
            if (snapshot.exists()) {
                setStatus(snapshot.val().status || 'in-progress');
            } else {
                setStatus('in-progress');
            }
        });
    } else {
        setStatus('in-progress');
    }
  }, [user]);

  const handleSubmitVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!transactionId.trim()) {
        toast({
            variant: 'destructive',
            title: 'Transaction ID Required',
            description: 'Please enter the transaction ID from your UPI app.',
        });
        return;
    }
    setLoading(true);

    const newStatus = isMasterUpgrade ? 'master-payment-pending' : 'payment-pending';
    const feeDescription = isMasterUpgrade ? `Master Upgrade (${subscriptionYears} Year/s)` : 'Basic Verification Fee';

    try {
      const userRef = ref(db, `users/${user.uid}`);
      await update(userRef, { 
          status: newStatus,
          verificationTransactionId: transactionId,
          verificationTimestamp: serverTimestamp(),
      });
      
      const userTransactionsRef = ref(db, `transactions/${user.uid}`);
      const newTransactionRef = push(userTransactionsRef);
      await set(newTransactionRef, {
        amount: price,
        description: feeDescription,
        timestamp: serverTimestamp(),
        type: 'payment',
        status: 'pending',
        subscriptionYears: isMasterUpgrade ? subscriptionYears : undefined,
      });

      toast({
        title: 'Payment Submitted',
        description: 'Your payment is under review. This can take up to 48 hours.',
      });
      setStatus(newStatus);
    } catch (error) {
      console.error('Failed to update status:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Could not submit your verification payment. Please try again.',
      });
    } finally {
        setLoading(false);
    }
  };

  if (status === 'loading') {
      return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Authentication Required</CardTitle>
            <CardDescription>You need to be logged in to get verified.</CardDescription>
          </CardHeader>
          <CardContent className="flex gap-4 justify-center">
            <Button asChild>
              <Link href={`/login?redirect=/professional-dashboard/verify`}> <LogIn className="mr-2"/> Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (status === 'payment-pending' || status === 'master-payment-pending') {
      return (
           <div className="space-y-8 max-w-2xl mx-auto">
              <PageHeader
                title="Payment in Progress"
                description="Your payment is currently being reviewed by our team."
              />
              <Card className="bg-blue-50 border-blue-200 text-center">
                <CardHeader>
                    <div className="mx-auto bg-blue-100 text-blue-600 rounded-full h-16 w-16 flex items-center justify-center">
                        <Clock className="h-8 w-8" />
                    </div>
                </CardHeader>
                <CardContent>
                    <CardTitle className="font-headline text-xl text-blue-900">
                        We've Received Your Payment Request
                    </CardTitle>
                    <CardDescription className="text-blue-800 mt-2">
                        Thank you for submitting your payment details. Verification can take up to 48 hours. We'll notify you once your profile is approved.
                    </CardDescription>
                </CardContent>
                <CardFooter>
                    <Button asChild className="mx-auto" variant="outline">
                        <Link href="/professional-dashboard">Back to Dashboard</Link>
                    </Button>
                </CardFooter>
              </Card>
           </div>
      )
  }
  
   if (status === 'master') {
      return (
           <div className="space-y-8 max-w-2xl mx-auto">
              <PageHeader
                title="Subscription Active"
                description="You are a Master Professional!"
              />
              <Card className="bg-green-50 border-green-200 text-center">
                <CardHeader>
                    <div className="mx-auto bg-green-100 text-green-600 rounded-full h-16 w-16 flex items-center justify-center">
                        <Gem className="h-8 w-8" />
                    </div>
                </CardHeader>
                <CardContent>
                    <CardTitle className="font-headline text-xl text-green-900">
                        Welcome to the Master Tier!
                    </CardTitle>
                    <CardDescription className="text-green-800 mt-2">
                        You now have access to all premium features, including profile customization.
                    </CardDescription>
                </CardContent>
                <CardFooter>
                    <Button asChild className="mx-auto">
                        <Link href="/professional-dashboard/profile/edit">Customize Your Profile</Link>
                    </Button>
                </CardFooter>
              </Card>
           </div>
      )
  }


  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <PageHeader
        title={isMasterUpgrade ? 'Upgrade to Master Professional' : 'Professional Verification'}
        description={isMasterUpgrade ? `You're already verified! Upgrade now to unlock premium features.` : `Unlock premium features like a 'Verified' badge by paying a one-time fee.`}
      />
      <Card>
        <CardHeader>
            <CardTitle className="font-headline">{isMasterUpgrade ? 'Pay Master Upgrade Fee' : 'Pay One-Time Verification Fee'}</CardTitle>
            <CardDescription>
                Pay a fee of {isDubai ? `AED ${price.toLocaleString()}` : `₹${price.toLocaleString('en-IN')}`} to {isMasterUpgrade ? 'upgrade your account' : `get a 'Verified' badge and build trust with clients`}.
            </CardDescription>
        </CardHeader>
        <CardContent>
            {isMasterUpgrade && (
                 <Card className="mb-6 bg-purple-50 border-purple-200">
                    <CardHeader>
                        <CardTitle className="font-headline text-lg text-purple-900">Master Professional Benefits</CardTitle>
                    </CardHeader>
                     <CardContent>
                         <ul className="space-y-2 text-sm text-purple-800">
                             <li className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-purple-600"/>Exclusive 'Master' Badge on Profile</li>
                             <li className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-purple-600"/>Profile Customization (Themes)</li>
                             <li className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-purple-600"/>Display Social Media Links</li>
                         </ul>
                     </CardContent>
                 </Card>
            )}
            <Card>
                <form onSubmit={handleSubmitVerification}>
                    {isMasterUpgrade && (
                        <CardContent className="pt-6">
                             <div className="grid grid-cols-2 gap-4 items-end">
                                <div className="space-y-2">
                                <Label>Subscription Duration</Label>
                                <Select onValueChange={(value) => setSubscriptionYears(Number(value))} defaultValue="1">
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select duration" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="1">1 Year</SelectItem>
                                        <SelectItem value="2">2 Years</SelectItem>
                                        <SelectItem value="3">3 Years</SelectItem>
                                        <SelectItem value="4">4 Years</SelectItem>
                                        <SelectItem value="5">5 Years</SelectItem>
                                    </SelectContent>
                                </Select>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm text-muted-foreground">Total Amount</p>
                                    <p className="text-2xl font-bold">{isDubai ? `AED ${price.toLocaleString()}` : `₹${price.toLocaleString('en-IN')}`}</p>
                                </div>
                            </div>
                        </CardContent>
                    )}
                    <CardHeader>
                        <CardTitle>Pay with UPI QR</CardTitle>
                        <CardDescription>1. Scan the QR code with any UPI app.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4 text-center">
                        <div className="p-4 bg-muted rounded-lg">
                            <p className="text-sm text-muted-foreground">Scan the QR code or use the UPI ID below</p>
                            <div className="flex justify-center my-4">
                                <Image 
                                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiLink)}`}
                                alt="UPI QR Code for verification fee"
                                width={200}
                                height={200}
                                className="rounded-md border p-2"
                                />
                            </div>
                            <p className="font-mono font-semibold text-lg">{upiId}</p>
                        </div>
                    </CardContent>
                     <CardHeader>
                        <CardDescription>2. After paying, submit the UPI Transaction ID below.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            <Label htmlFor="transaction-id">UPI Transaction ID</Label>
                            <Input 
                                id="transaction-id" 
                                placeholder="e.g., 217382193812" 
                                value={transactionId}
                                onChange={(e) => setTransactionId(e.target.value)}
                                required
                            />
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button className="w-full" size="lg" type="submit" disabled={loading}>
                            {loading ? <Loader2 className="mr-2 animate-spin"/> : <ShieldCheck className="mr-2" />}
                            {loading ? 'Submitting...' : 'Submit Transaction ID'}
                        </Button>
                    </CardFooter>
                </form>
            </Card>
        </CardContent>
      </Card>
    </div>
  );
}
