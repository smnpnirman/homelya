
'use client';

import PageHeader from "@/components/page-header";
import EditProfileForm from "./edit-profile-form";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function EditProfilePage() {
  const { user } = useAuth();

  if (!user) {
    return (
        <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                    <CardDescription>You must be logged in to edit your profile.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                        <Link href="/professional-auth/login">Login</Link>
                    </Button>
                </CardContent>
            </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Edit Your Profile"
        description="Keep your professional information up-to-date to attract more clients."
      />
      <EditProfileForm userId={user.uid} />
    </div>
  );
}
