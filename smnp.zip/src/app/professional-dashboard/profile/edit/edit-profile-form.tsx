
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, useFieldArray } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ExternalLink, Loader2, Save, Gem, Image as ImageIcon, Check, Eye, Video, PlusCircle, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ref, get, update } from 'firebase/database';
import { db } from '@/lib/firebase';
import { Skeleton } from '@/components/ui/skeleton';
import type { ProfileTheme, VerificationStatus } from '@/lib/types';
import { Separator } from '@/components/ui/separator';
import Image from 'next/image';
import Link from 'next/link';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

const indianStatesAndUTs = [
  "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", 
  "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", 
  "Jharkhand", "Karnataka", "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", 
  "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", 
  "Uttar Pradesh", "Uttarakhand", "West Bengal"
];

const profileFormSchema = z.object({
  companyName: z.string().min(2, 'Company name must be at least 2 characters.'),
  specialty: z.string().min(2, 'Specialty must be at least 2 characters.'),
  experienceLevel: z.enum(['Beginner', 'Intermediate', 'Expert']).optional(),
  state: z.string({ required_error: 'Please select your state.' }).optional(),
  location: z.string().min(2, 'Location must be at least 2 characters.'),
  locationUrl: z.string().url('Please enter a valid URL (e.g., a Google Maps link).').optional().or(z.literal('')),
  description: z.string().min(20, 'Description must be at least 20 characters.'),
  phone: z.string().min(10, 'Please enter a valid phone number.').optional().or(z.literal('')),
  email: z.string().email('Please enter a valid email address.').optional().or(z.literal('')),
  website: z.string().url({ message: 'Please enter a valid URL.' }).optional().or(z.literal('')),
  gstNumber: z.string().optional(),
  image: z.string().url({ message: "Please enter a valid image URL." }).optional().or(z.literal('')),
  coverImage: z.string().url({ message: "Please enter a valid cover image URL." }).optional().or(z.literal('')),
  socials: z.object({
      facebook: z.string().url().optional().or(z.literal('')),
      instagram: z.string().url().optional().or(z.literal('')),
      linkedin: z.string().url().optional().or(z.literal('')),
      twitter: z.string().url().optional().or(z.literal('')),
  }).optional(),
  workHistory: z.string().optional(),
  skills: z.string().optional(),
  catalogPdfUrl: z.string().url({ message: "Please enter a valid PDF URL." }).optional().or(z.literal('')),
  theme: z.enum(['default', 'modern', 'creative', 'premium']).optional(),
  galleryImages: z.array(z.object({ value: z.string().url({message: "Please enter a valid URL."}).optional().or(z.literal('')) })).optional(),
  profileVideoUrl: z.string().url({ message: "Please enter a valid YouTube or Instagram video URL." }).optional().or(z.literal('')),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

const themePreviews: Record<ProfileTheme, { name: string; layout: React.FC }> = {
    default: {
        name: 'Default',
        layout: () => (
            <div className="w-full h-full rounded bg-slate-50 p-2 space-y-1.5 flex flex-col">
                <div className="h-8 rounded-sm bg-slate-200 flex items-center p-1.5 gap-1.5">
                    <div className="w-5 h-5 rounded bg-slate-300" />
                    <div className="space-y-1 flex-1">
                        <div className="h-2 w-1/2 rounded-sm bg-slate-300" />
                        <div className="h-1.5 w-1/4 rounded-sm bg-slate-300/80" />
                    </div>
                </div>
                <div className="flex-1 flex gap-1.5">
                    <div className="w-2/3 space-y-1.5">
                        <div className="h-12 rounded-sm bg-slate-200" />
                        <div className="h-full rounded-sm bg-slate-200" />
                    </div>
                    <div className="w-1/3 space-y-1.5">
                        <div className="h-10 rounded-sm bg-slate-200" />
                        <div className="h-full rounded-sm bg-slate-200" />
                    </div>
                </div>
            </div>
        )
    },
    modern: {
        name: 'Modern',
        layout: () => (
             <div className="w-full h-full rounded bg-slate-50 p-1 space-y-1 relative">
                <div className="h-8 rounded-sm bg-teal-200" />
                <div className="absolute top-5 left-1/2 -translate-x-1/2 w-11/12">
                    <div className="h-12 rounded-sm bg-white border border-gray-200 shadow-sm p-1.5 flex items-center gap-1.5">
                         <div className="w-8 h-8 rounded-full bg-gray-300" />
                         <div className="space-y-1 flex-1">
                            <div className="h-2 w-1/2 rounded-sm bg-gray-300" />
                            <div className="h-1.5 w-1/4 rounded-sm bg-gray-300/80" />
                        </div>
                    </div>
                    <div className="h-10 mt-1 rounded-sm bg-white border border-gray-200 shadow-sm" />
                    <div className="h-16 mt-1 rounded-sm bg-white border border-gray-200 shadow-sm" />
                </div>
            </div>
        )
    },
    creative: {
        name: 'Creative',
        layout: () => (
             <div className="w-full h-full rounded bg-pink-50 p-1 space-y-1">
                <div className="h-12 rounded-sm bg-pink-100 flex items-center p-2 gap-2">
                    <div className="h-8 w-8 rounded-md bg-pink-300" />
                     <div className="flex-1 space-y-1">
                        <div className="h-2 w-3/4 rounded-sm bg-pink-300" />
                        <div className="h-1.5 w-1/2 rounded-sm bg-pink-300/70" />
                        <div className="h-3 w-1/4 rounded-sm bg-pink-300" />
                    </div>
                </div>
                <div className="h-24 rounded-sm bg-pink-100/50" />
            </div>
        )
    },
    premium: {
        name: 'Premium',
         layout: () => (
            <div className="w-full h-full rounded bg-slate-50 p-1 space-y-1 relative">
                <div className="h-8 rounded-sm bg-amber-200" />
                <div className="absolute top-5 left-2 w-full pr-2">
                    <div className="flex items-end gap-1.5">
                        <div className="h-10 w-10 rounded-full bg-slate-800 border-2 border-white shadow" />
                         <div className="space-y-1 flex-1 pb-1">
                            <div className="h-3 w-1/2 rounded-sm bg-slate-800" />
                            <div className="h-2 w-1/3 rounded-sm bg-amber-400" />
                        </div>
                    </div>
                    <div className="mt-1.5 flex gap-1.5">
                         <div className="w-2/3 space-y-1">
                            <div className="h-4 w-1/3 rounded-sm bg-slate-200" />
                            <div className="h-16 rounded-sm bg-slate-200" />
                         </div>
                         <div className="w-1/3 space-y-1">
                            <div className="h-10 rounded-sm bg-slate-200" />
                         </div>
                    </div>
                </div>
            </div>
        )
    }
};


const ThemePreview = ({ theme, selected, onClick }: { theme: ProfileTheme, selected: boolean, onClick: () => void }) => {
    const preview = themePreviews[theme] || themePreviews.default;
    const Layout = preview.layout;
    return (
        <div onClick={onClick} className={cn("cursor-pointer rounded-lg border-2 p-2 transition-all", selected ? 'border-primary ring-2 ring-primary/50 shadow-lg' : 'border-border hover:border-primary/50')}>
            <div className="aspect-video rounded-md bg-background p-1 overflow-hidden">
                <Layout />
            </div>
            <div className="mt-2 flex items-center justify-between">
                <p className="font-semibold text-sm">{preview.name}</p>
                {selected && <Check className="h-5 w-5 text-primary" />}
            </div>
        </div>
    );
}

export default function EditProfileForm({ userId }: { userId: string }) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus | null>(null);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      companyName: '',
      specialty: '',
      experienceLevel: 'Beginner',
      location: '',
      locationUrl: '',
      description: '',
      phone: '',
      email: '',
      website: '',
      gstNumber: '',
      image: '',
      coverImage: '',
      socials: {
          facebook: '',
          instagram: '',
          linkedin: '',
          twitter: '',
      },
      workHistory: '',
      skills: '',
      catalogPdfUrl: '',
      theme: 'default',
      galleryImages: [],
      profileVideoUrl: '',
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "galleryImages"
  });

  const watchImage = form.watch('image');
  const watchCoverImage = form.watch('coverImage');
  const watchTheme = form.watch('theme');

  useEffect(() => {
    const fetchProfileData = async () => {
      setDataLoading(true);
      try {
        const userRef = ref(db, `users/${userId}`);
        const snapshot = await get(userRef);
        if (snapshot.exists()) {
          const data = snapshot.val();
          setVerificationStatus(data.status || 'in-progress');
          setUserRole(data.role || 'user');
          const gallery = Array.isArray(data.galleryImages) ? data.galleryImages.map(url => ({ value: url })) : [];
          form.reset({
            companyName: data.companyName || '',
            specialty: data.specialty || '',
            experienceLevel: data.experienceLevel || 'Beginner',
            state: data.state || '',
            location: data.location || '',
            locationUrl: data.locationUrl || '',
            description: data.description || '',
            phone: data.phone || '',
            email: data.email || '',
            website: data.website || '',
            gstNumber: data.gstNumber || '',
            image: data.image || '',
            coverImage: data.coverImage || '',
            socials: data.socials || { facebook: '', instagram: '', linkedin: '', twitter: '' },
            workHistory: data.workHistory || '',
            skills: data.skills || '',
            catalogPdfUrl: data.catalogPdfUrl || '',
            theme: data.theme || 'default',
            galleryImages: gallery,
            profileVideoUrl: data.profileVideoUrl || '',
          });
        }
      } catch (error) {
        console.error('Failed to fetch profile data:', error);
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'Failed to load your profile data.',
        });
      } finally {
        setDataLoading(false);
      }
    };

    fetchProfileData();
  }, [userId, form, toast]);

  const onSubmit = async (data: ProfileFormValues) => {
    setLoading(true);
    
    const submittedData = {
        ...data,
        galleryImages: (data.galleryImages || []).map(item => item.value).filter(url => url && url.trim() !== '')
    };

    try {
      const userRef = ref(db, `users/${userId}`);
      await update(userRef, submittedData);
      toast({
        title: 'Profile Updated',
        description: 'Your professional profile has been saved successfully.',
      });
    } catch (error) {
      console.error('Failed to update profile:', error);
      toast({
        variant: 'destructive',
        title: 'Update Failed',
        description: 'An error occurred while updating your profile.',
      });
    } finally {
      setLoading(false);
    }
  };

  const profileLink = userRole ? `/${userRole}s/${userId}` : '/';

  if (dataLoading) {
    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/3" />
                    <Skeleton className="h-4 w-2/3" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2"><Skeleton className="h-4 w-1/4" /><Skeleton className="h-10 w-full" /></div>
                    <div className="space-y-2"><Skeleton className="h-4 w-1/4" /><Skeleton className="h-24 w-full" /></div>
                    <div className="space-y-2"><Skeleton className="h-4 w-1/4" /><Skeleton className="h-10 w-full" /></div>
                </CardContent>
            </Card>
             <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/3" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                        <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                    </div>
                </CardContent>
            </Card>
            {verificationStatus === 'master' && (
             <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-full" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <Skeleton className="h-10 w-32" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-1/4" />
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
                        <Skeleton className="h-28 w-full" />
                        <Skeleton className="h-28 w-full" />
                        <Skeleton className="h-28 w-full" />
                        <Skeleton className="h-28 w-full" />
                      </div>
                    </div>
                    <div className="space-y-2"><Skeleton className="h-4 w-1/4" /><Skeleton className="h-10 w-full" /></div>
                    <div className="space-y-2"><Skeleton className="h-4 w-1/4" /><Skeleton className="h-24 w-full" /></div>
                     <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                        <div className="space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-10 w-full" /></div>
                    </div>
                </CardContent>
            </Card>
            )}
        </div>
    );
  }

  return (
    <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle className="font-headline text-xl">Public Information</CardTitle>
                    <CardDescription>This information will be displayed on your public profile.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <FormField
                    control={form.control}
                    name="companyName"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                            <Input placeholder="e.g., Jharkhand Builders" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Company Description</FormLabel>
                        <FormControl>
                            <Textarea
                            placeholder="Describe your company and the services you offer..."
                            rows={5}
                            {...field}
                            />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                    control={form.control}
                    name="image"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Profile Logo URL</FormLabel>
                        <div className="flex gap-2">
                            <FormControl>
                            <Input placeholder="https://example.com/logo.png" {...field} />
                            </FormControl>
                            {watchImage && (
                            <Button asChild variant="ghost" size="icon">
                                <Link href={watchImage} target="_blank">
                                <ExternalLink className="h-4 w-4" />
                                </Link>
                            </Button>
                            )}
                        </div>
                        {watchImage && (
                            <div className="mt-2">
                                <Image src={watchImage} alt="Image preview" width={100} height={100} className="rounded-md object-cover" />
                            </div>
                        )}
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="font-headline text-xl">Contact & Location</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Public Phone Number</FormLabel>
                            <FormControl>
                                <Input placeholder="e.g., +91 12345 67890" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Public Email</FormLabel>
                            <FormControl>
                                <Input placeholder="e.g., contact@yourcompany.com" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    </div>
                     <FormField
                        control={form.control}
                        name="website"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Website URL</FormLabel>
                            <FormControl>
                                <Input placeholder="https://yourcompany.com" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    <div className="grid md:grid-cols-2 gap-6">
                        <FormField
                            control={form.control}
                            name="state"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>State</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select State" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    {indianStatesAndUTs.map(state => <SelectItem key={state} value={state}>{state}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>City / Location</FormLabel>
                            <FormControl>
                                <Input placeholder="e.g., Ranchi" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    </div>
                     <FormField
                        control={form.control}
                        name="locationUrl"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Google Maps URL</FormLabel>
                            <FormControl>
                                <Input placeholder="https://maps.app.goo.gl/..." {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                    />
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="font-headline text-xl">Professional Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <FormField
                        control={form.control}
                        name="specialty"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Specialty</FormLabel>
                            <FormControl>
                                <Input placeholder="e.g., Modern & Minimalist" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                            control={form.control}
                            name="experienceLevel"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Experience Level</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select your experience level" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        <SelectItem value="Beginner">Beginner</SelectItem>
                                        <SelectItem value="Intermediate">Intermediate</SelectItem>
                                        <SelectItem value="Expert">Expert</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                    <FormField
                        control={form.control}
                        name="gstNumber"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>GST Number (Optional)</FormLabel>
                            <FormControl>
                                <Input placeholder="e.g., 20AAAAA0000A1Z5" {...field} />
                            </FormControl>
                            <FormDescription>Your Goods and Services Tax number.</FormDescription>
                            <FormMessage />
                            </FormItem>
                        )}
                    />
                     <FormField
                        control={form.control}
                        name="workHistory"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Work History & Experience</FormLabel>
                            <FormControl>
                                <Textarea
                                placeholder="Detail your past roles, notable projects, years of experience, etc."
                                rows={5}
                                {...field}
                                />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                        control={form.control}
                        name="skills"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Skills & Expertise</FormLabel>
                            <FormControl>
                                <Textarea
                                placeholder="List your key skills, separated by commas (e.g., 3D Modeling, Project Management, Vastu Compliance)."
                                rows={3}
                                {...field}
                                />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                            control={form.control}
                            name="catalogPdfUrl"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Catalog PDF URL</FormLabel>
                                <FormControl>
                                    <Input placeholder="https://example.com/catalog.pdf" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                </CardContent>
            </Card>

            {verificationStatus === 'master' && (
                <Card className="border-purple-500/50">
                    <CardHeader>
                        <CardTitle className="font-headline text-xl flex items-center gap-2">
                           <Gem className="text-purple-500" /> Master Professional Features
                        </CardTitle>
                        <CardDescription>Customize the look and feel of your public profile page.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <Button asChild variant="outline">
                            <Link href={profileLink} target="_blank">
                                <Eye className="mr-2 h-4 w-4" /> View My Profile
                            </Link>
                        </Button>
                        
                        <FormField
                            control={form.control}
                            name="theme"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Profile Theme</FormLabel>
                                <FormDescription>Choose a visual theme for your public profile page.</FormDescription>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
                                    {(Object.keys(themePreviews) as Array<ProfileTheme>).map(theme => (
                                        <ThemePreview
                                            key={theme}
                                            theme={theme}
                                            selected={field.value === theme}
                                            onClick={() => field.onChange(theme)}
                                        />
                                    ))}
                                </div>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        {(watchTheme === 'modern' || watchTheme === 'premium') && (
                            <FormField
                                control={form.control}
                                name="coverImage"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Cover Image URL (for Modern/Premium themes)</FormLabel>
                                    <div className="flex gap-2">
                                        <FormControl>
                                        <Input placeholder="https://example.com/cover.png" {...field} />
                                        </FormControl>
                                        {watchCoverImage && (
                                        <Button asChild variant="ghost" size="icon">
                                            <Link href={watchCoverImage} target="_blank">
                                            <ExternalLink className="h-4 w-4" />
                                            </Link>
                                        </Button>
                                        )}
                                    </div>
                                    {watchCoverImage && (
                                        <div className="mt-2">
                                            <Image src={watchCoverImage} alt="Cover image preview" width={200} height={100} className="rounded-md object-cover" />
                                        </div>
                                    )}
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        )}
                         <div className="space-y-3">
                            <FormLabel>Gallery Images</FormLabel>
                            <FormDescription>Add image URLs to showcase in your profile gallery.</FormDescription>
                            {fields.map((field, index) => {
                                const fieldValue = form.watch(`galleryImages.${index}.value`);
                                return (
                                    <FormField
                                        key={field.id}
                                        control={form.control}
                                        name={`galleryImages.${index}.value`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <div className="flex gap-2 items-center">
                                                    <FormControl>
                                                        <Input placeholder={`Image URL ${index + 1}`} {...field} />
                                                    </FormControl>
                                                    {fieldValue && (
                                                        <div className="w-16 h-10 relative shrink-0">
                                                            <Image src={fieldValue} alt={`Preview ${index + 1}`} layout="fill" className="object-cover rounded-md" />
                                                        </div>
                                                    )}
                                                    <Button type="button" variant="ghost" size="icon" className="shrink-0 text-destructive" onClick={() => remove(index)}>
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                );
                            })}
                             <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => append({ value: "" })}
                            >
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Add Image
                            </Button>
                        </div>
                         <FormField
                            control={form.control}
                            name="profileVideoUrl"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Profile Video URL</FormLabel>
                                <FormControl>
                                    <Input placeholder="https://youtube.com/watch?v=... or https://instagram.com/p/..." {...field} />
                                </FormControl>
                                <FormDescription>Add a YouTube or Instagram link to display a video on your profile.</FormDescription>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <Separator />
                        <div>
                            <h3 className="text-lg font-medium">Social Media Links</h3>
                            <p className="text-sm text-muted-foreground">Add links to your social media profiles.</p>
                        </div>
                        <div className="grid md:grid-cols-2 gap-6">
                            <FormField
                                control={form.control}
                                name="socials.linkedin"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>LinkedIn</FormLabel>
                                    <FormControl>
                                        <Input placeholder="https://linkedin.com/in/..." {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                                />
                            <FormField
                                control={form.control}
                                name="socials.twitter"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>X / Twitter</FormLabel>
                                    <FormControl>
                                        <Input placeholder="https://x.com/..." {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                                />
                            <FormField
                                control={form.control}
                                name="socials.instagram"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Instagram</FormLabel>
                                    <FormControl>
                                        <Input placeholder="https://instagram.com/..." {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                                />
                            <FormField
                                control={form.control}
                                name="socials.facebook"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Facebook</FormLabel>
                                    <FormControl>
                                        <Input placeholder="https://facebook.com/..." {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                                />
                        </div>
                    </CardContent>
                </Card>
            )}

            <div className="flex justify-end">
                <Button type="submit" size="lg" disabled={loading}>
                {loading ? (
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                    <Save className="mr-2 h-5 w-5" />
                )}
                Save Changes
                </Button>
            </div>
      </form>
    </Form>
  );
}

