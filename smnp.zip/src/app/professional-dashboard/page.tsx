
'use client';
import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { MessageSquare, Pencil, PlusCircle, ShieldCheck, IndianRupee, Clock, CalendarCheck, Heart, Fingerprint, Landmark, ChevronDown, CheckCircle, Hourglass, XCircle, FileText, Building, Download, Annoyed, Users, Gavel, View, Megaphone, Gem, Rss, Mail, Loader2, CalendarDays, Paintbrush } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useEffect, useState } from "react";
import { db, auth } from "@/lib/firebase";
import { ref, onValue, query, orderByChild, equalTo } from "firebase/database";
import type { VerificationStatus } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { useRouter } from "next/navigation";
import { sendEmailVerification } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';


interface HomeLoanInquiry {
    id: string;
    userId: string;
    status: 'payment-pending' | 'verifying' | 'processing' | 'approved' | 'rejected';
    loanAmount: number;
    timestamp: number;
}

function loanStatusToJsx(status: HomeLoanInquiry['status']) {
    switch(status) {
        case 'payment-pending':
            return <Badge variant="secondary" className="border-blue-500/50 bg-blue-500/10 text-blue-700"><Clock className="mr-1.5" />Payment Pending</Badge>;
        case 'verifying':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700"><Hourglass className="mr-1.5" />Verifying</Badge>;
        case 'processing':
            return <Badge variant="default"><Hourglass className="mr-1.5" />Processing</Badge>;
        case 'approved':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700"><CheckCircle className="mr-1.5" />Approved</Badge>;
        case 'rejected':
            return <Badge variant="destructive"><XCircle className="mr-1.5" />Rejected</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}


function UserHomeLoanStatus() {
  const { user } = useAuth();
  const router = useRouter();
  const [loanApplications, setLoanApplications] = useState<HomeLoanInquiry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      setLoading(true);
      const loansQuery = query(ref(db, 'home-loan-inquiries'), orderByChild('userId'), equalTo(user.uid));
      const unsubscribe = onValue(loansQuery, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const applications: HomeLoanInquiry[] = Object.keys(data)
            .map(key => ({ id: key, ...data[key] }))
            .sort((a, b) => b.timestamp - a.timestamp);
          setLoanApplications(applications);
        } else {
            setLoanApplications([]);
        }
        setLoading(false);
      });
      return () => unsubscribe();
    } else {
      setLoading(false);
    }
  }, [user]);

  if (loading) return <Skeleton className="h-48 w-full" />;

  if (loanApplications.length === 0) return null; // Don't show the card if there are no applications

  return (
    <Card>
        <CardHeader>
            <CardTitle className="font-headline flex items-center gap-2">
                <Landmark /> My Home Loan Applications
            </CardTitle>
            <CardDescription>
                Track the status of your home loan applications here.
            </CardDescription>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Submitted On</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {loanApplications.map(app => (
                        <TableRow key={app.id}>
                            <TableCell>{format(new Date(app.timestamp), 'PPP')}</TableCell>
                            <TableCell>₹{app.loanAmount.toLocaleString('en-IN')}</TableCell>
                            <TableCell>{loanStatusToJsx(app.status)}</TableCell>
                            <TableCell className="text-right">
                                <Button variant="outline" size="sm" onClick={() => router.push(`/home-loan-token/${app.id}`)}>
                                    <FileText className="mr-2"/> View Token
                                </Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
    </Card>
  )
}


export default function ProfessionalDashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [userData, setUserData] = useState<{role: string; status: VerificationStatus; smnpId?: string} | null>(null);
  const [loading, setLoading] = useState(true);
  const [resendingEmail, setResendingEmail] = useState(false);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const userRef = ref(db, 'users/' + user.uid);
    const unsubscribe = onValue(userRef, (snapshot) => {
      if (snapshot.exists()) {
        setUserData(snapshot.val());
      } else {
        setUserData({ role: 'user', status: 'verified' });
      }
      setLoading(false);
    }, (error) => {
      console.error("Firebase read failed:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleResendVerificationEmail = async () => {
    if (!user) return;
    setResendingEmail(true);
    try {
        await sendEmailVerification(user);
        toast({
            title: "Verification Email Sent",
            description: "A new verification link has been sent to your email address.",
        });
    } catch (error: any) {
        toast({
            variant: "destructive",
            title: "Error",
            description: error.message || "Failed to send verification email. Please try again later.",
        });
    } finally {
        setResendingEmail(false);
    }
  };

  if (loading) {
     return (
        <div className="space-y-8">
            <PageHeader title="Loading Dashboard..." />
            <Card>
                <CardContent className="p-4">
                    <Skeleton className="h-24 w-full" />
                </CardContent>
            </Card>
             <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Skeleton className="h-40 w-full" />
                <Skeleton className="h-40 w-full" />
             </div>
        </div>
    )
  }

  const isProfessional = userData?.role === 'designer' || userData?.role === 'constructor' || userData?.role === 'supplier' || userData?.role === 'seller';
  const showVerificationPrompt = isProfessional && userData?.status === 'in-progress';
  const showPaymentPending = isProfessional && (userData?.status === 'payment-pending' || userData?.status === 'master-payment-pending');
  const showUpgradePrompt = isProfessional && userData?.status === 'verified';
  const isMaster = userData?.status === 'master';
  const smnpId = userData?.smnpId;

  const professionalLinks = [
    { href: "/professional-dashboard/inquiries", icon: MessageSquare, title: "My Inquiries", description: "View and manage messages from potential clients." },
    { href: "/professional-dashboard/profile/edit", icon: Pencil, title: "Edit Profile", description: "Keep your professional information up-to-date." },
    { href: "/professional-dashboard/my-bookings", icon: CalendarCheck, title: "My Consultations", description: "View and manage consultation requests." },
    { href: "/professional-dashboard/events", icon: CalendarDays, title: "My Events", description: "Manage your workshops, webinars, and other events."},
    { href: "/professional-dashboard/vr-order", icon: View, title: "VR Kit", description: "Order a VR kit to showcase your designs." },
    { href: "/professional-dashboard/banner", icon: Download, title: "Promotional Banner", description: "Download a banner with your professional details." },
    { href: "/professional-dashboard/marketing", icon: Annoyed, title: "Marketing Banners", description: "Download festive banners for your marketing." },
    { href: "/professional-dashboard/advertising", icon: Megaphone, title: "Advertising", description: "Create and manage ad campaigns to boost your visibility." },
  ];
  
  if (isMaster) {
      professionalLinks.push({ href: "/professional-dashboard/community", icon: Rss, title: "My Community", description: "Post updates to your followers." });
  }

  const userLinks = [
      { href: "/professional-dashboard/my-bookings", icon: CalendarCheck, title: "My Bookings", description: "View your booked consultation appointments." },
      { href: "/favorites", icon: Heart, title: "My Favorites", description: "View your saved designs and professionals." },
      { href: "/professional-dashboard/following", icon: Users, title: "Following", description: "See updates from professionals you follow." },
  ];

  const roleSpecificLinks: { [key: string]: { href: string; icon: React.ElementType; title: string; description: string; } | null } = {
      designer: { href: "/professional-dashboard/my-designs", icon: Paintbrush, title: "Manage My Designs", description: "Add, edit, and view your design products." },
      constructor: { href: "/professional-dashboard/projects/new", icon: PlusCircle, title: "Add New Project", description: "Showcase your completed work to clients." },
      supplier: { href: "/professional-dashboard/products/new", icon: PlusCircle, title: "Add New Product", description: "Add a new product to your public catalog." },
      seller: { href: "/professional-dashboard/properties/new", icon: Building, title: "Add New Property", description: "List a new property for sale in the marketplace." },
      user: null
  };
  
  if (userData?.role === 'seller') {
      roleSpecificLinks.seller_auction = { href: "/professional-dashboard/auctions/new", icon: Gavel, title: "Create Auction", description: "List a new property for auction." };
  }

  const linksToShow = isProfessional ? professionalLinks : userLinks;
  const specificLink = isProfessional && userData?.role ? roleSpecificLinks[userData.role] : null;
  const sellerAuctionLink = isProfessional && userData?.role === 'seller' ? roleSpecificLinks['seller_auction'] : null;


  return (
    <div className="space-y-8">
      <PageHeader
        title={isProfessional ? "Professional Dashboard" : "My Dashboard"}
        description="Manage your profile, consultations, and client interactions."
      />

        {user && !user.emailVerified && (
            <Card className="bg-yellow-50 border-yellow-300">
                <CardHeader>
                    <CardTitle className="font-headline flex items-center gap-2 text-yellow-900">
                        <Mail /> Please Verify Your Email
                    </CardTitle>
                    <CardDescription className="text-yellow-800">
                        A verification link has been sent to your email address. Please check your inbox and click the link to complete your registration.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Button onClick={handleResendVerificationEmail} disabled={resendingEmail}>
                        {resendingEmail ? <Loader2 className="mr-2 animate-spin"/> : null}
                        Resend Verification Email
                    </Button>
                </CardContent>
            </Card>
        )}

      {user && !isProfessional && <UserHomeLoanStatus />}

      {isProfessional && smnpId && (
        <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2 text-primary">
                    <Fingerprint /> Your SMNP Registration ID
                </CardTitle>
                <CardDescription>
                    This is your unique identification number on the Homelya platform.
                </CardDescription>
            </CardHeader>
            <CardContent>
                 <p className="text-2xl font-bold font-mono tracking-wider text-primary">
                    {smnpId}
                </p>
            </CardContent>
        </Card>
      )}

      {showVerificationPrompt && (
        <Card className="bg-amber-50 border-amber-200">
            <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2 text-amber-900">
                    <ShieldCheck /> Get Your Profile Verified
                </CardTitle>
                <CardDescription className="text-amber-800">
                    To get a 'Verified' badge and build trust, please complete the one-time verification payment.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    <div className="flex-1">
                        <p className="font-bold text-lg text-amber-900">One-Time Verification Fee</p>
                        <p className="text-3xl font-bold flex items-center text-amber-900">
                            <IndianRupee className="h-7 w-7"/>2,999
                        </p>
                    </div>
                    <Button asChild size="lg">
                        <Link href="/professional-dashboard/verify">
                            Pay & Get Verified
                        </Link>
                    </Button>
                </div>
            </CardContent>
        </Card>
      )}

      {showPaymentPending && (
        <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2 text-blue-900">
                    <Clock /> Payment in Progress
                </CardTitle>
                <CardDescription className="text-blue-800">
                    We have received your payment request. Your verification/upgrade is currently under review by our team.
                    No need to pay again. This can take up to 48 hours.
                </CardDescription>
            </CardHeader>
        </Card>
      )}
      
       {showUpgradePrompt && (
        <Card className="bg-purple-50 border-purple-200">
            <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2 text-purple-900">
                    <Gem /> Upgrade to Master Professional
                </CardTitle>
                <CardDescription className="text-purple-800">
                   Unlock premium features by upgrading your account.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid md:grid-cols-2 gap-6 items-center">
                    <div>
                         <h4 className="font-semibold mb-2 text-purple-900">Benefits include:</h4>
                         <ul className="space-y-2 text-sm text-purple-800">
                             <li className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-purple-600"/>Exclusive 'Master' Badge on Profile</li>
                             <li className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-purple-600"/>Profile Customization (Themes)</li>
                             <li className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-purple-600"/>Display Social Media Links</li>
                         </ul>
                    </div>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                        <div className="flex-1">
                            <p className="font-bold text-lg text-purple-900">Special Upgrade Price (First Year)</p>
                            <p className="text-3xl font-bold flex items-center text-purple-900">
                                <IndianRupee className="h-7 w-7"/>2,999
                            </p>
                        </div>
                        <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
                            <Link href="/professional-dashboard/verify">
                                Upgrade Now
                            </Link>
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
      )}
      
      {isMaster && (
        <Card className="bg-green-50 border-green-200">
            <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2 text-green-900">
                    <Gem /> Master Professional Subscription Active
                </CardTitle>
                <CardDescription className="text-green-800">
                    You have access to all premium features, including profile customization and community posts.
                </CardDescription>
            </CardHeader>
             <CardContent>
                <Button asChild variant="link" className="p-0 text-green-700">
                  <Link href="/professional-dashboard/profile/edit">
                    Customize Your Profile
                  </Link>
                </Button>
            </CardContent>
        </Card>
      )}


      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {linksToShow.map((link) => (
            <Card key={link.href}>
                <CardHeader>
                    <CardTitle className="font-headline">{link.title}</CardTitle>
                    <CardDescription>{link.description}</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                        <Link href={link.href}>
                            <link.icon className="mr-2"/> View {link.title.split(' ')[0]}
                        </Link>
                    </Button>
                </CardContent>
            </Card>
        ))}

        {specificLink && (
            <Card>
                <CardHeader>
                    <CardTitle className="font-headline">{specificLink.title}</CardTitle>
                    <CardDescription>{specificLink.description}</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                        <Link href={specificLink.href}>
                            <specificLink.icon className="mr-2"/> {specificLink.title.split('Add ')[1] || specificLink.title.split('Create ')[1] || 'Manage'}
                        </Link>
                    </Button>
                </CardContent>
            </Card>
        )}
         {sellerAuctionLink && (
            <Card>
                <CardHeader>
                    <CardTitle className="font-headline">{sellerAuctionLink.title}</CardTitle>
                    <CardDescription>{sellerAuctionLink.description}</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button asChild>
                        <Link href={sellerAuctionLink.href}>
                            <sellerAuctionLink.icon className="mr-2"/> {sellerAuctionLink.title.split('Add ')[1] || sellerAuctionLink.title.split('Create ')[1]}
                        </Link>
                    </Button>
                </CardContent>
            </Card>
        )}
      </div>
    </div>
  );
}
