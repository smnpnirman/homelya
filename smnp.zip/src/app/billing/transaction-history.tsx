

'use client';

import { useEffect, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, onValue, query, orderByChild } from 'firebase/database';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { CreditCard, IndianRupee } from 'lucide-react';
import type { Transaction } from '@/lib/types';

function transactionTypeToJsx(type: Transaction['type']) {
    switch (type) {
        case 'payment':
            return <Badge variant="secondary">Payment</Badge>;
        case 'purchase':
            return <Badge variant="default">Purchase</Badge>;
        case 'refund':
            return <Badge variant="outline">Refund</Badge>;
        default:
            return <Badge variant="outline">{type}</Badge>;
    }
}

function transactionStatusToJsx(status: Transaction['status']) {
    switch(status) {
        case 'completed':
             return <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700">Completed</Badge>;
        case 'pending':
            return <Badge variant="secondary" className="border-amber-500/50 bg-amber-500/10 text-amber-700">Pending</Badge>;
        case 'failed':
            return <Badge variant="destructive">Failed</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
}

export default function TransactionHistory({ userId }: { userId: string }) {
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        const transactionsQuery = query(ref(db, `transactions/${userId}`), orderByChild('timestamp'));
        const unsubscribe = onValue(transactionsQuery, (snapshot) => {
            const data = snapshot.val();
            const transactionsList: Transaction[] = data ? Object.keys(data).map(key => ({
                id: key,
                ...data[key],
            })).sort((a,b) => b.timestamp - a.timestamp) : [];
            setTransactions(transactionsList);
            setLoading(false);
        });

        return () => unsubscribe();
    }, [userId]);

    return (
        <Card>
            <CardHeader>
                <CardTitle className="font-headline">Transaction History</CardTitle>
                <CardDescription>A record of all your payments and purchases on the platform.</CardDescription>
            </CardHeader>
            <CardContent>
                 <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Date</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Status</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {loading ? (
                            Array.from({length: 3}).map((_, i) => (
                                <TableRow key={i}>
                                    <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-48" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                </TableRow>
                            ))
                        ) : transactions.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={5} className="h-48 text-center">
                                    <div className="flex flex-col items-center gap-4">
                                        <CreditCard className="h-12 w-12 text-muted-foreground" />
                                        <h3 className="font-semibold text-lg">No transactions yet.</h3>
                                        <p className="text-muted-foreground">Your payment history will appear here.</p>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ) : (
                            transactions.map(tx => (
                                <TableRow key={tx.id}>
                                    <TableCell>{format(new Date(tx.timestamp), 'PPP')}</TableCell>
                                    <TableCell className="font-medium">{tx.description}</TableCell>
                                    <TableCell className="font-semibold flex items-center">
                                        <IndianRupee className="h-3.5 w-3.5 -ml-1"/>
                                        {tx.amount.toLocaleString('en-IN')}
                                    </TableCell>
                                    <TableCell>{transactionTypeToJsx(tx.type)}</TableCell>
                                    <TableCell>{transactionStatusToJsx(tx.status)}</TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}
