

'use client';

import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import TransactionHistory from "./transaction-history";
import { useAuth } from "@/hooks/use-auth";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function BillingPage() {
    const { user } = useAuth();

    if (!user) {
        return (
             <div className="text-center py-12">
                <Card className="max-w-md mx-auto">
                    <CardHeader>
                        <CardTitle className="font-headline text-2xl">Access Denied</CardTitle>
                        <CardDescription>You must be logged in to view your billing information.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button asChild>
                            <Link href="/login">Login</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Billing Information"
        description="Review your transaction history and manage your payments."
      />
      
      <TransactionHistory userId={user.uid} />
    </div>
  );
}
