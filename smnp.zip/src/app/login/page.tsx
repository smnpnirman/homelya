

'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { useRouter, useSearchParams } from 'next/navigation';
import { 
  signInWithEmailAndPassword, 
  GoogleAuthProvider, 
  signInWithRedirect, 
  getRedirectResult, 
  type User,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  type ConfirmationResult
} from 'firebase/auth';
import { auth, db } from '@/lib/firebase';
import { useState, Suspense, useEffect } from 'react';
import Image from 'next/image';
import { Separator } from '@/components/ui/separator';
import { ref, set, get } from 'firebase/database';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';


const emailFormSchema = z.object({
  email: z.string().email({ message: 'Please enter a valid email.' }),
  password: z.string().min(1, { message: 'Password is required.' }),
});

const phoneFormSchema = z.object({
  phone: z.string().regex(/^[6-9]\d{9}$/, 'Please enter a valid 10-digit Indian mobile number.'),
});

const otpFormSchema = z.object({
  otp: z.string().length(6, 'OTP must be 6 digits.'),
});


const GoogleIcon = () => (
    <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24">
        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"></path>
        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"></path>
        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"></path>
        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"></path>
    </svg>
);

async function handleAuthSuccess(user: User, router: any, toast: any, redirectUrl: string | null) {
  const userRef = ref(db, `users/${user.uid}`);
  const snapshot = await get(userRef);

  if (!snapshot.exists()) {
    // This is a first-time sign-in (likely from Google), create a DB entry.
    await set(userRef, {
      displayName: user.displayName || user.email || "New User",
      email: user.email,
      phone: user.phoneNumber || "",
      country: 'india', // Default
      state: '',
      city: '',
      location: 'Not specified',
      pincode: '',
      role: 'user', 
      status: 'verified',
      consultationsUsed: 0,
    });
    toast({
        title: 'Welcome!',
        description: 'Your account has been created.',
    });
  }

  // Fetch the latest user data after potential creation
  const userDataSnapshot = await get(userRef);
  const userData = userDataSnapshot.val();
  
  const isAdmin = userData?.role === 'admin';
  const isProfessional = userData?.role === 'designer' || userData?.role === 'constructor' || userData?.role === 'supplier' || userData?.role === 'seller';

  if (redirectUrl) {
    router.push(redirectUrl);
  } else if (isAdmin) {
    router.push('/admin');
  } else if (isProfessional || userData?.role === 'user') {
    router.push('/professional-dashboard');
  } else {
    router.push('/');
  }
}


function LoginPageContent() {
  const { toast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [phoneLoading, setPhoneLoading] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [otpSent, setOtpSent] = useState(false);

  const emailForm = useForm<z.infer<typeof emailFormSchema>>({
    resolver: zodResolver(emailFormSchema),
    defaultValues: { email: '', password: '' },
  });

  const phoneForm = useForm<z.infer<typeof phoneFormSchema>>({
    resolver: zodResolver(phoneFormSchema),
    defaultValues: { phone: '' }
  });

  const otpForm = useForm<z.infer<typeof otpFormSchema>>({
    resolver: zodResolver(otpFormSchema),
    defaultValues: { otp: '' }
  });

  useEffect(() => {
    const handleRedirectResult = async () => {
        try {
            const result = await getRedirectResult(auth);
            if (result) {
                setGoogleLoading(true);
                const redirectUrl = searchParams.get('redirect');
                await handleAuthSuccess(result.user, router, toast, redirectUrl);
            }
        } catch (error: any) {
            console.error('Google Sign-In failed:', error);
            toast({
                variant: 'destructive',
                title: 'Google Sign-In Failed',
                description: error.message || 'An unknown error occurred.',
            });
        } finally {
            setGoogleLoading(false);
        }
    };
    handleRedirectResult();
  }, [router, searchParams, toast]);


  const onEmailSubmit = async (values: z.infer<typeof emailFormSchema>) => {
    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, values.email, values.password);
      const redirectUrl = searchParams.get('redirect');
      await handleAuthSuccess(userCredential.user, router, toast, redirectUrl);
    } catch (error: any) {
      console.error('Login failed:', error);
      toast({
        variant: 'destructive',
        title: 'Login Failed',
        description: error.message || 'An unknown error occurred.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    const provider = new GoogleAuthProvider();
    await signInWithRedirect(auth, provider);
  }

  const handlePhoneSignIn = async (values: z.infer<typeof phoneFormSchema>) => {
    setPhoneLoading(true);
    try {
      const appVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        'size': 'invisible',
        'callback': (response: any) => {
          // reCAPTCHA solved, allow signInWithPhoneNumber.
        }
      });
      const formattedPhoneNumber = `+91${values.phone}`;
      const confirmation = await signInWithPhoneNumber(auth, formattedPhoneNumber, appVerifier);
      setConfirmationResult(confirmation);
      setOtpSent(true);
      toast({
        title: 'OTP Sent',
        description: `An OTP has been sent to ${formattedPhoneNumber}.`,
      });
    } catch (error: any) {
      console.error('Phone sign-in error:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to Send OTP',
        description: error.message || 'Please check the phone number and try again.',
      });
    } finally {
      setPhoneLoading(false);
    }
  };

  const handleVerifyOtp = async (values: z.infer<typeof otpFormSchema>) => {
    if (!confirmationResult) return;
    setPhoneLoading(true);
    try {
      const userCredential = await confirmationResult.confirm(values.otp);
      const redirectUrl = searchParams.get('redirect');
      await handleAuthSuccess(userCredential.user, router, toast, redirectUrl);
    } catch (error: any) {
      console.error('OTP verification failed:', error);
      toast({
        variant: 'destructive',
        title: 'Invalid OTP',
        description: 'The OTP you entered is incorrect. Please try again.',
      });
    } finally {
      setPhoneLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-8rem)] w-full items-center justify-center p-4">
      <div className="grid w-full max-w-4xl grid-cols-1 md:grid-cols-2 overflow-hidden rounded-lg border shadow-lg">
        <div className="hidden md:block relative">
           <Image 
            src="https://picsum.photos/600/800"
            alt="Modern house"
            width={600}
            height={800}
            className="object-cover w-full h-full"
            data-ai-hint="modern architecture"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent p-8 flex flex-col justify-end">
            <h2 className="font-headline text-3xl font-bold text-white">Your Dream Home Awaits</h2>
            <p className="text-white/80 mt-2">Log in to access your personalized plans and saved favorites.</p>
          </div>
        </div>
        <div className="p-8 bg-card">
          <Card className="border-0 shadow-none">
            
            <CardHeader className="text-center p-0 mb-8">
              <CardTitle className="font-headline text-2xl">Welcome Back</CardTitle>
              <CardDescription>Sign in to access your account.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
               <div id="recaptcha-container"></div>
               <Tabs defaultValue="email" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="email">Email</TabsTrigger>
                        <TabsTrigger value="phone">Phone OTP</TabsTrigger>
                    </TabsList>
                    <TabsContent value="email" className="pt-4">
                        <Button variant="outline" className="w-full" onClick={handleGoogleSignIn} disabled={googleLoading}>
                            {googleLoading ? <Loader2 className="animate-spin" /> : <><GoogleIcon /> Continue with Google</>}
                        </Button>
                        <div className="my-4 flex items-center">
                            <Separator className="flex-1" />
                            <span className="mx-4 text-xs text-muted-foreground">OR</span>
                            <Separator className="flex-1" />
                        </div>
                        <Form {...emailForm}>
                            <form onSubmit={emailForm.handleSubmit(onEmailSubmit)} className="space-y-4">
                                <FormField
                                control={emailForm.control}
                                name="email"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Email</FormLabel>
                                    <FormControl>
                                        <Input placeholder="you@example.com" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                                />
                                <FormField
                                control={emailForm.control}
                                name="password"
                                render={({ field }) => (
                                    <FormItem>
                                    <div className="flex items-center justify-between">
                                        <FormLabel>Password</FormLabel>
                                        <Link href="/forgot-password" className="text-sm font-medium text-primary hover:underline" tabIndex={-1}>
                                        Forgot Password?
                                        </Link>
                                    </div>
                                    <FormControl>
                                        <Input type="password" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                                />
                                <Button type="submit" className="w-full" disabled={loading}>
                                    {loading ? <Loader2 className="animate-spin" /> : 'Log In'}
                                </Button>
                            </form>
                        </Form>
                    </TabsContent>
                    <TabsContent value="phone" className="pt-4">
                        {!otpSent ? (
                            <Form {...phoneForm}>
                                <form onSubmit={phoneForm.handleSubmit(handlePhoneSignIn)} className="space-y-6">
                                    <FormField
                                        control={phoneForm.control}
                                        name="phone"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Mobile Number</FormLabel>
                                                <div className="flex items-center">
                                                    <span className="inline-flex items-center px-3 h-10 rounded-l-md border border-r-0 border-input bg-background text-sm">+91</span>
                                                    <FormControl>
                                                        <Input placeholder="9876543210" {...field} className="rounded-l-none" />
                                                    </FormControl>
                                                </div>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <Button type="submit" className="w-full" disabled={phoneLoading}>
                                        {phoneLoading ? <Loader2 className="animate-spin" /> : 'Send OTP'}
                                    </Button>
                                </form>
                            </Form>
                        ) : (
                            <Form {...otpForm}>
                                <form onSubmit={otpForm.handleSubmit(handleVerifyOtp)} className="space-y-6">
                                    <FormField
                                        control={otpForm.control}
                                        name="otp"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Enter OTP</FormLabel>
                                                <FormControl>
                                                    <Input placeholder="Enter 6-digit OTP" {...field} />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <Button type="submit" className="w-full" disabled={phoneLoading}>
                                        {phoneLoading ? <Loader2 className="animate-spin" /> : 'Verify & Log In'}
                                    </Button>
                                </form>
                            </Form>
                        )}
                    </TabsContent>
                </Tabs>
            </CardContent>
            <CardFooter className="flex flex-col gap-4 p-0 mt-4 text-center">
              <p className="text-sm text-muted-foreground">
                New user?{' '}
                <Link href="/signup" className="font-semibold text-primary hover:underline">
                  Sign Up
                </Link>
              </p>
               <p className="text-sm text-muted-foreground">
                Professional?{' '}
                <Link href="/professional-auth/signup" className="font-semibold text-primary hover:underline">
                  Register as a Professional
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <LoginPageContent />
    </Suspense>
  )
}
