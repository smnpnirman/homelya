'use client';

import { useParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { db } from '@/lib/firebase';
import { ref, get } from 'firebase/database';
import PageHeader from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { Loader2, Download, CheckCircle, Calendar as CalendarIcon, User as UserIcon, Mail as MailIcon, FileText, Ticket as TicketIcon, MapPin, Globe } from 'lucide-react';
import Logo from '@/components/logo';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import html2canvas from 'html2canvas';
import type { AppEvent, EventBooking } from '@/lib/types';
import NextImage from 'next/image';


export default function EventTicketPage() {
  const params = useParams();
  const bookingId = params.id as string;
  const [booking, setBooking] = useState<EventBooking | null>(null);
  const [appEvent, setAppEvent] = useState<AppEvent | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const ticketRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!bookingId) return;

    const fetchBookingAndEvent = async () => {
      setLoading(true);
      try {
        const bookingRef = ref(db, `bookings/${bookingId}`);
        const bookingSnapshot = await get(bookingRef);
        if (bookingSnapshot.exists()) {
          const bookingData = { id: bookingId, ...bookingSnapshot.val() } as EventBooking;
          setBooking(bookingData);

          const eventRef = ref(db, `events/${bookingData.eventId}`);
          const eventSnapshot = await get(eventRef);
           if (eventSnapshot.exists()) {
               setAppEvent({ id: bookingData.eventId, ...eventSnapshot.val() });
           }

        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBookingAndEvent();
  }, [bookingId]);
  
  const handleDownload = async () => {
    if (!ticketRef.current) return;
    setDownloading(true);
    try {
        const canvas = await html2canvas(ticketRef.current, { 
            backgroundColor: null,
            scale: 2,
        });
        const link = document.createElement('a');
        link.download = `homelya-event-ticket-${bookingId}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
    } catch(error) {
        console.error("Error downloading ticket:", error);
    } finally {
        setDownloading(false);
    }
  };

  const handleEmailTicket = () => {
    if (!booking || !appEvent) return;

    const subject = `Your Ticket for: ${appEvent.name}`;
    const body = `
Hello ${booking.userName},

Thank you for booking your ticket for "${appEvent.name}".

Event Details:
- Date: ${format(new Date(appEvent.eventDate), 'PPP')}
- Location: ${appEvent.locationOrUrl}

You can view and download your ticket anytime from this link:
${window.location.href}

We look forward to seeing you there!

Regards,
The Homelya Team
    `;

    const mailtoLink = `mailto:${booking.userEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body.trim())}`;
    
    window.location.href = mailtoLink;
  };

  const formattedTicketId = `EVT-${bookingId.slice(-6).toUpperCase()}`;

  if (loading) {
    return (
        <div className="space-y-8 max-w-lg mx-auto">
            <PageHeader title="Loading Your Ticket..." />
            <Card>
                <CardContent className="p-8">
                    <Skeleton className="h-[500px] w-full" />
                </CardContent>
            </Card>
        </div>
    )
  }

  if (!booking || !appEvent) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Ticket Not Found</h2>
        <p className="text-muted-foreground">The event ticket you are looking for does not exist.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-lg mx-auto">
      <PageHeader
        title="Booking Confirmed!"
        description="Here is your ticket. Present this at the event."
      />
      <div 
        ref={ticketRef} 
        className="bg-card border rounded-2xl shadow-lg overflow-hidden"
      >
        <div className="p-6 bg-gradient-to-br from-primary/10 to-transparent">
            <div className="flex justify-between items-center">
                <Logo />
                <div className="text-right">
                    <p className="font-semibold text-primary">ADMIT ONE</p>
                    <p className="text-xs text-muted-foreground">Event Ticket</p>
                </div>
            </div>
        </div>
        <div className="p-6">
            <div className="grid grid-cols-3 gap-6">
                <div className="col-span-2 space-y-4">
                    <div>
                        <p className="text-sm text-muted-foreground">EVENT</p>
                        <h2 className="font-bold text-xl font-headline">{booking.eventTitle}</h2>
                    </div>
                    <div>
                        <p className="text-sm text-muted-foreground">ATTENDEE</p>
                        <h3 className="font-semibold">{booking.userName}</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                         <div>
                            <p className="text-sm text-muted-foreground">DATE</p>
                            <p className="font-semibold flex items-center gap-2"><CalendarIcon className="h-4 w-4 text-primary"/> {format(new Date(appEvent.eventDate), 'PPP')}</p>
                        </div>
                        <div>
                            <p className="text-sm text-muted-foreground">LOCATION</p>
                            <p className="font-semibold flex items-center gap-2 text-sm">
                                {appEvent.eventType === 'offline' ? <MapPin className="h-4 w-4 text-primary"/> : <Globe className="h-4 w-4 text-primary"/>}
                                {appEvent.locationOrUrl}
                            </p>
                        </div>
                    </div>
                </div>
                <div className="col-span-1 flex flex-col items-center justify-center border-l-2 border-dashed pl-6">
                    <NextImage 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${formattedTicketId}`}
                        alt="Ticket QR Code"
                        width={120}
                        height={120}
                        className="rounded-md border p-1"
                    />
                     <p className="text-xs text-muted-foreground mt-2 text-center">Scan at entry</p>
                     <p className="font-semibold font-mono text-sm mt-2">{formattedTicketId}</p>
                </div>
            </div>
        </div>
        <div className="bg-muted/50 px-6 py-2 text-center text-xs text-muted-foreground">
            Booked on: {format(new Date(booking.timestamp), 'PPP p')}
        </div>
      </div>

      <div className="text-center space-x-4">
        <Button size="lg" onClick={handleDownload} disabled={downloading}>
            {downloading ? <Loader2 className="mr-2 animate-spin" /> : <Download className="mr-2" />}
            {downloading ? "Downloading..." : "Download Ticket"}
        </Button>
         <Button size="lg" variant="outline" onClick={handleEmailTicket}>
            <MailIcon className="mr-2" />
            Email to Myself
        </Button>
      </div>
    </div>
  );
}
