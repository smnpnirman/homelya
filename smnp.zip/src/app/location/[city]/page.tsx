
'use client';

import { useState, useMemo, useEffect } from 'react';
import PageHeader from '@/components/page-header';
import ProfessionalListItem from '@/components/professional-list-item';
import { db } from '@/lib/firebase';
import { ref, onValue } from 'firebase/database';
import type { Provider, Supplier } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { useParams } from 'next/navigation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

type Professional = (Provider | Supplier) & { role: string };

export default function LocationPage() {
  const params = useParams();
  const city = typeof params.city === 'string' ? params.city : '';
  
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!city) return;

    setLoading(true);
    
    const usersRef = ref(db, 'users');
    const unsubscribe = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const allProfessionals: Professional[] = Object.keys(data)
          .map(key => {
            const user = data[key];
            if (user.role === 'designer' || user.role === 'constructor' || user.role === 'supplier') {
              return {
                id: key,
                name: user.companyName,
                specialty: user.specialty || (user.role === 'supplier' ? user.category : 'Not specified'),
                category: user.category, // for suppliers
                location: user.location || 'Not specified',
                description: user.description || 'No description available.',
                image: user.image || 'https://placehold.co/400x400.png',
                dataAiHint: 'professional portrait',
                rating: 4.5 + Math.random() * 0.5,
                role: user.role,
                status: user.status,
                phone: user.phone,
              }
            }
            return null;
          })
          .filter((p): p is Professional => p !== null);
          
        const filtered = allProfessionals.filter(p => p.location.toLowerCase() === city.toLowerCase());
        setProfessionals(filtered);

      } else {
        setProfessionals([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [city]);
  
  const designers = useMemo(() => professionals.filter(p => p.role === 'designer'), [professionals]);
  const constructors = useMemo(() => professionals.filter(p => p.role === 'constructor'), [professionals]);
  const suppliers = useMemo(() => professionals.filter(p => p.role === 'supplier'), [professionals]);

  const renderSkeletons = () => (
    Array.from({ length: 3 }).map((_, i) => (
      <Skeleton key={i} className="h-48 w-full" />
    ))
  );

  return (
    <div className="space-y-8">
      <PageHeader 
        title={`Professionals in ${city.charAt(0).toUpperCase() + city.slice(1)}`}
        description={`Browse designers, constructors, and suppliers available in your selected city.`}
      />
      
      <Tabs defaultValue="designers" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="designers">Designers ({designers.length})</TabsTrigger>
            <TabsTrigger value="constructors">Constructors ({constructors.length})</TabsTrigger>
            <TabsTrigger value="suppliers">Suppliers ({suppliers.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="designers" className="space-y-6 mt-6">
            {loading ? renderSkeletons() : designers.map((item) => (
                <ProfessionalListItem key={item.id} professional={item as Provider} itemType="designer" />
            ))}
            {!loading && designers.length === 0 && <p className="text-center text-muted-foreground py-8">No designers found in this city.</p>}
        </TabsContent>
        <TabsContent value="constructors" className="space-y-6 mt-6">
            {loading ? renderSkeletons() : constructors.map((item) => (
                <ProfessionalListItem key={item.id} professional={item as Provider} itemType="constructor" />
            ))}
            {!loading && constructors.length === 0 && <p className="text-center text-muted-foreground py-8">No constructors found in this city.</p>}
        </TabsContent>
        <TabsContent value="suppliers" className="space-y-6 mt-6">
            {loading ? renderSkeletons() : suppliers.map((item) => (
                <ProfessionalListItem key={item.id} professional={item as Supplier} itemType="supplier" />
            ))}
            {!loading && suppliers.length === 0 && <p className="text-center text-muted-foreground py-8">No suppliers found in this city.</p>}
        </TabsContent>
      </Tabs>
    </div>
  );
}
