

'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { ExternalLink, Loader2, Globe, Map } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { createUserWithEmailAndPassword, updateProfile, sendEmailVerification } from 'firebase/auth';
import { auth, db } from '@/lib/firebase';
import { ref, set } from "firebase/database";
import { useState } from 'react';
import Image from 'next/image';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const indianStates = [
  "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", 
  "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", 
  "Jharkhand", "Karnataka", "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", 
  "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", 
  "Uttar Pradesh", "Uttarakhand", "West Bengal"
].sort();


const formSchema = z.object({
  companyName: z.string().min(2, { message: 'Company name must be at least 2 characters.' }),
  email: z.string().email({ message: 'Please enter a valid email.' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters.' }),
  role: z.enum(['designer', 'constructor', 'supplier', 'seller', 'broker'], {
    required_error: "Please select a role.",
  }),
  phone: z.string().min(9, { message: 'Please enter a valid phone number.' }),
  country: z.enum(['india', 'dubai']),
  state: z.string().optional(),
  city: z.string().min(2, { message: "City is required." }),
  pincode: z.string().optional(),
  gstNumber: z.string().optional(),
  specialty: z.string().min(2, { message: 'Specialty must be at least 2 characters.' }),
  description: z.string().min(20, { message: 'Description must be at least 20 characters.' }),
  upiId: z.string().min(3, { message: "Please enter a valid UPI ID."}).regex(/^[\w.-]+@[\w.-]+$/, { message: 'Please enter a valid UPI ID format (e.g., yourname@bank).' }),
  website: z.string().url({ message: 'Please enter a valid URL.' }).optional().or(z.literal('')),
  image: z.string().url({ message: "Please enter a valid image URL." }).optional().or(z.literal('')),
  architectureRegistrationNumber: z.string().optional(),
  localAuthorityRegistrationNumber: z.string().optional(),
}).superRefine((data, ctx) => {
    if (data.role === 'designer') {
        const hasArchReg = data.architectureRegistrationNumber && data.architectureRegistrationNumber.trim() !== '';
        const hasLocalReg = data.localAuthorityRegistrationNumber && data.localAuthorityRegistrationNumber.trim() !== '';

        if (!hasArchReg && !hasLocalReg) {
             ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'Either an Architecture or Local Authority Registration Number is required for designers.',
                path: ['architectureRegistrationNumber'],
            });
             ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'Either an Architecture or Local Authority Registration Number is required for designers.',
                path: ['localAuthorityRegistrationNumber'],
            });
        }
        
        if (hasArchReg && !/^CA\/\d{4}\/\d+$/.test(data.architectureRegistrationNumber!)) {
             ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'Format must be CA/YYYY/NNNN...',
                path: ['architectureRegistrationNumber'],
            });
        }
    }
    if (data.country === 'india' && !data.state) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'State is required for registrations in India.',
            path: ['state'],
        });
    }
    if (data.country === 'india' && data.pincode && !/^\d{6}$/.test(data.pincode)) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'Please enter a valid 6-digit Indian pincode.',
            path: ['pincode'],
        });
    }
});


export default function ProfessionalSignupPage() {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [country, setCountry] = useState<'india' | 'dubai' | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      companyName: '',
      email: '',
      password: '',
      phone: '',
      city: '',
      pincode: '',
      gstNumber: '',
      specialty: '',
      description: '',
      upiId: '',
      website: '',
      image: '',
      architectureRegistrationNumber: '',
      localAuthorityRegistrationNumber: '',
    }
  });
  
  const watchRole = form.watch('role');
  const watchImage = form.watch('image');

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, values.email, values.password);
      const user = userCredential.user;
      
      await updateProfile(user, {
          displayName: values.companyName
      });
      
      await sendEmailVerification(user);

      const fullPhoneNumber = `${values.country === 'india' ? '+91' : '+971'}${values.phone}`;

      const dbValues = {
        companyName: values.companyName,
        displayName: values.companyName,
        email: values.email,
        role: values.role,
        phone: fullPhoneNumber,
        country: values.country,
        state: values.state || null,
        city: values.city,
        location: values.city, // Main location field is city
        pincode: values.pincode || null,
        gstNumber: values.gstNumber || null,
        specialty: values.specialty,
        description: values.description,
        status: 'in-progress',
        upiId: values.upiId,
        website: values.website || null,
        image: values.image || null,
        architectureRegistrationNumber: values.architectureRegistrationNumber || null,
        localAuthorityRegistrationNumber: values.localAuthorityRegistrationNumber || null,
      };
      
      await set(ref(db, `users/${user.uid}`), dbValues);
      
      toast({
        title: 'Professional Account Created',
        description: 'Your profile is under review. Please check your email to verify your account.',
      });
      router.push('/professional-dashboard');
    } catch (error: any) {
      console.error('Signup failed:', error);
      toast({
        variant: 'destructive',
        title: 'Signup Failed',
        description: error.message || 'An unknown error occurred.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSetCountry = (selectedCountry: 'india' | 'dubai') => {
      setCountry(selectedCountry);
      form.setValue('country', selectedCountry);
  }

  if (!country) {
      return (
        <div className="flex min-h-[calc(100vh-8rem)] w-full items-center justify-center p-4">
            <div className="w-full max-w-lg overflow-hidden">
                <Card className="border-0 md:border md:shadow-lg">
                  <CardHeader className="text-center p-8">
                    <CardTitle className="font-headline text-2xl">Become a Partner</CardTitle>
                    <CardDescription>First, please tell us where you are registering from.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 p-8 pt-0">
                    <Button className="w-full h-16 text-lg" onClick={() => handleSetCountry('india')}>
                      <Map className="mr-4" /> Register from India
                    </Button>
                    <Button className="w-full h-16 text-lg" onClick={() => handleSetCountry('dubai')}>
                      <Globe className="mr-4" /> Register from Dubai
                    </Button>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-4 p-8 pt-0">
                      <p className="text-sm text-center text-muted-foreground">
                      Already have a professional account?{' '}
                      <Link href="/login" className="font-semibold text-primary hover:underline">
                          Log In
                      </Link>
                      </p>
                  </CardFooter>
                </Card>
            </div>
        </div>
      );
  }

  return (
    <div className="flex min-h-full w-full items-center justify-center p-4">
      <div className="grid w-full max-w-4xl grid-cols-1 md:grid-cols-2 overflow-hidden rounded-lg border shadow-lg">
        <div className="hidden md:block relative">
           <Image 
            src="https://picsum.photos/600/800"
            alt="Construction worker"
            width={600}
            height={800}
            className="object-cover w-full h-full"
            data-ai-hint="construction worker helmet"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent p-8 flex flex-col justify-end">
            <h2 className="font-headline text-3xl font-bold text-white">Join Our Network</h2>
            <p className="text-white/80 mt-2">Register as a professional to reach new clients and grow your business.</p>
          </div>
        </div>
        <div className="p-8 bg-card">
            <Card className="border-0 shadow-none">
              <CardHeader className="text-center p-0 mb-4">
                <CardTitle className="font-headline text-2xl">Become a Partner</CardTitle>
                <CardDescription>Create your professional account to get started.</CardDescription>
                <Button variant="link" onClick={() => setCountry(null)}>Change Country</Button>
              </CardHeader>
              <CardContent className="space-y-4 p-0">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="companyName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Jharkhand Builders" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FormField
                            control={form.control}
                            name="role"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>I am a...</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select profession" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    <SelectItem value="designer">Designer / Architect</SelectItem>
                                    <SelectItem value="constructor">Constructor / Builder</SelectItem>
                                    <SelectItem value="supplier">Material Supplier</SelectItem>
                                    <SelectItem value="seller">Property Seller</SelectItem>
                                    <SelectItem value="broker">Broker</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="specialty"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Specialty / Category</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., Residential Homes" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                      </div>
                       {watchRole === 'designer' && (
                          <>
                            <FormField
                                control={form.control}
                                name="architectureRegistrationNumber"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Architecture Registration Number</FormLabel>
                                    <FormControl>
                                    <Input placeholder="CA/YYYY/NNNNNN" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                            <div className="text-center text-xs text-muted-foreground">OR</div>
                            <FormField
                                control={form.control}
                                name="localAuthorityRegistrationNumber"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Local Authority Registration No.</FormLabel>
                                    <FormControl>
                                    <Input placeholder="e.g., RMC/123/2024" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                          </>
                        )}
                       <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company Description</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Describe your company..." {...field} rows={3}/>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       <FormField
                          control={form.control}
                          name="website"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Website URL (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="https://yourcompany.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                            control={form.control}
                            name="image"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Company Logo/Image URL (Optional)</FormLabel>
                                <div className="flex gap-2">
                                <FormControl>
                                    <Input placeholder="https://example.com/logo.png" {...field} />
                                </FormControl>
                                {watchImage && (
                                  <Button asChild variant="ghost" size="icon">
                                    <Link href={watchImage} target="_blank">
                                      <ExternalLink className="h-4 w-4" />
                                    </Link>
                                  </Button>
                                )}
                                </div>
                                {watchImage && (
                                    <div className="mt-2">
                                        <Image src={watchImage} alt="Image preview" width={100} height={100} className="rounded-md object-cover" />
                                    </div>
                                )}
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contact Number</FormLabel>
                                <div className="flex items-center">
                                    <span className="inline-flex items-center px-3 h-10 rounded-l-md border border-r-0 border-input bg-background text-sm">
                                        {country === 'india' ? '+91' : '+971'}
                                    </span>
                                    <FormControl>
                                      <Input placeholder={country === 'india' ? "9876543210" : "501234567"} {...field} className="rounded-l-none" />
                                    </FormControl>
                                </div>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                           <FormField
                            control={form.control}
                            name="city"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>City</FormLabel>
                                <FormControl>
                                <Input placeholder={country === 'india' ? "e.g., Ranchi" : "e.g., Dubai"} {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                           />
                      </div>
                       {country === 'india' && (
                         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                           <FormField
                                control={form.control}
                                name="state"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>State</FormLabel>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select State" />
                                        </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                        {indianStates.map(loc => <SelectItem key={loc} value={loc}>{loc}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                            control={form.control}
                            name="pincode"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Pincode (Optional)</FormLabel>
                                <FormControl>
                                    <Input placeholder="e.g., 834001" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        </div>
                       )}
                        <FormField
                          control={form.control}
                          name="gstNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>GST / TRN (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder={country === 'india' ? "e.g., 20AAAAA0000A1Z5" : "e.g., 100..."} {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      <FormField
                        control={form.control}
                        name="upiId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>UPI ID for Payments</FormLabel>
                            <FormControl>
                              <Input placeholder="your-upi-id@bank" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Business Email</FormLabel>
                            <FormControl>
                              <Input placeholder="you@yourcompany.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full" disabled={loading}>
                        {loading ? <Loader2 className="animate-spin" /> : 'Create Professional Account'}
                      </Button>
                    </form>
                  </Form>
              </CardContent>
              <CardFooter className="flex flex-col gap-4 p-0 pt-4">
                <p className="text-sm text-center text-muted-foreground">
                  Already have a professional account?{' '}
                  <Link href="/login" className="font-semibold text-primary hover:underline">
                    Log In
                  </Link>
                </p>
              </CardFooter>
            </Card>
        </div>
      </div>
    </div>
  );
}
