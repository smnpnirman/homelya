
'use client';

import { useParams, useRouter } from 'next/navigation';
import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, IndianRupee, LogIn, Loader2, CheckCircle, Tag } from 'lucide-react';
import Image from 'next/image';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';
import { useEffect, useState } from 'react';
import type { Design, Offer } from '@/lib/types';
import { db } from '@/lib/firebase';
import { ref, get, set, push, serverTimestamp } from 'firebase/database';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';

export default function PaymentPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const { user, userData } = useAuth();
  const isDubai = userData?.country === 'dubai';
  const designId = params.designId as string;

  const [design, setDesign] = useState<Design | null>(null);
  const [loading, setLoading] = useState(true);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [transactionId, setTransactionId] = useState('');

  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [finalPrice, setFinalPrice] = useState<number | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);

  const upiId = '6204910508@mbk';
  const payeeName = 'Homelya';

  useEffect(() => {
    if (!designId) return;
    const fetchDesign = async () => {
      setLoading(true);
      const designRef = ref(db, `designs/${designId}`);
      try {
        const snapshot = await get(designRef);
        if (snapshot.exists()) {
          const designData = { id: designId, ...snapshot.val() };
          setDesign(designData);
          setFinalPrice(designData.price || 50000);
        }
      } catch (error) {
        console.error("Error fetching design for payment:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchDesign();
  }, [designId]);

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) {
        toast({ variant: "destructive", title: "Please enter a coupon code." });
        return;
    }
    setCouponLoading(true);
    try {
        const offersRef = ref(db, 'offers');
        const snapshot = await get(offersRef);
        if (snapshot.exists()) {
            const offers: Record<string, Offer> = snapshot.val();
            const foundOffer = Object.values(offers).find(offer => offer.code === couponCode);
            
            if (foundOffer) {
                if (new Date(foundOffer.expiryDate) < new Date()) {
                    toast({ variant: "destructive", title: "Coupon Expired", description: "This coupon is no longer valid." });
                    setDiscount(0);
                    setFinalPrice(design?.price || 50000);
                } else if (foundOffer.applicableOn.toLowerCase().includes('design')) {
                    const originalPrice = design?.price || 50000;
                    const discountAmount = originalPrice * (foundOffer.discountPercentage / 100);
                    setFinalPrice(originalPrice - discountAmount);
                    setDiscount(foundOffer.discountPercentage);
                    toast({ title: "Coupon Applied!", description: `You got a ${foundOffer.discountPercentage}% discount.` });
                } else {
                    toast({ variant: "destructive", title: "Invalid Coupon", description: "This coupon is not applicable for designs." });
                }
            } else {
                 toast({ variant: "destructive", title: "Invalid Coupon", description: "The coupon code you entered is not valid." });
                 setDiscount(0);
                 setFinalPrice(design?.price || 50000);
            }
        } else {
             toast({ variant: "destructive", title: "Invalid Coupon", description: "The coupon code you entered is not valid." });
        }
    } catch(error) {
        toast({ variant: "destructive", title: "Error", description: "Could not apply coupon. Please try again." });
    } finally {
        setCouponLoading(false);
    }
  };

  const handleUpiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !design || finalPrice === null) return;
     if (!transactionId.trim()) {
        toast({ variant: "destructive", title: "Transaction ID Required" });
        return;
    }

    setPaymentLoading(true);
    try {
        const userTransactionsRef = ref(db, `transactions/${user.uid}`);
        const newTransactionRef = push(userTransactionsRef);
        await set(newTransactionRef, {
            amount: finalPrice,
            description: `Purchase of design: ${design.name}`,
            timestamp: serverTimestamp(),
            type: 'purchase',
            status: 'pending',
            details: {
                designId: design.id,
                designName: design.name,
                transactionId: transactionId,
                originalPrice: design.price || 50000,
                discountApplied: discount > 0 ? `${discount}%` : 'None',
                couponCode: discount > 0 ? couponCode : 'None',
            }
        });
        toast({
            title: 'Payment Submitted!',
            description: 'Your payment is being verified. You will be notified upon confirmation.',
        });
        router.push('/billing');
    } catch (error) {
        toast({ variant: 'destructive', title: 'Submission Failed' });
    } finally {
        setPaymentLoading(false);
    }
  }


  if (loading) {
    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <PageHeader
                title="Complete Your Purchase"
                description="Loading your order details..."
            />
            <div className="grid md:grid-cols-2 gap-8 items-start">
                <Card>
                    <CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader>
                    <CardContent className="space-y-4">
                        <Skeleton className="h-40 w-full" />
                    </CardContent>
                    <CardFooter><Skeleton className="h-12 w-full" /></CardFooter>
                </Card>
                <div className="space-y-4">
                    <h3 className="font-headline text-xl font-bold">Order Summary</h3>
                    <Skeleton className="h-64 w-full" />
                </div>
            </div>
        </div>
    )
  }

  if (!design) {
    return (
      <div className="text-center py-12">
        <h2 className="font-headline text-2xl">Design not found</h2>
        <p className="text-muted-foreground">The design you are looking for does not exist.</p>
      </div>
    );
  }
  
  if (!user) {
    return (
        <div className="text-center py-12">
            <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Authentication Required</CardTitle>
                    <CardDescription>You need to be logged in to purchase a design. Please log in or sign up to continue.</CardDescription>
                </CardHeader>
                <CardContent className="flex gap-4 justify-center">
                    <Button asChild>
                        <Link href={`/login?redirect=/payment/${design.id}`}> <LogIn className="mr-2"/> Login</Link>
                    </Button>
                     <Button asChild variant="outline">
                        <Link href={`/signup?redirect=/payment/${design.id}`}>Sign Up</Link>
                    </Button>
                </CardContent>
            </Card>
      </div>
    );
  }

  const price = finalPrice !== null ? finalPrice : (design.price || 50000);
  const upiLink = `upi://pay?pa=${upiId}&pn=${payeeName}&am=${price.toFixed(2)}&cu=INR&tn=Payment for ${design.name}`;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <PageHeader
        title="Complete Your Purchase"
        description={`You are purchasing the plan for "${design.name}".`}
      />
      <div className="grid md:grid-cols-2 gap-8 items-start">
        <Tabs defaultValue="upi" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="upi">Pay with UPI</TabsTrigger>
                <TabsTrigger value="card" disabled>Card Payment</TabsTrigger>
            </TabsList>
            <TabsContent value="upi">
                <form onSubmit={handleUpiSubmit}>
                <Card>
                <CardHeader>
                    <CardTitle className="font-headline">Pay with UPI</CardTitle>
                    <CardDescription>1. Scan the QR code or use the UPI ID to pay.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-center">
                    <div className="p-4 bg-muted rounded-lg">
                        <div className="flex justify-center my-4">
                            <Image 
                                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiLink)}`}
                                alt="UPI QR Code"
                                width={200}
                                height={200}
                                className="rounded-md border p-2"
                            />
                        </div>
                        <p className="font-mono font-semibold text-lg">{upiId}</p>
                    </div>
                     <p className="text-sm text-muted-foreground">OR</p>
                      <Button className="w-full" size="lg" asChild>
                       <Link href={upiLink}>
                         Pay {isDubai ? `AED ${price.toLocaleString()}` : <><IndianRupee className="inline-block h-4 w-4" />{price.toLocaleString('en-IN')}</>} via UPI App
                       </Link>
                    </Button>
                </CardContent>
                <CardHeader>
                    <CardDescription>2. After paying, submit the Transaction ID below.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        <Label htmlFor="transaction-id">UPI Transaction ID</Label>
                        <Input 
                            id="transaction-id" 
                            placeholder="e.g., 217382193812"
                            value={transactionId}
                            onChange={(e) => setTransactionId(e.target.value)}
                            required
                        />
                    </div>
                </CardContent>
                <CardFooter>
                   <Button type="submit" className="w-full" size="lg" disabled={paymentLoading}>
                     {paymentLoading ? <Loader2 className="mr-2 animate-spin"/> : <CheckCircle className="mr-2" />}
                     {paymentLoading ? 'Verifying...' : 'Submit & Verify Payment'}
                   </Button>
                </CardFooter>
                </Card>
                </form>
            </TabsContent>
        </Tabs>
        

        <div className="space-y-4">
            <h3 className="font-headline text-xl font-bold">Order Summary</h3>
            <Card className="overflow-hidden">
                <Image 
                    src={design.image || `https://picsum.photos/seed/${design.id}/400/250`}
                    alt={design.name}
                    width={400}
                    height={250}
                    className="w-full object-cover aspect-video"
                    data-ai-hint={design.dataAiHint}
                />
                <CardContent className="p-4 space-y-3">
                    <h4 className="font-headline font-semibold">{design.name}</h4>
                    <p className="text-muted-foreground text-sm">{design.style}</p>
                    
                    <div className="space-y-2 pt-3 border-t">
                        <div className="flex justify-between items-center text-sm">
                            <p className="text-muted-foreground">Original Price</p>
                            <p>{isDubai ? 'AED' : '₹'}{(design.price || 50000).toLocaleString(isDubai ? undefined : 'en-IN')}</p>
                        </div>
                        {discount > 0 && (
                             <div className="flex justify-between items-center text-sm text-green-600">
                                <p>Coupon Discount ({discount}%)</p>
                                <p>- {isDubai ? 'AED ' : '₹'}{((design.price || 50000) * (discount / 100)).toLocaleString(isDubai ? undefined : 'en-IN')}</p>
                            </div>
                        )}
                    </div>
                    
                    <div className="flex justify-between items-center mt-2 pt-2 border-t">
                        <p className="font-semibold text-lg">Total</p>
                        <p className="font-bold text-xl flex items-center">
                            {isDubai ? 'AED ' : <IndianRupee/>}
                            {price.toLocaleString(isDubai ? undefined : 'en-IN')}
                        </p>
                    </div>
                </CardContent>
                 <CardFooter className="bg-muted/50 p-4">
                    <div className="w-full space-y-2">
                        <Label htmlFor="coupon-code">Have a Coupon?</Label>
                        <div className="flex gap-2">
                            <Input 
                                id="coupon-code" 
                                placeholder="Enter coupon code" 
                                value={couponCode}
                                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                                disabled={couponLoading || discount > 0}
                            />
                            <Button variant="secondary" onClick={handleApplyCoupon} disabled={couponLoading || discount > 0}>
                                {couponLoading ? <Loader2 className="animate-spin" /> : 'Apply'}
                            </Button>
                        </div>
                    </div>
                </CardFooter>
            </Card>
        </div>
      </div>
    </div>
  );
}
