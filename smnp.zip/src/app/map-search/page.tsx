
'use client';

import { useEffect, useMemo, useState } from "react";
import PageHeader from "@/components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { db } from "@/lib/firebase";
import { ref, onValue } from "firebase/database";
import type { Provider } from "@/lib/types";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Briefcase, LocateFixed, Loader2, View, ShieldCheck } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

type Professional = Provider & { role: 'designer' | 'constructor' | 'supplier' | 'seller' };

export default function MapSearchPage() {
    const { toast } = useToast();
    const [allProfessionals, setAllProfessionals] = useState<Professional[]>([]);
    const [loading, setLoading] = useState(true);
    const [locating, setLocating] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [roleFilter, setRoleFilter] = useState("all");
    const [cityFilter, setCityFilter] = useState("all");
    const [statusFilter, setStatusFilter] = useState<"all" | "verified">("verified");
    const [mapUrl, setMapUrl] = useState("https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15020421.11826018!2d72.39634994596329!3d22.99925237735326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30635ff06b92b791%3A0xd78c4fa1854213a6!2sIndia!5e0!3m2!1sen!2sin!4v1717861535891!5m2!1sen!2sin");

    useEffect(() => {
        setLoading(true);
        const usersRef = ref(db, 'users');
        const unsubscribe = onValue(usersRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                const professionalsList: Professional[] = Object.keys(data)
                    .map(key => ({ id: key, ...data[key] }))
                    .filter(user => (user.role === 'designer' || user.role === 'constructor' || user.role === 'supplier' || user.role === 'seller'));
                setAllProfessionals(professionalsList);
            }
            setLoading(false);
        });
        return () => unsubscribe();
    }, []);
    
    const professionalCities = useMemo(() => {
        const cities = allProfessionals
            .map(p => p.location)
            .filter((c): c is string => !!c);
        return [...new Set(cities)].sort();
    }, [allProfessionals]);

    const professionalsByCity = useMemo(() => {
        let filteredProfessionals = allProfessionals;

        if (statusFilter === 'verified') {
            filteredProfessionals = filteredProfessionals.filter(p => p.status === 'verified' || p.status === 'master');
        }

        if (roleFilter !== 'all') {
            filteredProfessionals = filteredProfessionals.filter(p => p.role === roleFilter);
        }

        if (cityFilter !== 'all') {
            filteredProfessionals = filteredProfessionals.filter(p => p.location === cityFilter);
        }

        if (searchTerm) {
            const lowerCaseSearchTerm = searchTerm.toLowerCase();
            filteredProfessionals = filteredProfessionals.filter(p => {
                return (p.name && p.name.toLowerCase().includes(lowerCaseSearchTerm)) || 
                       (p.location && p.location.toLowerCase().includes(lowerCaseSearchTerm)) ||
                       (p.specialty && p.specialty.toLowerCase().includes(lowerCaseSearchTerm));
            });
        }

        const grouped = filteredProfessionals.reduce((acc, professional) => {
            const city = professional.location;
            if (city) {
                if (!acc[city]) {
                    acc[city] = [];
                }
                acc[city].push(professional);
            }
            return acc;
        }, {} as Record<string, Professional[]>);

        return Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b));

    }, [allProfessionals, searchTerm, roleFilter, cityFilter, statusFilter]);

    const getInitials = (name?: string) => {
        if (!name) return 'P';
        return name.substring(0, 2).toUpperCase();
    }
    
    const handleLocateMe = () => {
        if (!navigator.geolocation) {
            toast({
                variant: 'destructive',
                title: 'Geolocation Not Supported',
                description: 'Your browser does not support geolocation.',
            });
            return;
        }

        setLocating(true);
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                const userLocationUrl = `https://www.google.com/maps/embed/v1/view?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&center=${latitude},${longitude}&zoom=14`;
                setMapUrl(userLocationUrl);
                setLocating(false);
                toast({
                    title: 'Location Found!',
                    description: 'Map centered on your current location.',
                });
            },
            (error) => {
                setLocating(false);
                toast({
                    variant: 'destructive',
                    title: 'Location Access Denied',
                    description: 'Please allow location access in your browser settings to use this feature.',
                });
                console.error("Geolocation error:", error);
            }
        );
    };

    const handleViewOnMap = (professional: Professional) => {
        if (professional.locationUrl) {
            const embedUrl = `https://maps.google.com/maps?q=${encodeURIComponent(professional.location)}&t=&z=13&ie=UTF8&iwloc=&output=embed`;
            setMapUrl(embedUrl);
        } else {
            toast({
                variant: "secondary",
                title: "Location Not Available",
                description: "This professional has not provided a specific map location.",
            });
        }
    };

    return (
        <div className="space-y-8">
            <PageHeader
                title="Search Professionals by Map"
                description="Visually explore verified professionals across India."
            />
            <div className="grid lg:grid-cols-3 gap-8 h-[75vh]">
                <Card className="lg:col-span-1 flex flex-col">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Search /> Find a Professional
                        </CardTitle>
                        <div className="flex gap-2 pt-2">
                             <Input 
                                placeholder="Search by name, location..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                             <Button variant="outline" size="icon" onClick={handleLocateMe} disabled={locating} title="Find professionals near me">
                                {locating ? <Loader2 className="h-4 w-4 animate-spin" /> : <LocateFixed className="h-4 w-4" />}
                                <span className="sr-only">Find nearby</span>
                            </Button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <Select value={roleFilter} onValueChange={setRoleFilter}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Role" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Roles</SelectItem>
                                    <SelectItem value="designer">Designer</SelectItem>
                                    <SelectItem value="constructor">Constructor</SelectItem>
                                    <SelectItem value="supplier">Supplier</SelectItem>
                                    <SelectItem value="seller">Seller</SelectItem>
                                </SelectContent>
                            </Select>
                             <Select value={cityFilter} onValueChange={setCityFilter}>
                                <SelectTrigger>
                                    <SelectValue placeholder="City" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Cities</SelectItem>
                                    {professionalCities.map(city => (
                                        <SelectItem key={city} value={city}>{city}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as "all" | "verified")}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Status" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Statuses</SelectItem>
                                    <SelectItem value="verified">Verified Only</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </CardHeader>
                    <CardContent className="p-0 flex-1">
                        <ScrollArea className="h-full">
                             {loading ? (
                                <div className="space-y-4 p-4">
                                    <Skeleton className="h-20 w-full" />
                                    <Skeleton className="h-20 w-full" />
                                    <Skeleton className="h-20 w-full" />
                                    <Skeleton className="h-20 w-full" />
                                </div>
                            ) : professionalsByCity.length === 0 ? (
                                <div className="p-8 text-center text-muted-foreground">
                                    <p>No professionals found matching your criteria.</p>
                                    <p className="text-sm">Try adjusting your search or filter settings.</p>
                                </div>
                            ) : (
                                <Accordion type="multiple" className="w-full">
                                    {professionalsByCity.map(([city, professionals]) => (
                                        <AccordionItem value={city} key={city}>
                                            <AccordionTrigger className="px-4 py-3 hover:bg-muted/50">
                                                <div className="flex items-center gap-2">
                                                    <span className="font-semibold">{city}</span>
                                                    <Badge variant="secondary">{professionals.length}</Badge>
                                                </div>
                                            </AccordionTrigger>
                                            <AccordionContent className="px-1.5 pb-2">
                                                 <div className="space-y-2 p-2">
                                                    {professionals.map(prof => (
                                                        <Card key={prof.id} className="hover:bg-muted/50">
                                                            <CardContent className="p-3">
                                                                <div className="flex items-start gap-4">
                                                                    <Avatar className="h-12 w-12 border">
                                                                        <AvatarImage src={prof.image} alt={prof.name}/>
                                                                        <AvatarFallback>{getInitials(prof.name)}</AvatarFallback>
                                                                    </Avatar>
                                                                    <div className="flex-1 space-y-1">
                                                                        <Link href={`/${prof.role}s/${prof.id}`} target="_blank">
                                                                            <h3 className="font-semibold hover:text-primary transition-colors">{prof.name}</h3>
                                                                        </Link>
                                                                        <p className="text-xs text-muted-foreground capitalize flex items-center gap-1"><Briefcase className="h-3 w-3"/>{prof.role}</p>
                                                                        <p className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3"/>{prof.location}</p>
                                                                        {(prof.status === 'verified' || prof.status === 'master') && <Badge variant="secondary" className="border-green-500/50 bg-green-500/10 text-green-700 text-xs mt-1"><ShieldCheck className="mr-1 h-3 w-3"/>Verified</Badge>}
                                                                    </div>
                                                                    <Button size="icon" variant="outline" onClick={() => handleViewOnMap(prof)} disabled={!prof.locationUrl}>
                                                                        <View className="h-4 w-4" />
                                                                        <span className="sr-only">View on map</span>
                                                                    </Button>
                                                                </div>
                                                            </CardContent>
                                                        </Card>
                                                    ))}
                                                 </div>
                                            </AccordionContent>
                                        </AccordionItem>
                                    ))}
                                </Accordion>
                            )}
                        </ScrollArea>
                    </CardContent>
                </Card>

                <Card className="lg:col-span-2 overflow-hidden">
                    <iframe
                        key={mapUrl}
                        src={mapUrl}
                        width="100%"
                        height="100%"
                        style={{ border: 0 }}
                        allowFullScreen={true}
                        loading="lazy"
                        referrerPolicy="no-referrer-when-downgrade"
                    ></iframe>
                </Card>
            </div>
        </div>
    );
}
